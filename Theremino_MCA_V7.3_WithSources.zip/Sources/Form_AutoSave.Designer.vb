﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_AutoSave
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_AutoSave))
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Me.txt_AutoSave_Format = New System.Windows.Forms.TextBox
        Me.lst_AutoSaveItem = New System.Windows.Forms.CheckedListBox
        Me.lbl_seconds = New System.Windows.Forms.Label
        Me.lbl_Path_format = New System.Windows.Forms.Label
        Me.chk_AutoSave_Enabled = New System.Windows.Forms.CheckBox
        Me.lbl_Folder = New System.Windows.Forms.Label
        Me.txt_AutoSave_Folder = New System.Windows.Forms.TextBox
        Me.btn_Browse = New System.Windows.Forms.Button
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog
        Me.lbl_Execute = New System.Windows.Forms.Label
        Me.txt_AutoSave_Execute = New System.Windows.Forms.TextBox
        Me.chk_AutoSave_ExecuteEnabled = New System.Windows.Forms.CheckBox
        Me.btn_OK = New System.Windows.Forms.Button
        Me.btn_Cancel = New System.Windows.Forms.Button
        Me.lbl_Items_to_save = New System.Windows.Forms.Label
        Me.GroupBox_AutoSave_Detail = New System.Windows.Forms.GroupBox
        Me.btn_Help = New MyButton
        Me.btn_Apply = New System.Windows.Forms.Button
        Me.btn_Now = New System.Windows.Forms.Button
        Me.chk_AutoSave_StartNew = New System.Windows.Forms.CheckBox
        Me.lbl_Save_every = New System.Windows.Forms.Label
        Me.txt_AutoSaveSeconds = New MyTextBox
        Me.GroupBox_AutoSave_Detail.SuspendLayout()
        Me.SuspendLayout()
        '
        'txt_AutoSave_Format
        '
        Me.txt_AutoSave_Format.ForeColor = System.Drawing.SystemColors.ControlText
        Me.txt_AutoSave_Format.Location = New System.Drawing.Point(86, 73)
        Me.txt_AutoSave_Format.Name = "txt_AutoSave_Format"
        Me.txt_AutoSave_Format.Size = New System.Drawing.Size(417, 20)
        Me.txt_AutoSave_Format.TabIndex = 3
        '
        'lst_AutoSaveItem
        '
        Me.lst_AutoSaveItem.CheckOnClick = True
        Me.lst_AutoSaveItem.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lst_AutoSaveItem.FormattingEnabled = True
        Me.lst_AutoSaveItem.Location = New System.Drawing.Point(88, 108)
        Me.lst_AutoSaveItem.Name = "lst_AutoSaveItem"
        Me.lst_AutoSaveItem.Size = New System.Drawing.Size(415, 94)
        Me.lst_AutoSaveItem.TabIndex = 4
        '
        'lbl_seconds
        '
        Me.lbl_seconds.AutoSize = True
        Me.lbl_seconds.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_seconds.Location = New System.Drawing.Point(182, 22)
        Me.lbl_seconds.Name = "lbl_seconds"
        Me.lbl_seconds.Size = New System.Drawing.Size(47, 13)
        Me.lbl_seconds.TabIndex = 7
        Me.lbl_seconds.Text = "seconds"
        '
        'lbl_Path_format
        '
        Me.lbl_Path_format.AutoSize = True
        Me.lbl_Path_format.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_Path_format.Location = New System.Drawing.Point(6, 76)
        Me.lbl_Path_format.Name = "lbl_Path_format"
        Me.lbl_Path_format.Size = New System.Drawing.Size(61, 13)
        Me.lbl_Path_format.TabIndex = 8
        Me.lbl_Path_format.Text = "Path format"
        '
        'chk_AutoSave_Enabled
        '
        Me.chk_AutoSave_Enabled.AutoSize = True
        Me.chk_AutoSave_Enabled.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chk_AutoSave_Enabled.Location = New System.Drawing.Point(246, 22)
        Me.chk_AutoSave_Enabled.Name = "chk_AutoSave_Enabled"
        Me.chk_AutoSave_Enabled.Size = New System.Drawing.Size(65, 17)
        Me.chk_AutoSave_Enabled.TabIndex = 10
        Me.chk_AutoSave_Enabled.Text = "Enabled"
        Me.chk_AutoSave_Enabled.UseVisualStyleBackColor = True
        '
        'lbl_Folder
        '
        Me.lbl_Folder.AutoSize = True
        Me.lbl_Folder.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_Folder.Location = New System.Drawing.Point(6, 50)
        Me.lbl_Folder.Name = "lbl_Folder"
        Me.lbl_Folder.Size = New System.Drawing.Size(36, 13)
        Me.lbl_Folder.TabIndex = 11
        Me.lbl_Folder.Text = "Folder"
        '
        'txt_AutoSave_Folder
        '
        Me.txt_AutoSave_Folder.ForeColor = System.Drawing.SystemColors.ControlText
        Me.txt_AutoSave_Folder.Location = New System.Drawing.Point(86, 47)
        Me.txt_AutoSave_Folder.Name = "txt_AutoSave_Folder"
        Me.txt_AutoSave_Folder.Size = New System.Drawing.Size(346, 20)
        Me.txt_AutoSave_Folder.TabIndex = 12
        '
        'btn_Browse
        '
        Me.btn_Browse.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_Browse.Location = New System.Drawing.Point(438, 47)
        Me.btn_Browse.Name = "btn_Browse"
        Me.btn_Browse.Size = New System.Drawing.Size(65, 20)
        Me.btn_Browse.TabIndex = 13
        Me.btn_Browse.Text = "Browse"
        Me.btn_Browse.UseVisualStyleBackColor = True
        '
        'FolderBrowserDialog1
        '
        Me.FolderBrowserDialog1.Description = "Pick a directory, please."
        '
        'lbl_Execute
        '
        Me.lbl_Execute.AutoSize = True
        Me.lbl_Execute.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_Execute.Location = New System.Drawing.Point(9, 221)
        Me.lbl_Execute.Name = "lbl_Execute"
        Me.lbl_Execute.Size = New System.Drawing.Size(46, 13)
        Me.lbl_Execute.TabIndex = 14
        Me.lbl_Execute.Text = "Execute"
        '
        'txt_AutoSave_Execute
        '
        Me.txt_AutoSave_Execute.ForeColor = System.Drawing.SystemColors.ControlText
        Me.txt_AutoSave_Execute.Location = New System.Drawing.Point(86, 218)
        Me.txt_AutoSave_Execute.Name = "txt_AutoSave_Execute"
        Me.txt_AutoSave_Execute.Size = New System.Drawing.Size(326, 20)
        Me.txt_AutoSave_Execute.TabIndex = 15
        '
        'chk_AutoSave_ExecuteEnabled
        '
        Me.chk_AutoSave_ExecuteEnabled.AutoSize = True
        Me.chk_AutoSave_ExecuteEnabled.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chk_AutoSave_ExecuteEnabled.Location = New System.Drawing.Point(438, 220)
        Me.chk_AutoSave_ExecuteEnabled.Name = "chk_AutoSave_ExecuteEnabled"
        Me.chk_AutoSave_ExecuteEnabled.Size = New System.Drawing.Size(65, 17)
        Me.chk_AutoSave_ExecuteEnabled.TabIndex = 16
        Me.chk_AutoSave_ExecuteEnabled.Text = "Enabled"
        Me.chk_AutoSave_ExecuteEnabled.UseVisualStyleBackColor = True
        '
        'btn_OK
        '
        Me.btn_OK.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_OK.Location = New System.Drawing.Point(423, 257)
        Me.btn_OK.Name = "btn_OK"
        Me.btn_OK.Size = New System.Drawing.Size(80, 29)
        Me.btn_OK.TabIndex = 17
        Me.btn_OK.Text = "OK"
        Me.btn_OK.UseVisualStyleBackColor = True
        '
        'btn_Cancel
        '
        Me.btn_Cancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_Cancel.Location = New System.Drawing.Point(246, 257)
        Me.btn_Cancel.Name = "btn_Cancel"
        Me.btn_Cancel.Size = New System.Drawing.Size(80, 29)
        Me.btn_Cancel.TabIndex = 18
        Me.btn_Cancel.Text = "Cancel"
        Me.btn_Cancel.UseVisualStyleBackColor = True
        '
        'lbl_Items_to_save
        '
        Me.lbl_Items_to_save.AutoSize = True
        Me.lbl_Items_to_save.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.lbl_Items_to_save.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_Items_to_save.Location = New System.Drawing.Point(4, 108)
        Me.lbl_Items_to_save.Name = "lbl_Items_to_save"
        Me.lbl_Items_to_save.Size = New System.Drawing.Size(70, 13)
        Me.lbl_Items_to_save.TabIndex = 19
        Me.lbl_Items_to_save.Text = "Items to save"
        '
        'GroupBox_AutoSave_Detail
        '
        Me.GroupBox_AutoSave_Detail.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.txt_AutoSaveSeconds)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.btn_Help)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.btn_Apply)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.btn_Now)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.chk_AutoSave_StartNew)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.lbl_Save_every)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.lbl_Items_to_save)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.btn_OK)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.btn_Cancel)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.chk_AutoSave_ExecuteEnabled)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.txt_AutoSave_Execute)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.lbl_Execute)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.btn_Browse)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.txt_AutoSave_Folder)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.lbl_Folder)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.chk_AutoSave_Enabled)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.lbl_Path_format)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.lbl_seconds)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.lst_AutoSaveItem)
        Me.GroupBox_AutoSave_Detail.Controls.Add(Me.txt_AutoSave_Format)
        Me.GroupBox_AutoSave_Detail.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox_AutoSave_Detail.Location = New System.Drawing.Point(4, 6)
        Me.GroupBox_AutoSave_Detail.Name = "GroupBox_AutoSave_Detail"
        Me.GroupBox_AutoSave_Detail.Size = New System.Drawing.Size(521, 292)
        Me.GroupBox_AutoSave_Detail.TabIndex = 20
        Me.GroupBox_AutoSave_Detail.TabStop = False
        Me.GroupBox_AutoSave_Detail.Text = "Details"
        '
        'btn_Help
        '
        Me.btn_Help.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Help.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(213, Byte), Integer), CType(CType(213, Byte), Integer)), System.Drawing.Color.White}
        CBlendItems1.iPoint = New Single() {0.0!, 0.755287!, 1.0!}
        Me.btn_Help.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems2.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_Help.ColorFillBlendChecked = CBlendItems2
        Me.btn_Help.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Help.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Help.Corners.All = CType(6, Short)
        Me.btn_Help.Corners.LowerLeft = CType(6, Short)
        Me.btn_Help.Corners.LowerRight = CType(6, Short)
        Me.btn_Help.Corners.UpperLeft = CType(6, Short)
        Me.btn_Help.Corners.UpperRight = CType(6, Short)
        Me.btn_Help.FillType = MyButton.eFillType.LinearVertical
        Me.btn_Help.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.btn_Help.FocalPoints.CenterPtX = 1.0!
        Me.btn_Help.FocalPoints.CenterPtY = 0.1904762!
        Me.btn_Help.FocalPoints.FocusPtX = 0.0!
        Me.btn_Help.FocalPoints.FocusPtY = 0.0!
        Me.btn_Help.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_Help.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_Help.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Help.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Help.FocusPtTracker = DesignerRectTracker2
        Me.btn_Help.Image = Nothing
        Me.btn_Help.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Help.ImageIndex = 0
        Me.btn_Help.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Help.Location = New System.Drawing.Point(438, 0)
        Me.btn_Help.Name = "btn_Help"
        Me.btn_Help.Shape = MyButton.eShape.Rectangle
        Me.btn_Help.SideImage = Nothing
        Me.btn_Help.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Help.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_Help.Size = New System.Drawing.Size(65, 16)
        Me.btn_Help.TabIndex = 24
        Me.btn_Help.Text = "Help"
        Me.btn_Help.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Help.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_Help.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Help.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Apply
        '
        Me.btn_Apply.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_Apply.Location = New System.Drawing.Point(343, 257)
        Me.btn_Apply.Name = "btn_Apply"
        Me.btn_Apply.Size = New System.Drawing.Size(68, 29)
        Me.btn_Apply.TabIndex = 23
        Me.btn_Apply.Text = "Apply"
        Me.btn_Apply.UseVisualStyleBackColor = True
        '
        'btn_Now
        '
        Me.btn_Now.Location = New System.Drawing.Point(28, 257)
        Me.btn_Now.Name = "btn_Now"
        Me.btn_Now.Size = New System.Drawing.Size(121, 29)
        Me.btn_Now.TabIndex = 22
        Me.btn_Now.Text = "Apply and Save Now"
        Me.btn_Now.UseVisualStyleBackColor = True
        '
        'chk_AutoSave_StartNew
        '
        Me.chk_AutoSave_StartNew.AutoSize = True
        Me.chk_AutoSave_StartNew.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chk_AutoSave_StartNew.Location = New System.Drawing.Point(389, 22)
        Me.chk_AutoSave_StartNew.Name = "chk_AutoSave_StartNew"
        Me.chk_AutoSave_StartNew.Size = New System.Drawing.Size(114, 17)
        Me.chk_AutoSave_StartNew.TabIndex = 21
        Me.chk_AutoSave_StartNew.Text = "Start new measure"
        Me.chk_AutoSave_StartNew.UseVisualStyleBackColor = True
        '
        'lbl_Save_every
        '
        Me.lbl_Save_every.AutoSize = True
        Me.lbl_Save_every.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_Save_every.Location = New System.Drawing.Point(6, 22)
        Me.lbl_Save_every.Name = "lbl_Save_every"
        Me.lbl_Save_every.Size = New System.Drawing.Size(61, 13)
        Me.lbl_Save_every.TabIndex = 20
        Me.lbl_Save_every.Text = "Save every"
        '
        'txt_AutoSaveSeconds
        '
        Me.txt_AutoSaveSeconds.ArrowsIncrement = 10
        Me.txt_AutoSaveSeconds.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_AutoSaveSeconds.Increment = 10
        Me.txt_AutoSaveSeconds.Location = New System.Drawing.Point(86, 19)
        Me.txt_AutoSaveSeconds.MaxValue = 90000000
        Me.txt_AutoSaveSeconds.MinValue = 10
        Me.txt_AutoSaveSeconds.Name = "txt_AutoSaveSeconds"
        Me.txt_AutoSaveSeconds.NumericValue = 10
        Me.txt_AutoSaveSeconds.NumericValueInteger = 10
        Me.txt_AutoSaveSeconds.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_AutoSaveSeconds.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_AutoSaveSeconds.RoundingStep = 0
        Me.txt_AutoSaveSeconds.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_AutoSaveSeconds.Size = New System.Drawing.Size(86, 20)
        Me.txt_AutoSaveSeconds.TabIndex = 25
        '
        'Form_AutoSave
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(531, 304)
        Me.Controls.Add(Me.GroupBox_AutoSave_Detail)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form_AutoSave"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "AutoSave setting"
        Me.GroupBox_AutoSave_Detail.ResumeLayout(False)
        Me.GroupBox_AutoSave_Detail.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txt_AutoSave_Format As System.Windows.Forms.TextBox
    Friend WithEvents lst_AutoSaveItem As System.Windows.Forms.CheckedListBox
    Friend WithEvents lbl_seconds As System.Windows.Forms.Label
    Friend WithEvents lbl_Path_format As System.Windows.Forms.Label
    Friend WithEvents chk_AutoSave_Enabled As System.Windows.Forms.CheckBox
    Friend WithEvents lbl_Folder As System.Windows.Forms.Label
    Friend WithEvents txt_AutoSave_Folder As System.Windows.Forms.TextBox
    Friend WithEvents btn_Browse As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents lbl_Execute As System.Windows.Forms.Label
    Friend WithEvents txt_AutoSave_Execute As System.Windows.Forms.TextBox
    Friend WithEvents chk_AutoSave_ExecuteEnabled As System.Windows.Forms.CheckBox
    Friend WithEvents btn_OK As System.Windows.Forms.Button
    Friend WithEvents btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents lbl_Items_to_save As System.Windows.Forms.Label
    Friend WithEvents GroupBox_AutoSave_Detail As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_Save_every As System.Windows.Forms.Label
    Friend WithEvents chk_AutoSave_StartNew As System.Windows.Forms.CheckBox
    Friend WithEvents btn_Apply As System.Windows.Forms.Button
    Friend WithEvents btn_Now As System.Windows.Forms.Button
    Friend WithEvents btn_Help As MyButton
    Friend WithEvents txt_AutoSaveSeconds As MyTextBox
End Class
