﻿Public Class Form_Help

    Private Sub Form_HelpResize(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        rt_Help.Height = Me.Height - 54
        rt_Help.Width = Me.Width - 36
    End Sub
End Class