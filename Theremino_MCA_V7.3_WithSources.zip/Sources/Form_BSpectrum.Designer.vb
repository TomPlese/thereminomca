﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_BSpectrum
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_BSpectrum))
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker3 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems3 As cBlendItems = New cBlendItems
        Dim CBlendItems4 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker4 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker5 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems5 As cBlendItems = New cBlendItems
        Dim CBlendItems6 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker6 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker7 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems7 As cBlendItems = New cBlendItems
        Dim CBlendItems8 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker8 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker9 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems9 As cBlendItems = New cBlendItems
        Dim CBlendItems10 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker10 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker11 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems11 As cBlendItems = New cBlendItems
        Dim CBlendItems12 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker12 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker13 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems13 As cBlendItems = New cBlendItems
        Dim CBlendItems14 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker14 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker15 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems15 As cBlendItems = New cBlendItems
        Dim CBlendItems16 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker16 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker17 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems17 As cBlendItems = New cBlendItems
        Dim CBlendItems18 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker18 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker19 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems19 As cBlendItems = New cBlendItems
        Dim CBlendItems20 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker20 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker21 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems21 As cBlendItems = New cBlendItems
        Dim CBlendItems22 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker22 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker23 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems23 As cBlendItems = New cBlendItems
        Dim CBlendItems24 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker24 As DesignerRectTracker = New DesignerRectTracker
        Me.Group_BS_Details = New System.Windows.Forms.GroupBox
        Me.btn_BS_CopyBack = New System.Windows.Forms.Button
        Me.lbl_BS_Speed = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txt_BS_Speed = New MyTextBox
        Me.btn_BS_Filename = New System.Windows.Forms.Button
        Me.btn_BS_ShowHide = New MyButton
        Me.lbl_BS_Info = New System.Windows.Forms.Label
        Me.btn_BS_UseBKG = New MyButton
        Me.chk_BS_RawData = New System.Windows.Forms.CheckBox
        Me.tk_BS_Index = New System.Windows.Forms.TrackBar
        Me.btn_Help = New MyButton
        Me.lbl_BS_Index = New System.Windows.Forms.Label
        Me.txt_BS_Index = New MyTextBox
        Me.tk_BS_Speed = New System.Windows.Forms.TrackBar
        Me.btn_BS_Stop = New MyButton
        Me.btn_BS_Forward = New MyButton
        Me.btn_BS_Back = New MyButton
        Me.chk_BS_Repeat = New System.Windows.Forms.CheckBox
        Me.rad_BS_Current = New System.Windows.Forms.RadioButton
        Me.rad_BS_BKG = New System.Windows.Forms.RadioButton
        Me.rad_BS_Ref3 = New System.Windows.Forms.RadioButton
        Me.rad_BS_Ref2 = New System.Windows.Forms.RadioButton
        Me.rad_BS_Ref1 = New System.Windows.Forms.RadioButton
        Me.btn_BS_CommitXY = New System.Windows.Forms.Button
        Me.btn_BS_Apply = New System.Windows.Forms.Button
        Me.btn_BS_Browse = New System.Windows.Forms.Button
        Me.txt_BS_Filename = New System.Windows.Forms.TextBox
        Me.txt_BS_Folder = New System.Windows.Forms.TextBox
        Me.FolderBrowserDialog_BS = New System.Windows.Forms.FolderBrowserDialog
        Me.GB_BS_X = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txt_BS_X_Multiply00 = New MyTextBox
        Me.chk_BS_EnergyAdj = New System.Windows.Forms.CheckBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.lbl_BS_Offset = New System.Windows.Forms.Label
        Me.txt_BS_Offset = New MyTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.rad_BS_X_1_10 = New System.Windows.Forms.RadioButton
        Me.rad_BS_X_1_2 = New System.Windows.Forms.RadioButton
        Me.rad_BS_X_Auto = New System.Windows.Forms.RadioButton
        Me.tk_BS_X = New System.Windows.Forms.TrackBar
        Me.lbl_BS_X_Multiply = New System.Windows.Forms.Label
        Me.txt_BS_X_Multiply = New MyTextBox
        Me.rad_BS_X_20 = New System.Windows.Forms.RadioButton
        Me.rad_BS_X_10 = New System.Windows.Forms.RadioButton
        Me.rad_BS_X_5 = New System.Windows.Forms.RadioButton
        Me.rad_BS_X_2 = New System.Windows.Forms.RadioButton
        Me.rad_BS_X_1 = New System.Windows.Forms.RadioButton
        Me.chk_BS_SPE = New System.Windows.Forms.CheckBox
        Me.chk_BS_ThereminoMCA = New System.Windows.Forms.CheckBox
        Me.rad_BS_Y_Auto = New System.Windows.Forms.RadioButton
        Me.rad_BS_Y_1_2 = New System.Windows.Forms.RadioButton
        Me.rad_BS_Y_100 = New System.Windows.Forms.RadioButton
        Me.GB_BS_Y = New System.Windows.Forms.GroupBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.rad_BS_Y_1_10 = New System.Windows.Forms.RadioButton
        Me.rad_BS_Y_1 = New System.Windows.Forms.RadioButton
        Me.rad_BS_Y_2 = New System.Windows.Forms.RadioButton
        Me.tk_BS_Y = New System.Windows.Forms.TrackBar
        Me.lbl_BS_Y_Multiply = New System.Windows.Forms.Label
        Me.txt_BS_Y_Multiply = New MyTextBox
        Me.rad_BS_Y_10 = New System.Windows.Forms.RadioButton
        Me.GB_BS_Format = New System.Windows.Forms.GroupBox
        Me.btn_BS_Clear = New MyButton
        Me.btn_BS_All = New MyButton
        Me.GB_BS_Show = New System.Windows.Forms.GroupBox
        Me.btn_BS_SetBase = New MyButton
        Me.btn_BS_SaveNow = New MyButton
        Me.rad_BS_Sub = New System.Windows.Forms.RadioButton
        Me.rad_BS_Add = New System.Windows.Forms.RadioButton
        Me.rad_BS_Difference = New System.Windows.Forms.RadioButton
        Me.rad_BS_Sum = New System.Windows.Forms.RadioButton
        Me.rad_BS_Normal = New System.Windows.Forms.RadioButton
        Me.btn_BS_AutoSave = New MyButton
        Me.btn_BS_MoreOptions = New MyButton
        Me.OpenFileDialog_BS = New System.Windows.Forms.OpenFileDialog
        Me.AnimateTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Group_BS_Details.SuspendLayout()
        CType(Me.tk_BS_Index, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_BS_Speed, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GB_BS_X.SuspendLayout()
        CType(Me.tk_BS_X, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GB_BS_Y.SuspendLayout()
        CType(Me.tk_BS_Y, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GB_BS_Format.SuspendLayout()
        Me.GB_BS_Show.SuspendLayout()
        Me.SuspendLayout()
        '
        'Group_BS_Details
        '
        Me.Group_BS_Details.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_CopyBack)
        Me.Group_BS_Details.Controls.Add(Me.lbl_BS_Speed)
        Me.Group_BS_Details.Controls.Add(Me.Label5)
        Me.Group_BS_Details.Controls.Add(Me.txt_BS_Speed)
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_Filename)
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_ShowHide)
        Me.Group_BS_Details.Controls.Add(Me.lbl_BS_Info)
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_UseBKG)
        Me.Group_BS_Details.Controls.Add(Me.chk_BS_RawData)
        Me.Group_BS_Details.Controls.Add(Me.tk_BS_Index)
        Me.Group_BS_Details.Controls.Add(Me.btn_Help)
        Me.Group_BS_Details.Controls.Add(Me.lbl_BS_Index)
        Me.Group_BS_Details.Controls.Add(Me.txt_BS_Index)
        Me.Group_BS_Details.Controls.Add(Me.tk_BS_Speed)
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_Stop)
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_Forward)
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_Back)
        Me.Group_BS_Details.Controls.Add(Me.chk_BS_Repeat)
        Me.Group_BS_Details.Controls.Add(Me.rad_BS_Current)
        Me.Group_BS_Details.Controls.Add(Me.rad_BS_BKG)
        Me.Group_BS_Details.Controls.Add(Me.rad_BS_Ref3)
        Me.Group_BS_Details.Controls.Add(Me.rad_BS_Ref2)
        Me.Group_BS_Details.Controls.Add(Me.rad_BS_Ref1)
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_CommitXY)
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_Apply)
        Me.Group_BS_Details.Controls.Add(Me.btn_BS_Browse)
        Me.Group_BS_Details.Controls.Add(Me.txt_BS_Filename)
        Me.Group_BS_Details.Controls.Add(Me.txt_BS_Folder)
        Me.Group_BS_Details.ForeColor = System.Drawing.Color.Navy
        Me.Group_BS_Details.Location = New System.Drawing.Point(6, 4)
        Me.Group_BS_Details.Name = "Group_BS_Details"
        Me.Group_BS_Details.Size = New System.Drawing.Size(472, 183)
        Me.Group_BS_Details.TabIndex = 1
        Me.Group_BS_Details.TabStop = False
        '
        'btn_BS_CopyBack
        '
        Me.btn_BS_CopyBack.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_BS_CopyBack.Location = New System.Drawing.Point(398, 139)
        Me.btn_BS_CopyBack.Name = "btn_BS_CopyBack"
        Me.btn_BS_CopyBack.Size = New System.Drawing.Size(69, 26)
        Me.btn_BS_CopyBack.TabIndex = 33
        Me.btn_BS_CopyBack.Text = "Copy back"
        Me.btn_BS_CopyBack.UseVisualStyleBackColor = True
        '
        'lbl_BS_Speed
        '
        Me.lbl_BS_Speed.AutoSize = True
        Me.lbl_BS_Speed.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_BS_Speed.Location = New System.Drawing.Point(99, 149)
        Me.lbl_BS_Speed.Name = "lbl_BS_Speed"
        Me.lbl_BS_Speed.Size = New System.Drawing.Size(38, 13)
        Me.lbl_BS_Speed.TabIndex = 32
        Me.lbl_BS_Speed.Text = "Speed"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(169, 147)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(20, 16)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "%"
        '
        'txt_BS_Speed
        '
        Me.txt_BS_Speed.ArrowsIncrement = 1
        Me.txt_BS_Speed.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_BS_Speed.Increment = 1
        Me.txt_BS_Speed.Location = New System.Drawing.Point(140, 146)
        Me.txt_BS_Speed.MaxValue = 100
        Me.txt_BS_Speed.MinValue = 0
        Me.txt_BS_Speed.Name = "txt_BS_Speed"
        Me.txt_BS_Speed.NumericValue = 50
        Me.txt_BS_Speed.NumericValueInteger = 50
        Me.txt_BS_Speed.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_BS_Speed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_BS_Speed.RoundingStep = 1
        Me.txt_BS_Speed.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_BS_Speed.Size = New System.Drawing.Size(28, 20)
        Me.txt_BS_Speed.TabIndex = 29
        Me.txt_BS_Speed.Text = "50"
        Me.txt_BS_Speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_BS_Filename
        '
        Me.btn_BS_Filename.ForeColor = System.Drawing.Color.Navy
        Me.btn_BS_Filename.Location = New System.Drawing.Point(7, 76)
        Me.btn_BS_Filename.Name = "btn_BS_Filename"
        Me.btn_BS_Filename.Size = New System.Drawing.Size(52, 19)
        Me.btn_BS_Filename.TabIndex = 28
        Me.btn_BS_Filename.Text = "File"
        Me.btn_BS_Filename.UseVisualStyleBackColor = True
        '
        'btn_BS_ShowHide
        '
        Me.btn_BS_ShowHide.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_ShowHide.CenterPtTracker = DesignerRectTracker1
        Me.btn_BS_ShowHide.CheckButton = True
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, -0.003021148!, 0.7643505!, 0.8036254!, 1.0!}
        Me.btn_BS_ShowHide.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.305136!, 1.0!}
        Me.btn_BS_ShowHide.ColorFillBlendChecked = CBlendItems2
        Me.btn_BS_ShowHide.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_ShowHide.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_ShowHide.Corners.All = CType(6, Short)
        Me.btn_BS_ShowHide.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_ShowHide.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_ShowHide.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_ShowHide.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_ShowHide.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_ShowHide.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_BS_ShowHide.FocalPoints.CenterPtX = 0.5272727!
        Me.btn_BS_ShowHide.FocalPoints.CenterPtY = 0.0!
        Me.btn_BS_ShowHide.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_ShowHide.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_ShowHide.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_ShowHide.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_ShowHide.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_ShowHide.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_ShowHide.FocusPtTracker = DesignerRectTracker2
        Me.btn_BS_ShowHide.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_BS_ShowHide.Image = Nothing
        Me.btn_BS_ShowHide.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_ShowHide.ImageIndex = 0
        Me.btn_BS_ShowHide.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_ShowHide.Location = New System.Drawing.Point(5, 0)
        Me.btn_BS_ShowHide.Name = "btn_BS_ShowHide"
        Me.btn_BS_ShowHide.Shape = MyButton.eShape.Rectangle
        Me.btn_BS_ShowHide.SideImage = Nothing
        Me.btn_BS_ShowHide.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_ShowHide.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_ShowHide.Size = New System.Drawing.Size(45, 17)
        Me.btn_BS_ShowHide.TabIndex = 6
        Me.btn_BS_ShowHide.Text = "Show"
        Me.btn_BS_ShowHide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_ShowHide.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_ShowHide.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_ShowHide.TextShadow = System.Drawing.Color.Transparent
        Me.btn_BS_ShowHide.TextShadowChecked = System.Drawing.Color.Empty
        '
        'lbl_BS_Info
        '
        Me.lbl_BS_Info.AutoSize = True
        Me.lbl_BS_Info.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_BS_Info.Location = New System.Drawing.Point(67, 109)
        Me.lbl_BS_Info.Name = "lbl_BS_Info"
        Me.lbl_BS_Info.Size = New System.Drawing.Size(0, 13)
        Me.lbl_BS_Info.TabIndex = 27
        '
        'btn_BS_UseBKG
        '
        Me.btn_BS_UseBKG.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_UseBKG.CenterPtTracker = DesignerRectTracker3
        Me.btn_BS_UseBKG.CheckButton = True
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, -0.003021148!, 0.7643505!, 0.8036254!, 1.0!}
        Me.btn_BS_UseBKG.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.305136!, 1.0!}
        Me.btn_BS_UseBKG.ColorFillBlendChecked = CBlendItems4
        Me.btn_BS_UseBKG.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_UseBKG.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_UseBKG.Corners.All = CType(6, Short)
        Me.btn_BS_UseBKG.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_UseBKG.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_UseBKG.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_UseBKG.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_UseBKG.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_UseBKG.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_BS_UseBKG.FocalPoints.CenterPtX = 0.5272727!
        Me.btn_BS_UseBKG.FocalPoints.CenterPtY = 0.0!
        Me.btn_BS_UseBKG.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_UseBKG.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_UseBKG.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_UseBKG.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_UseBKG.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_UseBKG.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = True
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_UseBKG.FocusPtTracker = DesignerRectTracker4
        Me.btn_BS_UseBKG.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_BS_UseBKG.Image = Nothing
        Me.btn_BS_UseBKG.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_UseBKG.ImageIndex = 0
        Me.btn_BS_UseBKG.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_UseBKG.Location = New System.Drawing.Point(256, 0)
        Me.btn_BS_UseBKG.Name = "btn_BS_UseBKG"
        Me.btn_BS_UseBKG.Shape = MyButton.eShape.Rectangle
        Me.btn_BS_UseBKG.SideImage = Nothing
        Me.btn_BS_UseBKG.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_UseBKG.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_UseBKG.Size = New System.Drawing.Size(70, 17)
        Me.btn_BS_UseBKG.TabIndex = 7
        Me.btn_BS_UseBKG.Text = "UseBKG"
        Me.btn_BS_UseBKG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_UseBKG.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_UseBKG.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_UseBKG.TextShadow = System.Drawing.Color.Transparent
        Me.btn_BS_UseBKG.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'chk_BS_RawData
        '
        Me.chk_BS_RawData.AutoSize = True
        Me.chk_BS_RawData.Checked = True
        Me.chk_BS_RawData.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_BS_RawData.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chk_BS_RawData.Location = New System.Drawing.Point(391, 23)
        Me.chk_BS_RawData.Name = "chk_BS_RawData"
        Me.chk_BS_RawData.Size = New System.Drawing.Size(74, 17)
        Me.chk_BS_RawData.TabIndex = 12
        Me.chk_BS_RawData.Text = "Raw Data"
        Me.chk_BS_RawData.UseVisualStyleBackColor = True
        '
        'tk_BS_Index
        '
        Me.tk_BS_Index.AutoSize = False
        Me.tk_BS_Index.LargeChange = 1
        Me.tk_BS_Index.Location = New System.Drawing.Point(101, 23)
        Me.tk_BS_Index.Margin = New System.Windows.Forms.Padding(1)
        Me.tk_BS_Index.Name = "tk_BS_Index"
        Me.tk_BS_Index.Size = New System.Drawing.Size(213, 26)
        Me.tk_BS_Index.TabIndex = 10
        Me.tk_BS_Index.TickFrequency = 5
        '
        'btn_Help
        '
        Me.btn_Help.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Help.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, -0.003021148!, 0.7643505!, 0.8036254!, 1.0!}
        Me.btn_Help.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems6.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_Help.ColorFillBlendChecked = CBlendItems6
        Me.btn_Help.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Help.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Help.Corners.All = CType(6, Short)
        Me.btn_Help.Corners.LowerLeft = CType(6, Short)
        Me.btn_Help.Corners.LowerRight = CType(6, Short)
        Me.btn_Help.Corners.UpperLeft = CType(6, Short)
        Me.btn_Help.Corners.UpperRight = CType(6, Short)
        Me.btn_Help.FillType = MyButton.eFillType.LinearVertical
        Me.btn_Help.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.btn_Help.FocalPoints.CenterPtX = 0.5272727!
        Me.btn_Help.FocalPoints.CenterPtY = 0.0!
        Me.btn_Help.FocalPoints.FocusPtX = 0.0!
        Me.btn_Help.FocalPoints.FocusPtY = 0.0!
        Me.btn_Help.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_Help.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_Help.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Help.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Help.FocusPtTracker = DesignerRectTracker6
        Me.btn_Help.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Help.Image = Nothing
        Me.btn_Help.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Help.ImageIndex = 0
        Me.btn_Help.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Help.Location = New System.Drawing.Point(412, 0)
        Me.btn_Help.Name = "btn_Help"
        Me.btn_Help.Shape = MyButton.eShape.Rectangle
        Me.btn_Help.SideImage = Nothing
        Me.btn_Help.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Help.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_Help.Size = New System.Drawing.Size(55, 17)
        Me.btn_Help.TabIndex = 8
        Me.btn_Help.Text = "Help"
        Me.btn_Help.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Help.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_Help.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Help.TextShadow = System.Drawing.Color.Transparent
        '
        'lbl_BS_Index
        '
        Me.lbl_BS_Index.AutoSize = True
        Me.lbl_BS_Index.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_BS_Index.Location = New System.Drawing.Point(9, 23)
        Me.lbl_BS_Index.Name = "lbl_BS_Index"
        Me.lbl_BS_Index.Size = New System.Drawing.Size(33, 13)
        Me.lbl_BS_Index.TabIndex = 21
        Me.lbl_BS_Index.Text = "Index"
        '
        'txt_BS_Index
        '
        Me.txt_BS_Index.ArrowsIncrement = 1
        Me.txt_BS_Index.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_BS_Index.Increment = 1
        Me.txt_BS_Index.Location = New System.Drawing.Point(66, 25)
        Me.txt_BS_Index.MaxValue = 90000000
        Me.txt_BS_Index.MinValue = -1
        Me.txt_BS_Index.Name = "txt_BS_Index"
        Me.txt_BS_Index.NumericValue = 0
        Me.txt_BS_Index.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_BS_Index.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_BS_Index.RoundingStep = 1
        Me.txt_BS_Index.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_BS_Index.Size = New System.Drawing.Size(40, 20)
        Me.txt_BS_Index.TabIndex = 9
        Me.txt_BS_Index.Text = "0"
        Me.txt_BS_Index.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tk_BS_Speed
        '
        Me.tk_BS_Speed.AutoSize = False
        Me.tk_BS_Speed.LargeChange = 1
        Me.tk_BS_Speed.Location = New System.Drawing.Point(182, 139)
        Me.tk_BS_Speed.Margin = New System.Windows.Forms.Padding(1)
        Me.tk_BS_Speed.Maximum = 100
        Me.tk_BS_Speed.Name = "tk_BS_Speed"
        Me.tk_BS_Speed.Size = New System.Drawing.Size(100, 30)
        Me.tk_BS_Speed.TabIndex = 19
        Me.tk_BS_Speed.TickFrequency = 10
        Me.tk_BS_Speed.Value = 50
        '
        'btn_BS_Stop
        '
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_Stop.CenterPtTracker = DesignerRectTracker7
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.4623656!, 1.014337!, 1.0!}
        Me.btn_BS_Stop.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.Red, System.Drawing.Color.Orange, System.Drawing.Color.Orange}
        CBlendItems8.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_BS_Stop.ColorFillBlendChecked = CBlendItems8
        Me.btn_BS_Stop.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_Stop.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_Stop.Corners.All = CType(6, Short)
        Me.btn_BS_Stop.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_Stop.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_Stop.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_Stop.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_Stop.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_Stop.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.btn_BS_Stop.FocalPoints.CenterPtX = 1.0!
        Me.btn_BS_Stop.FocalPoints.CenterPtY = 0.3913043!
        Me.btn_BS_Stop.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_Stop.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_Stop.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_Stop.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_Stop.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_Stop.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_Stop.FocusPtTracker = DesignerRectTracker8
        Me.btn_BS_Stop.Image = Nothing
        Me.btn_BS_Stop.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_Stop.ImageIndex = 0
        Me.btn_BS_Stop.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_Stop.Location = New System.Drawing.Point(41, 142)
        Me.btn_BS_Stop.Name = "btn_BS_Stop"
        Me.btn_BS_Stop.Shape = MyButton.eShape.Rectangle
        Me.btn_BS_Stop.SideImage = Nothing
        Me.btn_BS_Stop.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_Stop.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_Stop.Size = New System.Drawing.Size(23, 23)
        Me.btn_BS_Stop.TabIndex = 18
        Me.btn_BS_Stop.Text = ""
        Me.btn_BS_Stop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_Stop.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_Stop.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_Stop.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_BS_Forward
        '
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_Forward.CenterPtTracker = DesignerRectTracker9
        Me.btn_BS_Forward.CheckButton = True
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.RoyalBlue, System.Drawing.Color.Navy}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_BS_Forward.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.4864048!, 1.0!}
        Me.btn_BS_Forward.ColorFillBlendChecked = CBlendItems10
        Me.btn_BS_Forward.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_Forward.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_Forward.Corners.All = CType(6, Short)
        Me.btn_BS_Forward.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_Forward.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_Forward.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_Forward.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_Forward.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_Forward.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.btn_BS_Forward.FocalPoints.CenterPtX = 0.0!
        Me.btn_BS_Forward.FocalPoints.CenterPtY = 0.3043478!
        Me.btn_BS_Forward.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_Forward.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_Forward.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_Forward.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_Forward.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_Forward.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_Forward.FocusPtTracker = DesignerRectTracker10
        Me.btn_BS_Forward.Image = Nothing
        Me.btn_BS_Forward.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_Forward.ImageIndex = 0
        Me.btn_BS_Forward.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_Forward.Location = New System.Drawing.Point(70, 142)
        Me.btn_BS_Forward.Name = "btn_BS_Forward"
        Me.btn_BS_Forward.Shape = MyButton.eShape.TriangleRight
        Me.btn_BS_Forward.SideImage = Nothing
        Me.btn_BS_Forward.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_Forward.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_Forward.Size = New System.Drawing.Size(23, 23)
        Me.btn_BS_Forward.TabIndex = 17
        Me.btn_BS_Forward.Text = ""
        Me.btn_BS_Forward.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_Forward.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_Forward.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_Forward.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_BS_Back
        '
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_Back.CenterPtTracker = DesignerRectTracker11
        Me.btn_BS_Back.CheckButton = True
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.RoyalBlue, System.Drawing.Color.Navy}
        CBlendItems11.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_BS_Back.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.4984894!, 1.0!}
        Me.btn_BS_Back.ColorFillBlendChecked = CBlendItems12
        Me.btn_BS_Back.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_Back.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_Back.Corners.All = CType(6, Short)
        Me.btn_BS_Back.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_Back.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_Back.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_Back.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_Back.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_Back.FillTypeChecked = MyButton.eFillType.LinearHorizontal
        Me.btn_BS_Back.FocalPoints.CenterPtX = 0.2!
        Me.btn_BS_Back.FocalPoints.CenterPtY = 0.2!
        Me.btn_BS_Back.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_Back.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_Back.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_Back.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_Back.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_Back.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_Back.FocusPtTracker = DesignerRectTracker12
        Me.btn_BS_Back.Image = Nothing
        Me.btn_BS_Back.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_Back.ImageIndex = 0
        Me.btn_BS_Back.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_Back.Location = New System.Drawing.Point(12, 142)
        Me.btn_BS_Back.Name = "btn_BS_Back"
        Me.btn_BS_Back.Shape = MyButton.eShape.TriangleLeft
        Me.btn_BS_Back.SideImage = Nothing
        Me.btn_BS_Back.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_Back.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_Back.Size = New System.Drawing.Size(23, 23)
        Me.btn_BS_Back.TabIndex = 16
        Me.btn_BS_Back.Text = ""
        Me.btn_BS_Back.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_Back.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_Back.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_Back.TextShadow = System.Drawing.Color.Transparent
        '
        'chk_BS_Repeat
        '
        Me.chk_BS_Repeat.AutoSize = True
        Me.chk_BS_Repeat.Checked = True
        Me.chk_BS_Repeat.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_BS_Repeat.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chk_BS_Repeat.Location = New System.Drawing.Point(320, 22)
        Me.chk_BS_Repeat.Name = "chk_BS_Repeat"
        Me.chk_BS_Repeat.Size = New System.Drawing.Size(61, 17)
        Me.chk_BS_Repeat.TabIndex = 11
        Me.chk_BS_Repeat.Text = "Repeat"
        Me.chk_BS_Repeat.UseVisualStyleBackColor = True
        '
        'rad_BS_Current
        '
        Me.rad_BS_Current.AccessibleName = "4"
        Me.rad_BS_Current.AutoSize = True
        Me.rad_BS_Current.Location = New System.Drawing.Point(334, 0)
        Me.rad_BS_Current.Name = "rad_BS_Current"
        Me.rad_BS_Current.Size = New System.Drawing.Size(59, 17)
        Me.rad_BS_Current.TabIndex = 5
        Me.rad_BS_Current.Text = "Current"
        Me.rad_BS_Current.UseVisualStyleBackColor = True
        '
        'rad_BS_BKG
        '
        Me.rad_BS_BKG.AccessibleName = "0"
        Me.rad_BS_BKG.AutoSize = True
        Me.rad_BS_BKG.Location = New System.Drawing.Point(202, 0)
        Me.rad_BS_BKG.Name = "rad_BS_BKG"
        Me.rad_BS_BKG.Size = New System.Drawing.Size(47, 17)
        Me.rad_BS_BKG.TabIndex = 4
        Me.rad_BS_BKG.Text = "BKG"
        Me.rad_BS_BKG.UseVisualStyleBackColor = True
        '
        'rad_BS_Ref3
        '
        Me.rad_BS_Ref3.AccessibleName = "3"
        Me.rad_BS_Ref3.AutoSize = True
        Me.rad_BS_Ref3.Location = New System.Drawing.Point(154, 0)
        Me.rad_BS_Ref3.Name = "rad_BS_Ref3"
        Me.rad_BS_Ref3.Size = New System.Drawing.Size(48, 17)
        Me.rad_BS_Ref3.TabIndex = 3
        Me.rad_BS_Ref3.Text = "Ref3"
        Me.rad_BS_Ref3.UseVisualStyleBackColor = True
        '
        'rad_BS_Ref2
        '
        Me.rad_BS_Ref2.AccessibleName = "2"
        Me.rad_BS_Ref2.AutoSize = True
        Me.rad_BS_Ref2.Location = New System.Drawing.Point(106, 0)
        Me.rad_BS_Ref2.Name = "rad_BS_Ref2"
        Me.rad_BS_Ref2.Size = New System.Drawing.Size(48, 17)
        Me.rad_BS_Ref2.TabIndex = 2
        Me.rad_BS_Ref2.Text = "Ref2"
        Me.rad_BS_Ref2.UseVisualStyleBackColor = True
        '
        'rad_BS_Ref1
        '
        Me.rad_BS_Ref1.AccessibleName = "1"
        Me.rad_BS_Ref1.AutoSize = True
        Me.rad_BS_Ref1.Checked = True
        Me.rad_BS_Ref1.Location = New System.Drawing.Point(58, 0)
        Me.rad_BS_Ref1.Name = "rad_BS_Ref1"
        Me.rad_BS_Ref1.Size = New System.Drawing.Size(48, 17)
        Me.rad_BS_Ref1.TabIndex = 1
        Me.rad_BS_Ref1.TabStop = True
        Me.rad_BS_Ref1.Text = "Ref1"
        Me.rad_BS_Ref1.UseVisualStyleBackColor = True
        '
        'btn_BS_CommitXY
        '
        Me.btn_BS_CommitXY.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_BS_CommitXY.Location = New System.Drawing.Point(330, 139)
        Me.btn_BS_CommitXY.Name = "btn_BS_CommitXY"
        Me.btn_BS_CommitXY.Size = New System.Drawing.Size(65, 26)
        Me.btn_BS_CommitXY.TabIndex = 9
        Me.btn_BS_CommitXY.Text = "Commit"
        Me.btn_BS_CommitXY.UseVisualStyleBackColor = True
        '
        'btn_BS_Apply
        '
        Me.btn_BS_Apply.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_BS_Apply.Location = New System.Drawing.Point(282, 139)
        Me.btn_BS_Apply.Name = "btn_BS_Apply"
        Me.btn_BS_Apply.Size = New System.Drawing.Size(44, 26)
        Me.btn_BS_Apply.TabIndex = 8
        Me.btn_BS_Apply.Text = "Aplly"
        Me.btn_BS_Apply.UseVisualStyleBackColor = True
        '
        'btn_BS_Browse
        '
        Me.btn_BS_Browse.ForeColor = System.Drawing.Color.Navy
        Me.btn_BS_Browse.Location = New System.Drawing.Point(6, 50)
        Me.btn_BS_Browse.Name = "btn_BS_Browse"
        Me.btn_BS_Browse.Size = New System.Drawing.Size(52, 19)
        Me.btn_BS_Browse.TabIndex = 3
        Me.btn_BS_Browse.Text = "Folder"
        Me.btn_BS_Browse.UseVisualStyleBackColor = True
        '
        'txt_BS_Filename
        '
        Me.txt_BS_Filename.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_BS_Filename.Location = New System.Drawing.Point(65, 76)
        Me.txt_BS_Filename.Name = "txt_BS_Filename"
        Me.txt_BS_Filename.Size = New System.Drawing.Size(397, 20)
        Me.txt_BS_Filename.TabIndex = 2
        '
        'txt_BS_Folder
        '
        Me.txt_BS_Folder.Location = New System.Drawing.Point(65, 50)
        Me.txt_BS_Folder.Name = "txt_BS_Folder"
        Me.txt_BS_Folder.Size = New System.Drawing.Size(400, 20)
        Me.txt_BS_Folder.TabIndex = 1
        '
        'GB_BS_X
        '
        Me.GB_BS_X.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GB_BS_X.Controls.Add(Me.Label3)
        Me.GB_BS_X.Controls.Add(Me.txt_BS_X_Multiply00)
        Me.GB_BS_X.Controls.Add(Me.chk_BS_EnergyAdj)
        Me.GB_BS_X.Controls.Add(Me.Label4)
        Me.GB_BS_X.Controls.Add(Me.lbl_BS_Offset)
        Me.GB_BS_X.Controls.Add(Me.txt_BS_Offset)
        Me.GB_BS_X.Controls.Add(Me.Label1)
        Me.GB_BS_X.Controls.Add(Me.rad_BS_X_1_10)
        Me.GB_BS_X.Controls.Add(Me.rad_BS_X_1_2)
        Me.GB_BS_X.Controls.Add(Me.rad_BS_X_Auto)
        Me.GB_BS_X.Controls.Add(Me.tk_BS_X)
        Me.GB_BS_X.Controls.Add(Me.lbl_BS_X_Multiply)
        Me.GB_BS_X.Controls.Add(Me.txt_BS_X_Multiply)
        Me.GB_BS_X.Controls.Add(Me.rad_BS_X_20)
        Me.GB_BS_X.Controls.Add(Me.rad_BS_X_10)
        Me.GB_BS_X.Controls.Add(Me.rad_BS_X_5)
        Me.GB_BS_X.Controls.Add(Me.rad_BS_X_2)
        Me.GB_BS_X.Controls.Add(Me.rad_BS_X_1)
        Me.GB_BS_X.ForeColor = System.Drawing.Color.Navy
        Me.GB_BS_X.Location = New System.Drawing.Point(6, 193)
        Me.GB_BS_X.Name = "GB_BS_X"
        Me.GB_BS_X.Size = New System.Drawing.Size(472, 56)
        Me.GB_BS_X.TabIndex = 27
        Me.GB_BS_X.TabStop = False
        Me.GB_BS_X.Text = "X (Bins)"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(95, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(11, 16)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "."
        '
        'txt_BS_X_Multiply00
        '
        Me.txt_BS_X_Multiply00.ArrowsIncrement = 1
        Me.txt_BS_X_Multiply00.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_BS_X_Multiply00.Increment = 1
        Me.txt_BS_X_Multiply00.Location = New System.Drawing.Point(105, 25)
        Me.txt_BS_X_Multiply00.MaxValue = 99
        Me.txt_BS_X_Multiply00.MinValue = -99
        Me.txt_BS_X_Multiply00.Name = "txt_BS_X_Multiply00"
        Me.txt_BS_X_Multiply00.NumericValue = 0
        Me.txt_BS_X_Multiply00.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_BS_X_Multiply00.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_BS_X_Multiply00.RoundingStep = 1
        Me.txt_BS_X_Multiply00.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_BS_X_Multiply00.Size = New System.Drawing.Size(25, 20)
        Me.txt_BS_X_Multiply00.TabIndex = 41
        Me.txt_BS_X_Multiply00.Text = "0"
        Me.txt_BS_X_Multiply00.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_BS_EnergyAdj
        '
        Me.chk_BS_EnergyAdj.AutoSize = True
        Me.chk_BS_EnergyAdj.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chk_BS_EnergyAdj.Location = New System.Drawing.Point(384, 26)
        Me.chk_BS_EnergyAdj.Name = "chk_BS_EnergyAdj"
        Me.chk_BS_EnergyAdj.Size = New System.Drawing.Size(80, 17)
        Me.chk_BS_EnergyAdj.TabIndex = 40
        Me.chk_BS_EnergyAdj.Text = "Energy Adj."
        Me.chk_BS_EnergyAdj.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(356, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(27, 13)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "KeV"
        '
        'lbl_BS_Offset
        '
        Me.lbl_BS_Offset.AutoSize = True
        Me.lbl_BS_Offset.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_BS_Offset.Location = New System.Drawing.Point(279, 27)
        Me.lbl_BS_Offset.Name = "lbl_BS_Offset"
        Me.lbl_BS_Offset.Size = New System.Drawing.Size(35, 13)
        Me.lbl_BS_Offset.TabIndex = 32
        Me.lbl_BS_Offset.Text = "Offset"
        '
        'txt_BS_Offset
        '
        Me.txt_BS_Offset.ArrowsIncrement = 1
        Me.txt_BS_Offset.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_BS_Offset.Increment = 1
        Me.txt_BS_Offset.Location = New System.Drawing.Point(321, 25)
        Me.txt_BS_Offset.MaxValue = 200
        Me.txt_BS_Offset.MinValue = -200
        Me.txt_BS_Offset.Name = "txt_BS_Offset"
        Me.txt_BS_Offset.NumericValue = 0
        Me.txt_BS_Offset.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_BS_Offset.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_BS_Offset.RoundingStep = 1
        Me.txt_BS_Offset.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_BS_Offset.Size = New System.Drawing.Size(34, 20)
        Me.txt_BS_Offset.TabIndex = 31
        Me.txt_BS_Offset.Text = "0"
        Me.txt_BS_Offset.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(130, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(20, 16)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "%"
        '
        'rad_BS_X_1_10
        '
        Me.rad_BS_X_1_10.AutoSize = True
        Me.rad_BS_X_1_10.Location = New System.Drawing.Point(118, 0)
        Me.rad_BS_X_1_10.Name = "rad_BS_X_1_10"
        Me.rad_BS_X_1_10.Size = New System.Drawing.Size(48, 17)
        Me.rad_BS_X_1_10.TabIndex = 29
        Me.rad_BS_X_1_10.Text = "1/10"
        Me.rad_BS_X_1_10.UseVisualStyleBackColor = True
        '
        'rad_BS_X_1_2
        '
        Me.rad_BS_X_1_2.AutoSize = True
        Me.rad_BS_X_1_2.Location = New System.Drawing.Point(168, 0)
        Me.rad_BS_X_1_2.Name = "rad_BS_X_1_2"
        Me.rad_BS_X_1_2.Size = New System.Drawing.Size(42, 17)
        Me.rad_BS_X_1_2.TabIndex = 28
        Me.rad_BS_X_1_2.Text = "1/2"
        Me.rad_BS_X_1_2.UseVisualStyleBackColor = True
        '
        'rad_BS_X_Auto
        '
        Me.rad_BS_X_Auto.AutoSize = True
        Me.rad_BS_X_Auto.Location = New System.Drawing.Point(65, 0)
        Me.rad_BS_X_Auto.Name = "rad_BS_X_Auto"
        Me.rad_BS_X_Auto.Size = New System.Drawing.Size(51, 17)
        Me.rad_BS_X_Auto.TabIndex = 26
        Me.rad_BS_X_Auto.Text = "Other"
        Me.rad_BS_X_Auto.UseVisualStyleBackColor = True
        '
        'tk_BS_X
        '
        Me.tk_BS_X.AutoSize = False
        Me.tk_BS_X.LargeChange = 1
        Me.tk_BS_X.Location = New System.Drawing.Point(149, 25)
        Me.tk_BS_X.Margin = New System.Windows.Forms.Padding(1)
        Me.tk_BS_X.Maximum = 37
        Me.tk_BS_X.Minimum = 1
        Me.tk_BS_X.Name = "tk_BS_X"
        Me.tk_BS_X.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.tk_BS_X.Size = New System.Drawing.Size(131, 26)
        Me.tk_BS_X.TabIndex = 23
        Me.tk_BS_X.TickFrequency = 2
        Me.tk_BS_X.Value = 1
        '
        'lbl_BS_X_Multiply
        '
        Me.lbl_BS_X_Multiply.AutoSize = True
        Me.lbl_BS_X_Multiply.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_BS_X_Multiply.Location = New System.Drawing.Point(8, 28)
        Me.lbl_BS_X_Multiply.Name = "lbl_BS_X_Multiply"
        Me.lbl_BS_X_Multiply.Size = New System.Drawing.Size(42, 13)
        Me.lbl_BS_X_Multiply.TabIndex = 21
        Me.lbl_BS_X_Multiply.Text = "Multiply"
        '
        'txt_BS_X_Multiply
        '
        Me.txt_BS_X_Multiply.ArrowsIncrement = 1
        Me.txt_BS_X_Multiply.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_BS_X_Multiply.Increment = 1
        Me.txt_BS_X_Multiply.Location = New System.Drawing.Point(58, 25)
        Me.txt_BS_X_Multiply.MaxValue = 10000
        Me.txt_BS_X_Multiply.MinValue = 1
        Me.txt_BS_X_Multiply.Name = "txt_BS_X_Multiply"
        Me.txt_BS_X_Multiply.NumericValue = 100
        Me.txt_BS_X_Multiply.NumericValueInteger = 100
        Me.txt_BS_X_Multiply.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_BS_X_Multiply.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_BS_X_Multiply.RoundingStep = 1
        Me.txt_BS_X_Multiply.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_BS_X_Multiply.Size = New System.Drawing.Size(40, 20)
        Me.txt_BS_X_Multiply.TabIndex = 20
        Me.txt_BS_X_Multiply.Text = "100"
        Me.txt_BS_X_Multiply.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'rad_BS_X_20
        '
        Me.rad_BS_X_20.AutoSize = True
        Me.rad_BS_X_20.Location = New System.Drawing.Point(390, 0)
        Me.rad_BS_X_20.Name = "rad_BS_X_20"
        Me.rad_BS_X_20.Size = New System.Drawing.Size(42, 17)
        Me.rad_BS_X_20.TabIndex = 14
        Me.rad_BS_X_20.Text = "x20"
        Me.rad_BS_X_20.UseVisualStyleBackColor = True
        '
        'rad_BS_X_10
        '
        Me.rad_BS_X_10.AutoSize = True
        Me.rad_BS_X_10.Location = New System.Drawing.Point(342, 0)
        Me.rad_BS_X_10.Name = "rad_BS_X_10"
        Me.rad_BS_X_10.Size = New System.Drawing.Size(42, 17)
        Me.rad_BS_X_10.TabIndex = 13
        Me.rad_BS_X_10.Text = "x10"
        Me.rad_BS_X_10.UseVisualStyleBackColor = True
        '
        'rad_BS_X_5
        '
        Me.rad_BS_X_5.AutoSize = True
        Me.rad_BS_X_5.Location = New System.Drawing.Point(300, 0)
        Me.rad_BS_X_5.Name = "rad_BS_X_5"
        Me.rad_BS_X_5.Size = New System.Drawing.Size(36, 17)
        Me.rad_BS_X_5.TabIndex = 12
        Me.rad_BS_X_5.Text = "x5"
        Me.rad_BS_X_5.UseVisualStyleBackColor = True
        '
        'rad_BS_X_2
        '
        Me.rad_BS_X_2.AutoSize = True
        Me.rad_BS_X_2.Location = New System.Drawing.Point(258, 0)
        Me.rad_BS_X_2.Name = "rad_BS_X_2"
        Me.rad_BS_X_2.Size = New System.Drawing.Size(36, 17)
        Me.rad_BS_X_2.TabIndex = 11
        Me.rad_BS_X_2.Text = "x2"
        Me.rad_BS_X_2.UseVisualStyleBackColor = True
        '
        'rad_BS_X_1
        '
        Me.rad_BS_X_1.AutoSize = True
        Me.rad_BS_X_1.Checked = True
        Me.rad_BS_X_1.Location = New System.Drawing.Point(216, 0)
        Me.rad_BS_X_1.Name = "rad_BS_X_1"
        Me.rad_BS_X_1.Size = New System.Drawing.Size(36, 17)
        Me.rad_BS_X_1.TabIndex = 10
        Me.rad_BS_X_1.TabStop = True
        Me.rad_BS_X_1.Text = "x1"
        Me.rad_BS_X_1.UseVisualStyleBackColor = True
        '
        'chk_BS_SPE
        '
        Me.chk_BS_SPE.AutoSize = True
        Me.chk_BS_SPE.Checked = True
        Me.chk_BS_SPE.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_BS_SPE.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chk_BS_SPE.Location = New System.Drawing.Point(123, 19)
        Me.chk_BS_SPE.Name = "chk_BS_SPE"
        Me.chk_BS_SPE.Size = New System.Drawing.Size(47, 17)
        Me.chk_BS_SPE.TabIndex = 24
        Me.chk_BS_SPE.Text = "SPE"
        Me.chk_BS_SPE.UseVisualStyleBackColor = True
        '
        'chk_BS_ThereminoMCA
        '
        Me.chk_BS_ThereminoMCA.AutoSize = True
        Me.chk_BS_ThereminoMCA.Checked = True
        Me.chk_BS_ThereminoMCA.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_BS_ThereminoMCA.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chk_BS_ThereminoMCA.Location = New System.Drawing.Point(15, 19)
        Me.chk_BS_ThereminoMCA.Name = "chk_BS_ThereminoMCA"
        Me.chk_BS_ThereminoMCA.Size = New System.Drawing.Size(102, 17)
        Me.chk_BS_ThereminoMCA.TabIndex = 15
        Me.chk_BS_ThereminoMCA.Text = "Theremino MCA"
        Me.chk_BS_ThereminoMCA.UseVisualStyleBackColor = True
        '
        'rad_BS_Y_Auto
        '
        Me.rad_BS_Y_Auto.AutoSize = True
        Me.rad_BS_Y_Auto.Location = New System.Drawing.Point(63, 0)
        Me.rad_BS_Y_Auto.Name = "rad_BS_Y_Auto"
        Me.rad_BS_Y_Auto.Size = New System.Drawing.Size(51, 17)
        Me.rad_BS_Y_Auto.TabIndex = 35
        Me.rad_BS_Y_Auto.Text = "Other"
        Me.rad_BS_Y_Auto.UseVisualStyleBackColor = True
        '
        'rad_BS_Y_1_2
        '
        Me.rad_BS_Y_1_2.AutoSize = True
        Me.rad_BS_Y_1_2.Location = New System.Drawing.Point(170, 0)
        Me.rad_BS_Y_1_2.Name = "rad_BS_Y_1_2"
        Me.rad_BS_Y_1_2.Size = New System.Drawing.Size(42, 17)
        Me.rad_BS_Y_1_2.TabIndex = 31
        Me.rad_BS_Y_1_2.Text = "1/2"
        Me.rad_BS_Y_1_2.UseVisualStyleBackColor = True
        '
        'rad_BS_Y_100
        '
        Me.rad_BS_Y_100.AutoSize = True
        Me.rad_BS_Y_100.Location = New System.Drawing.Point(353, 0)
        Me.rad_BS_Y_100.Name = "rad_BS_Y_100"
        Me.rad_BS_Y_100.Size = New System.Drawing.Size(48, 17)
        Me.rad_BS_Y_100.TabIndex = 30
        Me.rad_BS_Y_100.Text = "x100"
        Me.rad_BS_Y_100.UseVisualStyleBackColor = True
        '
        'GB_BS_Y
        '
        Me.GB_BS_Y.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GB_BS_Y.Controls.Add(Me.Label2)
        Me.GB_BS_Y.Controls.Add(Me.rad_BS_Y_1_10)
        Me.GB_BS_Y.Controls.Add(Me.rad_BS_Y_1)
        Me.GB_BS_Y.Controls.Add(Me.rad_BS_Y_2)
        Me.GB_BS_Y.Controls.Add(Me.tk_BS_Y)
        Me.GB_BS_Y.Controls.Add(Me.lbl_BS_Y_Multiply)
        Me.GB_BS_Y.Controls.Add(Me.txt_BS_Y_Multiply)
        Me.GB_BS_Y.Controls.Add(Me.rad_BS_Y_Auto)
        Me.GB_BS_Y.Controls.Add(Me.rad_BS_Y_100)
        Me.GB_BS_Y.Controls.Add(Me.rad_BS_Y_1_2)
        Me.GB_BS_Y.Controls.Add(Me.rad_BS_Y_10)
        Me.GB_BS_Y.ForeColor = System.Drawing.Color.Navy
        Me.GB_BS_Y.Location = New System.Drawing.Point(8, 255)
        Me.GB_BS_Y.Name = "GB_BS_Y"
        Me.GB_BS_Y.Size = New System.Drawing.Size(472, 56)
        Me.GB_BS_Y.TabIndex = 39
        Me.GB_BS_Y.TabStop = False
        Me.GB_BS_Y.Text = "Y (Counts)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(95, 25)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(20, 16)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "%"
        '
        'rad_BS_Y_1_10
        '
        Me.rad_BS_Y_1_10.AutoSize = True
        Me.rad_BS_Y_1_10.Location = New System.Drawing.Point(116, 0)
        Me.rad_BS_Y_1_10.Name = "rad_BS_Y_1_10"
        Me.rad_BS_Y_1_10.Size = New System.Drawing.Size(48, 17)
        Me.rad_BS_Y_1_10.TabIndex = 39
        Me.rad_BS_Y_1_10.Text = "1/10"
        Me.rad_BS_Y_1_10.UseVisualStyleBackColor = True
        '
        'rad_BS_Y_1
        '
        Me.rad_BS_Y_1.AutoSize = True
        Me.rad_BS_Y_1.Checked = True
        Me.rad_BS_Y_1.Location = New System.Drawing.Point(218, 0)
        Me.rad_BS_Y_1.Name = "rad_BS_Y_1"
        Me.rad_BS_Y_1.Size = New System.Drawing.Size(36, 17)
        Me.rad_BS_Y_1.TabIndex = 38
        Me.rad_BS_Y_1.TabStop = True
        Me.rad_BS_Y_1.Text = "x1"
        Me.rad_BS_Y_1.UseVisualStyleBackColor = True
        '
        'rad_BS_Y_2
        '
        Me.rad_BS_Y_2.AutoSize = True
        Me.rad_BS_Y_2.Location = New System.Drawing.Point(260, 0)
        Me.rad_BS_Y_2.Name = "rad_BS_Y_2"
        Me.rad_BS_Y_2.Size = New System.Drawing.Size(36, 17)
        Me.rad_BS_Y_2.TabIndex = 37
        Me.rad_BS_Y_2.Text = "x2"
        Me.rad_BS_Y_2.UseVisualStyleBackColor = True
        '
        'tk_BS_Y
        '
        Me.tk_BS_Y.AutoSize = False
        Me.tk_BS_Y.LargeChange = 1
        Me.tk_BS_Y.Location = New System.Drawing.Point(129, 23)
        Me.tk_BS_Y.Margin = New System.Windows.Forms.Padding(1)
        Me.tk_BS_Y.Maximum = 37
        Me.tk_BS_Y.Minimum = 1
        Me.tk_BS_Y.Name = "tk_BS_Y"
        Me.tk_BS_Y.Size = New System.Drawing.Size(151, 26)
        Me.tk_BS_Y.TabIndex = 23
        Me.tk_BS_Y.TickFrequency = 2
        Me.tk_BS_Y.Value = 1
        '
        'lbl_BS_Y_Multiply
        '
        Me.lbl_BS_Y_Multiply.AutoSize = True
        Me.lbl_BS_Y_Multiply.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_BS_Y_Multiply.Location = New System.Drawing.Point(8, 28)
        Me.lbl_BS_Y_Multiply.Name = "lbl_BS_Y_Multiply"
        Me.lbl_BS_Y_Multiply.Size = New System.Drawing.Size(42, 13)
        Me.lbl_BS_Y_Multiply.TabIndex = 21
        Me.lbl_BS_Y_Multiply.Text = "Multiply"
        '
        'txt_BS_Y_Multiply
        '
        Me.txt_BS_Y_Multiply.ArrowsIncrement = 1
        Me.txt_BS_Y_Multiply.BackColor_Over = System.Drawing.SystemColors.Window
        Me.txt_BS_Y_Multiply.Increment = 1
        Me.txt_BS_Y_Multiply.Location = New System.Drawing.Point(56, 24)
        Me.txt_BS_Y_Multiply.MaxValue = 10000
        Me.txt_BS_Y_Multiply.MinValue = 1
        Me.txt_BS_Y_Multiply.Name = "txt_BS_Y_Multiply"
        Me.txt_BS_Y_Multiply.NumericValue = 100
        Me.txt_BS_Y_Multiply.NumericValueInteger = 100
        Me.txt_BS_Y_Multiply.RectangleColor = System.Drawing.Color.Transparent
        Me.txt_BS_Y_Multiply.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.None
        Me.txt_BS_Y_Multiply.RoundingStep = 1
        Me.txt_BS_Y_Multiply.ShadowColor = System.Drawing.Color.Transparent
        Me.txt_BS_Y_Multiply.Size = New System.Drawing.Size(40, 20)
        Me.txt_BS_Y_Multiply.TabIndex = 20
        Me.txt_BS_Y_Multiply.Text = "100"
        Me.txt_BS_Y_Multiply.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'rad_BS_Y_10
        '
        Me.rad_BS_Y_10.AutoSize = True
        Me.rad_BS_Y_10.Location = New System.Drawing.Point(302, 0)
        Me.rad_BS_Y_10.Name = "rad_BS_Y_10"
        Me.rad_BS_Y_10.Size = New System.Drawing.Size(42, 17)
        Me.rad_BS_Y_10.TabIndex = 29
        Me.rad_BS_Y_10.Text = "x10"
        Me.rad_BS_Y_10.UseVisualStyleBackColor = True
        '
        'GB_BS_Format
        '
        Me.GB_BS_Format.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GB_BS_Format.Controls.Add(Me.btn_BS_Clear)
        Me.GB_BS_Format.Controls.Add(Me.btn_BS_All)
        Me.GB_BS_Format.Controls.Add(Me.chk_BS_ThereminoMCA)
        Me.GB_BS_Format.Controls.Add(Me.chk_BS_SPE)
        Me.GB_BS_Format.ForeColor = System.Drawing.Color.Navy
        Me.GB_BS_Format.Location = New System.Drawing.Point(8, 317)
        Me.GB_BS_Format.Name = "GB_BS_Format"
        Me.GB_BS_Format.Size = New System.Drawing.Size(472, 50)
        Me.GB_BS_Format.TabIndex = 40
        Me.GB_BS_Format.TabStop = False
        Me.GB_BS_Format.Text = "Format"
        '
        'btn_BS_Clear
        '
        Me.btn_BS_Clear.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker13.IsActive = False
        DesignerRectTracker13.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker13.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_Clear.CenterPtTracker = DesignerRectTracker13
        CBlendItems13.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems13.iPoint = New Single() {0.0!, -0.003021148!, 0.7643505!, 0.8036254!, 1.0!}
        Me.btn_BS_Clear.ColorFillBlend = CBlendItems13
        CBlendItems14.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems14.iPoint = New Single() {0.0!, 0.305136!, 1.0!}
        Me.btn_BS_Clear.ColorFillBlendChecked = CBlendItems14
        Me.btn_BS_Clear.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_Clear.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_Clear.Corners.All = CType(6, Short)
        Me.btn_BS_Clear.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_Clear.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_Clear.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_Clear.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_Clear.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_Clear.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_BS_Clear.FocalPoints.CenterPtX = 0.4909091!
        Me.btn_BS_Clear.FocalPoints.CenterPtY = 0.3529412!
        Me.btn_BS_Clear.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_Clear.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_Clear.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_Clear.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_Clear.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_Clear.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker14.IsActive = False
        DesignerRectTracker14.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker14.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_Clear.FocusPtTracker = DesignerRectTracker14
        Me.btn_BS_Clear.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_BS_Clear.Image = Nothing
        Me.btn_BS_Clear.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_Clear.ImageIndex = 0
        Me.btn_BS_Clear.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_Clear.Location = New System.Drawing.Point(347, 19)
        Me.btn_BS_Clear.Name = "btn_BS_Clear"
        Me.btn_BS_Clear.Shape = MyButton.eShape.Rectangle
        Me.btn_BS_Clear.SideImage = Nothing
        Me.btn_BS_Clear.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_Clear.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_Clear.Size = New System.Drawing.Size(55, 17)
        Me.btn_BS_Clear.TabIndex = 27
        Me.btn_BS_Clear.Text = "Clear"
        Me.btn_BS_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_Clear.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_Clear.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_Clear.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_BS_All
        '
        Me.btn_BS_All.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker15.IsActive = False
        DesignerRectTracker15.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker15.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_All.CenterPtTracker = DesignerRectTracker15
        Me.btn_BS_All.CheckButton = True
        CBlendItems15.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems15.iPoint = New Single() {0.0!, -0.003021148!, 0.7643505!, 0.8036254!, 1.0!}
        Me.btn_BS_All.ColorFillBlend = CBlendItems15
        CBlendItems16.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems16.iPoint = New Single() {0.0!, 0.305136!, 1.0!}
        Me.btn_BS_All.ColorFillBlendChecked = CBlendItems16
        Me.btn_BS_All.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_All.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_All.Corners.All = CType(6, Short)
        Me.btn_BS_All.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_All.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_All.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_All.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_All.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_All.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_BS_All.FocalPoints.CenterPtX = 0.4545455!
        Me.btn_BS_All.FocalPoints.CenterPtY = 0.4117647!
        Me.btn_BS_All.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_All.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_All.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_All.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_All.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_All.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker16.IsActive = False
        DesignerRectTracker16.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker16.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_All.FocusPtTracker = DesignerRectTracker16
        Me.btn_BS_All.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_BS_All.Image = Nothing
        Me.btn_BS_All.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_All.ImageIndex = 0
        Me.btn_BS_All.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_All.Location = New System.Drawing.Point(408, 19)
        Me.btn_BS_All.Name = "btn_BS_All"
        Me.btn_BS_All.Shape = MyButton.eShape.Rectangle
        Me.btn_BS_All.SideImage = Nothing
        Me.btn_BS_All.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_All.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_All.Size = New System.Drawing.Size(55, 17)
        Me.btn_BS_All.TabIndex = 26
        Me.btn_BS_All.Text = "All"
        Me.btn_BS_All.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_All.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_All.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_All.TextShadow = System.Drawing.Color.Transparent
        Me.btn_BS_All.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'GB_BS_Show
        '
        Me.GB_BS_Show.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GB_BS_Show.Controls.Add(Me.btn_BS_SetBase)
        Me.GB_BS_Show.Controls.Add(Me.btn_BS_SaveNow)
        Me.GB_BS_Show.Controls.Add(Me.rad_BS_Sub)
        Me.GB_BS_Show.Controls.Add(Me.rad_BS_Add)
        Me.GB_BS_Show.Controls.Add(Me.rad_BS_Difference)
        Me.GB_BS_Show.Controls.Add(Me.rad_BS_Sum)
        Me.GB_BS_Show.Controls.Add(Me.rad_BS_Normal)
        Me.GB_BS_Show.Controls.Add(Me.btn_BS_AutoSave)
        Me.GB_BS_Show.ForeColor = System.Drawing.Color.Navy
        Me.GB_BS_Show.Location = New System.Drawing.Point(8, 373)
        Me.GB_BS_Show.Name = "GB_BS_Show"
        Me.GB_BS_Show.Size = New System.Drawing.Size(472, 50)
        Me.GB_BS_Show.TabIndex = 41
        Me.GB_BS_Show.TabStop = False
        Me.GB_BS_Show.Text = "Show"
        '
        'btn_BS_SetBase
        '
        Me.btn_BS_SetBase.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker17.IsActive = False
        DesignerRectTracker17.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker17.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_SetBase.CenterPtTracker = DesignerRectTracker17
        CBlendItems17.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems17.iPoint = New Single() {0.0!, -0.003021148!, 0.7643505!, 0.8036254!, 1.0!}
        Me.btn_BS_SetBase.ColorFillBlend = CBlendItems17
        CBlendItems18.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems18.iPoint = New Single() {0.0!, 0.305136!, 1.0!}
        Me.btn_BS_SetBase.ColorFillBlendChecked = CBlendItems18
        Me.btn_BS_SetBase.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_SetBase.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_SetBase.Corners.All = CType(6, Short)
        Me.btn_BS_SetBase.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_SetBase.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_SetBase.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_SetBase.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_SetBase.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_SetBase.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_BS_SetBase.FocalPoints.CenterPtX = 0.8987342!
        Me.btn_BS_SetBase.FocalPoints.CenterPtY = 0.3529412!
        Me.btn_BS_SetBase.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_SetBase.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_SetBase.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_SetBase.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_SetBase.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_SetBase.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker18.IsActive = False
        DesignerRectTracker18.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker18.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_SetBase.FocusPtTracker = DesignerRectTracker18
        Me.btn_BS_SetBase.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_BS_SetBase.Image = Nothing
        Me.btn_BS_SetBase.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_SetBase.ImageIndex = 0
        Me.btn_BS_SetBase.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_SetBase.Location = New System.Drawing.Point(376, 23)
        Me.btn_BS_SetBase.Name = "btn_BS_SetBase"
        Me.btn_BS_SetBase.Shape = MyButton.eShape.Rectangle
        Me.btn_BS_SetBase.SideImage = Nothing
        Me.btn_BS_SetBase.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_SetBase.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_SetBase.Size = New System.Drawing.Size(90, 17)
        Me.btn_BS_SetBase.TabIndex = 38
        Me.btn_BS_SetBase.Text = "Set base"
        Me.btn_BS_SetBase.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_SetBase.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_SetBase.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_SetBase.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_BS_SaveNow
        '
        Me.btn_BS_SaveNow.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker19.IsActive = False
        DesignerRectTracker19.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker19.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_SaveNow.CenterPtTracker = DesignerRectTracker19
        CBlendItems19.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems19.iPoint = New Single() {0.0!, -0.003021148!, 0.7643505!, 0.8036254!, 1.0!}
        Me.btn_BS_SaveNow.ColorFillBlend = CBlendItems19
        CBlendItems20.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems20.iPoint = New Single() {0.0!, 0.305136!, 1.0!}
        Me.btn_BS_SaveNow.ColorFillBlendChecked = CBlendItems20
        Me.btn_BS_SaveNow.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_SaveNow.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_SaveNow.Corners.All = CType(6, Short)
        Me.btn_BS_SaveNow.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_SaveNow.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_SaveNow.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_SaveNow.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_SaveNow.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_SaveNow.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_BS_SaveNow.FocalPoints.CenterPtX = 0.9493671!
        Me.btn_BS_SaveNow.FocalPoints.CenterPtY = 0.4705882!
        Me.btn_BS_SaveNow.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_SaveNow.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_SaveNow.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_SaveNow.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_SaveNow.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_SaveNow.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker20.IsActive = False
        DesignerRectTracker20.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker20.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_SaveNow.FocusPtTracker = DesignerRectTracker20
        Me.btn_BS_SaveNow.Image = Nothing
        Me.btn_BS_SaveNow.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_SaveNow.ImageIndex = 0
        Me.btn_BS_SaveNow.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_SaveNow.Location = New System.Drawing.Point(201, 23)
        Me.btn_BS_SaveNow.Name = "btn_BS_SaveNow"
        Me.btn_BS_SaveNow.Shape = MyButton.eShape.Rectangle
        Me.btn_BS_SaveNow.SideImage = Nothing
        Me.btn_BS_SaveNow.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_SaveNow.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_SaveNow.Size = New System.Drawing.Size(79, 17)
        Me.btn_BS_SaveNow.TabIndex = 37
        Me.btn_BS_SaveNow.Text = "Save Now"
        Me.btn_BS_SaveNow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_SaveNow.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_SaveNow.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_SaveNow.TextShadow = System.Drawing.Color.Transparent
        '
        'rad_BS_Sub
        '
        Me.rad_BS_Sub.AutoSize = True
        Me.rad_BS_Sub.Location = New System.Drawing.Point(389, 0)
        Me.rad_BS_Sub.Name = "rad_BS_Sub"
        Me.rad_BS_Sub.Size = New System.Drawing.Size(65, 17)
        Me.rad_BS_Sub.TabIndex = 36
        Me.rad_BS_Sub.Text = "Subtract"
        Me.rad_BS_Sub.UseVisualStyleBackColor = True
        '
        'rad_BS_Add
        '
        Me.rad_BS_Add.AutoSize = True
        Me.rad_BS_Add.Location = New System.Drawing.Point(331, 0)
        Me.rad_BS_Add.Name = "rad_BS_Add"
        Me.rad_BS_Add.Size = New System.Drawing.Size(44, 17)
        Me.rad_BS_Add.TabIndex = 35
        Me.rad_BS_Add.Text = "Add"
        Me.rad_BS_Add.UseVisualStyleBackColor = True
        '
        'rad_BS_Difference
        '
        Me.rad_BS_Difference.AutoSize = True
        Me.rad_BS_Difference.Location = New System.Drawing.Point(192, 0)
        Me.rad_BS_Difference.Name = "rad_BS_Difference"
        Me.rad_BS_Difference.Size = New System.Drawing.Size(74, 17)
        Me.rad_BS_Difference.TabIndex = 33
        Me.rad_BS_Difference.Text = "Difference"
        Me.rad_BS_Difference.UseVisualStyleBackColor = True
        '
        'rad_BS_Sum
        '
        Me.rad_BS_Sum.AutoSize = True
        Me.rad_BS_Sum.Location = New System.Drawing.Point(129, 0)
        Me.rad_BS_Sum.Name = "rad_BS_Sum"
        Me.rad_BS_Sum.Size = New System.Drawing.Size(46, 17)
        Me.rad_BS_Sum.TabIndex = 34
        Me.rad_BS_Sum.Text = "Sum"
        Me.rad_BS_Sum.UseVisualStyleBackColor = True
        '
        'rad_BS_Normal
        '
        Me.rad_BS_Normal.AutoSize = True
        Me.rad_BS_Normal.Checked = True
        Me.rad_BS_Normal.Location = New System.Drawing.Point(55, 0)
        Me.rad_BS_Normal.Name = "rad_BS_Normal"
        Me.rad_BS_Normal.Size = New System.Drawing.Size(58, 17)
        Me.rad_BS_Normal.TabIndex = 32
        Me.rad_BS_Normal.TabStop = True
        Me.rad_BS_Normal.Text = "Normal"
        Me.rad_BS_Normal.UseVisualStyleBackColor = True
        '
        'btn_BS_AutoSave
        '
        Me.btn_BS_AutoSave.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker21.IsActive = False
        DesignerRectTracker21.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker21.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_AutoSave.CenterPtTracker = DesignerRectTracker21
        Me.btn_BS_AutoSave.CheckButton = True
        CBlendItems21.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems21.iPoint = New Single() {0.0!, -0.003021148!, 0.7643505!, 0.8036254!, 1.0!}
        Me.btn_BS_AutoSave.ColorFillBlend = CBlendItems21
        CBlendItems22.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems22.iPoint = New Single() {0.0!, 0.305136!, 1.0!}
        Me.btn_BS_AutoSave.ColorFillBlendChecked = CBlendItems22
        Me.btn_BS_AutoSave.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_AutoSave.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_AutoSave.Corners.All = CType(6, Short)
        Me.btn_BS_AutoSave.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_AutoSave.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_AutoSave.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_AutoSave.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_AutoSave.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_AutoSave.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_BS_AutoSave.FocalPoints.CenterPtX = 0.5090909!
        Me.btn_BS_AutoSave.FocalPoints.CenterPtY = 0.2352941!
        Me.btn_BS_AutoSave.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_AutoSave.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_AutoSave.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_AutoSave.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_AutoSave.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_AutoSave.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker22.IsActive = False
        DesignerRectTracker22.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker22.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_AutoSave.FocusPtTracker = DesignerRectTracker22
        Me.btn_BS_AutoSave.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_BS_AutoSave.Image = Nothing
        Me.btn_BS_AutoSave.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_AutoSave.ImageIndex = 0
        Me.btn_BS_AutoSave.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_AutoSave.Location = New System.Drawing.Point(31, 23)
        Me.btn_BS_AutoSave.Name = "btn_BS_AutoSave"
        Me.btn_BS_AutoSave.Shape = MyButton.eShape.Rectangle
        Me.btn_BS_AutoSave.SideImage = Nothing
        Me.btn_BS_AutoSave.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_AutoSave.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_AutoSave.Size = New System.Drawing.Size(156, 17)
        Me.btn_BS_AutoSave.TabIndex = 26
        Me.btn_BS_AutoSave.Text = "Automatically save results"
        Me.btn_BS_AutoSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_AutoSave.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_AutoSave.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_AutoSave.TextShadow = System.Drawing.Color.Transparent
        Me.btn_BS_AutoSave.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_BS_MoreOptions
        '
        Me.btn_BS_MoreOptions.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker23.IsActive = False
        DesignerRectTracker23.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker23.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_MoreOptions.CenterPtTracker = DesignerRectTracker23
        Me.btn_BS_MoreOptions.CheckButton = True
        CBlendItems23.iColor = New System.Drawing.Color() {System.Drawing.Color.AliceBlue, System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))}
        CBlendItems23.iPoint = New Single() {0.0!, -0.003021148!, 0.7643505!, 0.8036254!, 1.0!}
        Me.btn_BS_MoreOptions.ColorFillBlend = CBlendItems23
        CBlendItems24.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer))}
        CBlendItems24.iPoint = New Single() {0.0!, 0.305136!, 1.0!}
        Me.btn_BS_MoreOptions.ColorFillBlendChecked = CBlendItems24
        Me.btn_BS_MoreOptions.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BS_MoreOptions.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BS_MoreOptions.Corners.All = CType(6, Short)
        Me.btn_BS_MoreOptions.Corners.LowerLeft = CType(6, Short)
        Me.btn_BS_MoreOptions.Corners.LowerRight = CType(6, Short)
        Me.btn_BS_MoreOptions.Corners.UpperLeft = CType(6, Short)
        Me.btn_BS_MoreOptions.Corners.UpperRight = CType(6, Short)
        Me.btn_BS_MoreOptions.FillType = MyButton.eFillType.LinearVertical
        Me.btn_BS_MoreOptions.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_BS_MoreOptions.FocalPoints.CenterPtX = 0.5272727!
        Me.btn_BS_MoreOptions.FocalPoints.CenterPtY = 0.0!
        Me.btn_BS_MoreOptions.FocalPoints.FocusPtX = 0.0!
        Me.btn_BS_MoreOptions.FocalPoints.FocusPtY = 0.0!
        Me.btn_BS_MoreOptions.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_BS_MoreOptions.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BS_MoreOptions.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BS_MoreOptions.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker24.IsActive = False
        DesignerRectTracker24.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker24.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BS_MoreOptions.FocusPtTracker = DesignerRectTracker24
        Me.btn_BS_MoreOptions.ForeColor = System.Drawing.Color.Navy
        Me.btn_BS_MoreOptions.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_BS_MoreOptions.Image = Nothing
        Me.btn_BS_MoreOptions.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_MoreOptions.ImageIndex = 0
        Me.btn_BS_MoreOptions.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BS_MoreOptions.Location = New System.Drawing.Point(188, 174)
        Me.btn_BS_MoreOptions.Name = "btn_BS_MoreOptions"
        Me.btn_BS_MoreOptions.Shape = MyButton.eShape.Rectangle
        Me.btn_BS_MoreOptions.SideImage = Nothing
        Me.btn_BS_MoreOptions.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BS_MoreOptions.SideImageSize = New System.Drawing.Size(48, 48)
        Me.btn_BS_MoreOptions.Size = New System.Drawing.Size(95, 17)
        Me.btn_BS_MoreOptions.TabIndex = 28
        Me.btn_BS_MoreOptions.Text = "More options"
        Me.btn_BS_MoreOptions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BS_MoreOptions.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_BS_MoreOptions.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BS_MoreOptions.TextShadow = System.Drawing.Color.Transparent
        Me.btn_BS_MoreOptions.TextShadowChecked = System.Drawing.Color.Empty
        '
        'OpenFileDialog_BS
        '
        Me.OpenFileDialog_BS.Multiselect = True
        Me.OpenFileDialog_BS.ShowReadOnly = True
        '
        'AnimateTimer
        '
        '
        'Form_BSpectrum
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(485, 428)
        Me.Controls.Add(Me.btn_BS_MoreOptions)
        Me.Controls.Add(Me.GB_BS_Show)
        Me.Controls.Add(Me.GB_BS_Format)
        Me.Controls.Add(Me.GB_BS_Y)
        Me.Controls.Add(Me.GB_BS_X)
        Me.Controls.Add(Me.Group_BS_Details)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form_BSpectrum"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Browse Spectrum"
        Me.Group_BS_Details.ResumeLayout(False)
        Me.Group_BS_Details.PerformLayout()
        CType(Me.tk_BS_Index, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_BS_Speed, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GB_BS_X.ResumeLayout(False)
        Me.GB_BS_X.PerformLayout()
        CType(Me.tk_BS_X, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GB_BS_Y.ResumeLayout(False)
        Me.GB_BS_Y.PerformLayout()
        CType(Me.tk_BS_Y, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GB_BS_Format.ResumeLayout(False)
        Me.GB_BS_Format.PerformLayout()
        Me.GB_BS_Show.ResumeLayout(False)
        Me.GB_BS_Show.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Group_BS_Details As System.Windows.Forms.GroupBox
    Friend WithEvents btn_BS_Browse As System.Windows.Forms.Button
    Friend WithEvents txt_BS_Filename As System.Windows.Forms.TextBox
    Friend WithEvents txt_BS_Folder As System.Windows.Forms.TextBox
    Friend WithEvents FolderBrowserDialog_BS As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents btn_BS_CommitXY As System.Windows.Forms.Button
    Friend WithEvents btn_BS_Apply As System.Windows.Forms.Button
    Friend WithEvents rad_BS_Current As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_BKG As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Ref3 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Ref2 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Ref1 As System.Windows.Forms.RadioButton
    Friend WithEvents chk_BS_Repeat As System.Windows.Forms.CheckBox
    Friend WithEvents btn_BS_Forward As MyButton
    Friend WithEvents btn_BS_Back As MyButton
    Friend WithEvents btn_BS_Stop As MyButton
    Friend WithEvents tk_BS_Speed As System.Windows.Forms.TrackBar
    Friend WithEvents lbl_BS_Index As System.Windows.Forms.Label
    Friend WithEvents txt_BS_Index As MyTextBox
    Friend WithEvents btn_Help As MyButton
    Friend WithEvents tk_BS_Index As System.Windows.Forms.TrackBar
    Friend WithEvents chk_BS_RawData As System.Windows.Forms.CheckBox
    Friend WithEvents btn_BS_UseBKG As MyButton
    Friend WithEvents GB_BS_X As System.Windows.Forms.GroupBox
    Friend WithEvents chk_BS_SPE As System.Windows.Forms.CheckBox
    Friend WithEvents tk_BS_X As System.Windows.Forms.TrackBar
    Friend WithEvents lbl_BS_X_Multiply As System.Windows.Forms.Label
    Friend WithEvents txt_BS_X_Multiply As MyTextBox
    Friend WithEvents chk_BS_ThereminoMCA As System.Windows.Forms.CheckBox
    Friend WithEvents rad_BS_X_20 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_X_10 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_X_5 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_X_2 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_X_1 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_X_Auto As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Y_Auto As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Y_1_2 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Y_100 As System.Windows.Forms.RadioButton
    Friend WithEvents GB_BS_Y As System.Windows.Forms.GroupBox
    Friend WithEvents tk_BS_Y As System.Windows.Forms.TrackBar
    Friend WithEvents lbl_BS_Y_Multiply As System.Windows.Forms.Label
    Friend WithEvents txt_BS_Y_Multiply As MyTextBox
    Friend WithEvents GB_BS_Format As System.Windows.Forms.GroupBox
    Friend WithEvents btn_BS_Clear As MyButton
    Friend WithEvents btn_BS_All As MyButton
    Friend WithEvents GB_BS_Show As System.Windows.Forms.GroupBox
    Friend WithEvents rad_BS_Difference As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Sum As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Normal As System.Windows.Forms.RadioButton
    Friend WithEvents btn_BS_AutoSave As MyButton
    Friend WithEvents btn_BS_SaveNow As MyButton
    Friend WithEvents rad_BS_Sub As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Add As System.Windows.Forms.RadioButton
    Friend WithEvents btn_BS_SetBase As MyButton
    Friend WithEvents btn_BS_MoreOptions As MyButton
    Friend WithEvents rad_BS_Y_2 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Y_10 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Y_1 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_Y_1_10 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_X_1_10 As System.Windows.Forms.RadioButton
    Friend WithEvents rad_BS_X_1_2 As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbl_BS_Info As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog_BS As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lbl_BS_Offset As System.Windows.Forms.Label
    Friend WithEvents txt_BS_Offset As MyTextBox
    Friend WithEvents btn_BS_ShowHide As MyButton
    Friend WithEvents btn_BS_Filename As System.Windows.Forms.Button
    Friend WithEvents txt_BS_Speed As MyTextBox
    Friend WithEvents AnimateTimer As System.Windows.Forms.Timer
    Friend WithEvents lbl_BS_Speed As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents chk_BS_EnergyAdj As System.Windows.Forms.CheckBox
    Friend WithEvents btn_BS_CopyBack As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_BS_X_Multiply00 As MyTextBox
End Class
