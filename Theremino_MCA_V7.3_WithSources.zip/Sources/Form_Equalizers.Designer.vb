﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Equalizers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker11 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Equalizers))
        Dim CBlendItems11 As cBlendItems = New cBlendItems
        Dim CBlendItems12 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker12 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker3 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems3 As cBlendItems = New cBlendItems
        Dim CBlendItems4 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker4 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker5 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems5 As cBlendItems = New cBlendItems
        Dim CBlendItems6 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker6 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker7 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems7 As cBlendItems = New cBlendItems
        Dim CBlendItems8 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker8 As DesignerRectTracker = New DesignerRectTracker
        Me.GroupBox_EnergyLin = New System.Windows.Forms.GroupBox
        Me.txt_LinMax = New MyTextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txt_Lin8 = New MyTextBox
        Me.txt_Lin7 = New MyTextBox
        Me.txt_Lin6 = New MyTextBox
        Me.txt_Lin5 = New MyTextBox
        Me.txt_Lin4 = New MyTextBox
        Me.txt_Lin3 = New MyTextBox
        Me.txt_Lin2 = New MyTextBox
        Me.txt_Lin1 = New MyTextBox
        Me.txt_LinInterp = New MyTextBox
        Me.lbl_LinInterp = New System.Windows.Forms.Label
        Me.chk_LinOn = New System.Windows.Forms.CheckBox
        Me.tk_Lin8 = New System.Windows.Forms.TrackBar
        Me.tk_Lin7 = New System.Windows.Forms.TrackBar
        Me.tk_Lin6 = New System.Windows.Forms.TrackBar
        Me.tk_Lin5 = New System.Windows.Forms.TrackBar
        Me.tk_Lin4 = New System.Windows.Forms.TrackBar
        Me.tk_Lin3 = New System.Windows.Forms.TrackBar
        Me.btn_SaveLin = New MyButton
        Me.btn_LoadLin = New MyButton
        Me.tk_Lin2 = New System.Windows.Forms.TrackBar
        Me.tk_Lin1 = New System.Windows.Forms.TrackBar
        Me.GroupBox_HeightEq = New System.Windows.Forms.GroupBox
        Me.txt_EqMax = New MyTextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txt_Eq8 = New MyTextBox
        Me.txt_Eq7 = New MyTextBox
        Me.txt_Eq6 = New MyTextBox
        Me.txt_Eq5 = New MyTextBox
        Me.txt_Eq4 = New MyTextBox
        Me.txt_Eq3 = New MyTextBox
        Me.txt_Eq2 = New MyTextBox
        Me.txt_Eq1 = New MyTextBox
        Me.btn_TestFill1 = New MyButton
        Me.txt_EqInterp = New MyTextBox
        Me.lbl_EqInterp = New System.Windows.Forms.Label
        Me.chk_EqOn = New System.Windows.Forms.CheckBox
        Me.tk_Eq8 = New System.Windows.Forms.TrackBar
        Me.tk_Eq7 = New System.Windows.Forms.TrackBar
        Me.tk_Eq6 = New System.Windows.Forms.TrackBar
        Me.tk_Eq5 = New System.Windows.Forms.TrackBar
        Me.tk_Eq4 = New System.Windows.Forms.TrackBar
        Me.tk_Eq3 = New System.Windows.Forms.TrackBar
        Me.btn_SaveEq = New MyButton
        Me.btn_LoadEq = New MyButton
        Me.tk_Eq2 = New System.Windows.Forms.TrackBar
        Me.tk_Eq1 = New System.Windows.Forms.TrackBar
        Me.GroupBox_EnergyLin.SuspendLayout()
        CType(Me.tk_Lin8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Lin7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Lin6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Lin5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Lin4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Lin3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Lin2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Lin1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_HeightEq.SuspendLayout()
        CType(Me.tk_Eq8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Eq7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Eq6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Eq5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Eq4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Eq3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Eq2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Eq1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox_EnergyLin
        '
        Me.GroupBox_EnergyLin.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_LinMax)
        Me.GroupBox_EnergyLin.Controls.Add(Me.Label2)
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_Lin8)
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_Lin7)
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_Lin6)
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_Lin5)
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_Lin4)
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_Lin3)
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_Lin2)
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_Lin1)
        Me.GroupBox_EnergyLin.Controls.Add(Me.txt_LinInterp)
        Me.GroupBox_EnergyLin.Controls.Add(Me.lbl_LinInterp)
        Me.GroupBox_EnergyLin.Controls.Add(Me.chk_LinOn)
        Me.GroupBox_EnergyLin.Controls.Add(Me.tk_Lin8)
        Me.GroupBox_EnergyLin.Controls.Add(Me.tk_Lin7)
        Me.GroupBox_EnergyLin.Controls.Add(Me.tk_Lin6)
        Me.GroupBox_EnergyLin.Controls.Add(Me.tk_Lin5)
        Me.GroupBox_EnergyLin.Controls.Add(Me.tk_Lin4)
        Me.GroupBox_EnergyLin.Controls.Add(Me.tk_Lin3)
        Me.GroupBox_EnergyLin.Controls.Add(Me.btn_SaveLin)
        Me.GroupBox_EnergyLin.Controls.Add(Me.btn_LoadLin)
        Me.GroupBox_EnergyLin.Controls.Add(Me.tk_Lin2)
        Me.GroupBox_EnergyLin.Controls.Add(Me.tk_Lin1)
        Me.GroupBox_EnergyLin.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_EnergyLin.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_EnergyLin.Location = New System.Drawing.Point(5, 147)
        Me.GroupBox_EnergyLin.Name = "GroupBox_EnergyLin"
        Me.GroupBox_EnergyLin.Size = New System.Drawing.Size(385, 136)
        Me.GroupBox_EnergyLin.TabIndex = 166
        Me.GroupBox_EnergyLin.TabStop = False
        Me.GroupBox_EnergyLin.Text = "Energy Linearizer"
        '
        'txt_LinMax
        '
        Me.txt_LinMax.ArrowsIncrement = 1
        Me.txt_LinMax.BackColor = System.Drawing.Color.MintCream
        Me.txt_LinMax.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_LinMax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_LinMax.DimFactorGray = -20
        Me.txt_LinMax.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_LinMax.ForeColor = System.Drawing.Color.Black
        Me.txt_LinMax.Increment = 0.2
        Me.txt_LinMax.Location = New System.Drawing.Point(225, 1)
        Me.txt_LinMax.MaxValue = 100
        Me.txt_LinMax.MinValue = 1
        Me.txt_LinMax.Name = "txt_LinMax"
        Me.txt_LinMax.NumericValue = 10
        Me.txt_LinMax.NumericValueInteger = 10
        Me.txt_LinMax.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_LinMax.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_LinMax.RoundingStep = 1
        Me.txt_LinMax.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_LinMax.Size = New System.Drawing.Size(28, 15)
        Me.txt_LinMax.TabIndex = 207
        Me.txt_LinMax.Text = "10"
        Me.txt_LinMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(165, 1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 14)
        Me.Label2.TabIndex = 208
        Me.Label2.Text = "Max effect"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_Lin8
        '
        Me.txt_Lin8.ArrowsIncrement = 1
        Me.txt_Lin8.BackColor = System.Drawing.Color.MintCream
        Me.txt_Lin8.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Lin8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Lin8.DimFactorGray = -20
        Me.txt_Lin8.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Lin8.ForeColor = System.Drawing.Color.Black
        Me.txt_Lin8.Increment = 0.2
        Me.txt_Lin8.Location = New System.Drawing.Point(293, 116)
        Me.txt_Lin8.MaxValue = 4000
        Me.txt_Lin8.MinValue = 1000
        Me.txt_Lin8.Name = "txt_Lin8"
        Me.txt_Lin8.NumericValue = 2000
        Me.txt_Lin8.NumericValueInteger = 2000
        Me.txt_Lin8.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Lin8.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Lin8.RoundingStep = 0
        Me.txt_Lin8.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Lin8.Size = New System.Drawing.Size(32, 15)
        Me.txt_Lin8.TabIndex = 206
        Me.txt_Lin8.Text = "2000"
        Me.txt_Lin8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Lin7
        '
        Me.txt_Lin7.ArrowsIncrement = 1
        Me.txt_Lin7.BackColor = System.Drawing.Color.MintCream
        Me.txt_Lin7.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Lin7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Lin7.DimFactorGray = -20
        Me.txt_Lin7.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Lin7.ForeColor = System.Drawing.Color.Black
        Me.txt_Lin7.Increment = 0.2
        Me.txt_Lin7.Location = New System.Drawing.Point(254, 116)
        Me.txt_Lin7.MaxValue = 2000
        Me.txt_Lin7.MinValue = 500
        Me.txt_Lin7.Name = "txt_Lin7"
        Me.txt_Lin7.NumericValue = 1000
        Me.txt_Lin7.NumericValueInteger = 1000
        Me.txt_Lin7.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Lin7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Lin7.RoundingStep = 0
        Me.txt_Lin7.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Lin7.Size = New System.Drawing.Size(32, 15)
        Me.txt_Lin7.TabIndex = 205
        Me.txt_Lin7.Text = "1000"
        Me.txt_Lin7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Lin6
        '
        Me.txt_Lin6.ArrowsIncrement = 1
        Me.txt_Lin6.BackColor = System.Drawing.Color.MintCream
        Me.txt_Lin6.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Lin6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Lin6.DimFactorGray = -20
        Me.txt_Lin6.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Lin6.ForeColor = System.Drawing.Color.Black
        Me.txt_Lin6.Increment = 0.2
        Me.txt_Lin6.Location = New System.Drawing.Point(214, 116)
        Me.txt_Lin6.MaxValue = 1000
        Me.txt_Lin6.MinValue = 250
        Me.txt_Lin6.Name = "txt_Lin6"
        Me.txt_Lin6.NumericValue = 500
        Me.txt_Lin6.NumericValueInteger = 500
        Me.txt_Lin6.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Lin6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Lin6.RoundingStep = 0
        Me.txt_Lin6.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Lin6.Size = New System.Drawing.Size(32, 15)
        Me.txt_Lin6.TabIndex = 204
        Me.txt_Lin6.Text = "500"
        Me.txt_Lin6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Lin5
        '
        Me.txt_Lin5.ArrowsIncrement = 1
        Me.txt_Lin5.BackColor = System.Drawing.Color.MintCream
        Me.txt_Lin5.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Lin5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Lin5.DimFactorGray = -20
        Me.txt_Lin5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Lin5.ForeColor = System.Drawing.Color.Black
        Me.txt_Lin5.Increment = 0.2
        Me.txt_Lin5.Location = New System.Drawing.Point(172, 116)
        Me.txt_Lin5.MaxValue = 400
        Me.txt_Lin5.MinValue = 100
        Me.txt_Lin5.Name = "txt_Lin5"
        Me.txt_Lin5.NumericValue = 200
        Me.txt_Lin5.NumericValueInteger = 200
        Me.txt_Lin5.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Lin5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Lin5.RoundingStep = 0
        Me.txt_Lin5.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Lin5.Size = New System.Drawing.Size(32, 15)
        Me.txt_Lin5.TabIndex = 203
        Me.txt_Lin5.Text = "200"
        Me.txt_Lin5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Lin4
        '
        Me.txt_Lin4.ArrowsIncrement = 1
        Me.txt_Lin4.BackColor = System.Drawing.Color.MintCream
        Me.txt_Lin4.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Lin4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Lin4.DimFactorGray = -20
        Me.txt_Lin4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Lin4.ForeColor = System.Drawing.Color.Black
        Me.txt_Lin4.Increment = 0.2
        Me.txt_Lin4.Location = New System.Drawing.Point(131, 116)
        Me.txt_Lin4.MaxValue = 200
        Me.txt_Lin4.MinValue = 50
        Me.txt_Lin4.Name = "txt_Lin4"
        Me.txt_Lin4.NumericValue = 100
        Me.txt_Lin4.NumericValueInteger = 100
        Me.txt_Lin4.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Lin4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Lin4.RoundingStep = 0
        Me.txt_Lin4.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Lin4.Size = New System.Drawing.Size(32, 15)
        Me.txt_Lin4.TabIndex = 202
        Me.txt_Lin4.Text = "100"
        Me.txt_Lin4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Lin3
        '
        Me.txt_Lin3.ArrowsIncrement = 1
        Me.txt_Lin3.BackColor = System.Drawing.Color.MintCream
        Me.txt_Lin3.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Lin3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Lin3.DimFactorGray = -20
        Me.txt_Lin3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Lin3.ForeColor = System.Drawing.Color.Black
        Me.txt_Lin3.Increment = 0.2
        Me.txt_Lin3.Location = New System.Drawing.Point(89, 116)
        Me.txt_Lin3.MaxValue = 100
        Me.txt_Lin3.MinValue = 25
        Me.txt_Lin3.Name = "txt_Lin3"
        Me.txt_Lin3.NumericValue = 50
        Me.txt_Lin3.NumericValueInteger = 50
        Me.txt_Lin3.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Lin3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Lin3.RoundingStep = 0
        Me.txt_Lin3.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Lin3.Size = New System.Drawing.Size(32, 15)
        Me.txt_Lin3.TabIndex = 201
        Me.txt_Lin3.Text = "50"
        Me.txt_Lin3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Lin2
        '
        Me.txt_Lin2.ArrowsIncrement = 1
        Me.txt_Lin2.BackColor = System.Drawing.Color.MintCream
        Me.txt_Lin2.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Lin2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Lin2.DimFactorGray = -20
        Me.txt_Lin2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Lin2.ForeColor = System.Drawing.Color.Black
        Me.txt_Lin2.Increment = 0.2
        Me.txt_Lin2.Location = New System.Drawing.Point(49, 116)
        Me.txt_Lin2.MaxValue = 40
        Me.txt_Lin2.MinValue = 10
        Me.txt_Lin2.Name = "txt_Lin2"
        Me.txt_Lin2.NumericValue = 20
        Me.txt_Lin2.NumericValueInteger = 20
        Me.txt_Lin2.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Lin2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Lin2.RoundingStep = 0
        Me.txt_Lin2.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Lin2.Size = New System.Drawing.Size(32, 15)
        Me.txt_Lin2.TabIndex = 200
        Me.txt_Lin2.Text = "20"
        Me.txt_Lin2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Lin1
        '
        Me.txt_Lin1.ArrowsIncrement = 1
        Me.txt_Lin1.BackColor = System.Drawing.Color.MintCream
        Me.txt_Lin1.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Lin1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Lin1.DimFactorGray = -20
        Me.txt_Lin1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Lin1.ForeColor = System.Drawing.Color.Black
        Me.txt_Lin1.Increment = 0.2
        Me.txt_Lin1.Location = New System.Drawing.Point(8, 116)
        Me.txt_Lin1.MaxValue = 20
        Me.txt_Lin1.MinValue = 5
        Me.txt_Lin1.Name = "txt_Lin1"
        Me.txt_Lin1.NumericValue = 10
        Me.txt_Lin1.NumericValueInteger = 10
        Me.txt_Lin1.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Lin1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Lin1.RoundingStep = 0
        Me.txt_Lin1.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Lin1.Size = New System.Drawing.Size(32, 15)
        Me.txt_Lin1.TabIndex = 199
        Me.txt_Lin1.Text = "10"
        Me.txt_Lin1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_LinInterp
        '
        Me.txt_LinInterp.ArrowsIncrement = 10
        Me.txt_LinInterp.BackColor = System.Drawing.Color.MintCream
        Me.txt_LinInterp.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_LinInterp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_LinInterp.DimFactorGray = -20
        Me.txt_LinInterp.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_LinInterp.ForeColor = System.Drawing.Color.Black
        Me.txt_LinInterp.Increment = 2
        Me.txt_LinInterp.Location = New System.Drawing.Point(343, 0)
        Me.txt_LinInterp.MaxValue = 100
        Me.txt_LinInterp.MinValue = 0
        Me.txt_LinInterp.Name = "txt_LinInterp"
        Me.txt_LinInterp.NumericValue = 50
        Me.txt_LinInterp.NumericValueInteger = 50
        Me.txt_LinInterp.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_LinInterp.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_LinInterp.RoundingStep = 10
        Me.txt_LinInterp.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_LinInterp.Size = New System.Drawing.Size(32, 15)
        Me.txt_LinInterp.TabIndex = 192
        Me.txt_LinInterp.Text = "50"
        Me.txt_LinInterp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_LinInterp
        '
        Me.lbl_LinInterp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_LinInterp.ForeColor = System.Drawing.Color.Black
        Me.lbl_LinInterp.Location = New System.Drawing.Point(269, 1)
        Me.lbl_LinInterp.Name = "lbl_LinInterp"
        Me.lbl_LinInterp.Size = New System.Drawing.Size(80, 14)
        Me.lbl_LinInterp.TabIndex = 193
        Me.lbl_LinInterp.Text = "Cubical interp."
        Me.lbl_LinInterp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chk_LinOn
        '
        Me.chk_LinOn.AutoSize = True
        Me.chk_LinOn.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_LinOn.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_LinOn.Location = New System.Drawing.Point(334, 114)
        Me.chk_LinOn.Name = "chk_LinOn"
        Me.chk_LinOn.Size = New System.Drawing.Size(41, 18)
        Me.chk_LinOn.TabIndex = 190
        Me.chk_LinOn.Text = "ON"
        Me.chk_LinOn.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.chk_LinOn.UseVisualStyleBackColor = True
        '
        'tk_Lin8
        '
        Me.tk_Lin8.AutoSize = False
        Me.tk_Lin8.Location = New System.Drawing.Point(292, 18)
        Me.tk_Lin8.Maximum = 1000
        Me.tk_Lin8.Minimum = -1000
        Me.tk_Lin8.Name = "tk_Lin8"
        Me.tk_Lin8.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Lin8.Size = New System.Drawing.Size(43, 103)
        Me.tk_Lin8.TabIndex = 168
        Me.tk_Lin8.TickFrequency = 200
        Me.tk_Lin8.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Lin7
        '
        Me.tk_Lin7.AutoSize = False
        Me.tk_Lin7.Location = New System.Drawing.Point(252, 18)
        Me.tk_Lin7.Maximum = 1000
        Me.tk_Lin7.Minimum = -1000
        Me.tk_Lin7.Name = "tk_Lin7"
        Me.tk_Lin7.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Lin7.Size = New System.Drawing.Size(43, 103)
        Me.tk_Lin7.TabIndex = 167
        Me.tk_Lin7.TickFrequency = 200
        Me.tk_Lin7.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Lin6
        '
        Me.tk_Lin6.AutoSize = False
        Me.tk_Lin6.Location = New System.Drawing.Point(210, 18)
        Me.tk_Lin6.Maximum = 1000
        Me.tk_Lin6.Minimum = -1000
        Me.tk_Lin6.Name = "tk_Lin6"
        Me.tk_Lin6.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Lin6.Size = New System.Drawing.Size(43, 103)
        Me.tk_Lin6.TabIndex = 166
        Me.tk_Lin6.TickFrequency = 200
        Me.tk_Lin6.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Lin5
        '
        Me.tk_Lin5.AutoSize = False
        Me.tk_Lin5.Location = New System.Drawing.Point(169, 18)
        Me.tk_Lin5.Maximum = 1000
        Me.tk_Lin5.Minimum = -1000
        Me.tk_Lin5.Name = "tk_Lin5"
        Me.tk_Lin5.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Lin5.Size = New System.Drawing.Size(43, 103)
        Me.tk_Lin5.TabIndex = 165
        Me.tk_Lin5.TickFrequency = 200
        Me.tk_Lin5.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Lin4
        '
        Me.tk_Lin4.AutoSize = False
        Me.tk_Lin4.Location = New System.Drawing.Point(128, 18)
        Me.tk_Lin4.Maximum = 1000
        Me.tk_Lin4.Minimum = -1000
        Me.tk_Lin4.Name = "tk_Lin4"
        Me.tk_Lin4.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Lin4.Size = New System.Drawing.Size(43, 103)
        Me.tk_Lin4.TabIndex = 164
        Me.tk_Lin4.TickFrequency = 200
        Me.tk_Lin4.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Lin3
        '
        Me.tk_Lin3.AutoSize = False
        Me.tk_Lin3.Location = New System.Drawing.Point(87, 18)
        Me.tk_Lin3.Maximum = 1000
        Me.tk_Lin3.Minimum = -1000
        Me.tk_Lin3.Name = "tk_Lin3"
        Me.tk_Lin3.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Lin3.Size = New System.Drawing.Size(43, 103)
        Me.tk_Lin3.TabIndex = 163
        Me.tk_Lin3.TickFrequency = 200
        Me.tk_Lin3.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'btn_SaveLin
        '
        Me.btn_SaveLin.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SaveLin.CenterPtTracker = DesignerRectTracker11
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_SaveLin.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_SaveLin.ColorFillBlendChecked = CBlendItems12
        Me.btn_SaveLin.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_SaveLin.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_SaveLin.Corners.All = CType(6, Short)
        Me.btn_SaveLin.Corners.LowerLeft = CType(6, Short)
        Me.btn_SaveLin.Corners.LowerRight = CType(6, Short)
        Me.btn_SaveLin.Corners.UpperLeft = CType(6, Short)
        Me.btn_SaveLin.Corners.UpperRight = CType(6, Short)
        Me.btn_SaveLin.DimFactorGray = -10
        Me.btn_SaveLin.DimFactorOver = 30
        Me.btn_SaveLin.FillType = MyButton.eFillType.LinearVertical
        Me.btn_SaveLin.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_SaveLin.FocalPoints.CenterPtX = 1.0!
        Me.btn_SaveLin.FocalPoints.CenterPtY = 1.0!
        Me.btn_SaveLin.FocalPoints.FocusPtX = 0.0!
        Me.btn_SaveLin.FocalPoints.FocusPtY = 0.0!
        Me.btn_SaveLin.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_SaveLin.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_SaveLin.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_SaveLin.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SaveLin.FocusPtTracker = DesignerRectTracker12
        Me.btn_SaveLin.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SaveLin.Image = Nothing
        Me.btn_SaveLin.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SaveLin.ImageIndex = 0
        Me.btn_SaveLin.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_SaveLin.Location = New System.Drawing.Point(341, 53)
        Me.btn_SaveLin.Name = "btn_SaveLin"
        Me.btn_SaveLin.Shape = MyButton.eShape.Rectangle
        Me.btn_SaveLin.SideImage = Nothing
        Me.btn_SaveLin.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SaveLin.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_SaveLin.Size = New System.Drawing.Size(36, 18)
        Me.btn_SaveLin.TabIndex = 161
        Me.btn_SaveLin.TabStop = False
        Me.btn_SaveLin.Text = "Save"
        Me.btn_SaveLin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SaveLin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_SaveLin.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_SaveLin.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_LoadLin
        '
        Me.btn_LoadLin.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LoadLin.CenterPtTracker = DesignerRectTracker1
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_LoadLin.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_LoadLin.ColorFillBlendChecked = CBlendItems2
        Me.btn_LoadLin.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_LoadLin.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_LoadLin.Corners.All = CType(6, Short)
        Me.btn_LoadLin.Corners.LowerLeft = CType(6, Short)
        Me.btn_LoadLin.Corners.LowerRight = CType(6, Short)
        Me.btn_LoadLin.Corners.UpperLeft = CType(6, Short)
        Me.btn_LoadLin.Corners.UpperRight = CType(6, Short)
        Me.btn_LoadLin.DimFactorGray = -10
        Me.btn_LoadLin.DimFactorOver = 30
        Me.btn_LoadLin.FillType = MyButton.eFillType.LinearVertical
        Me.btn_LoadLin.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_LoadLin.FocalPoints.CenterPtX = 1.0!
        Me.btn_LoadLin.FocalPoints.CenterPtY = 1.0!
        Me.btn_LoadLin.FocalPoints.FocusPtX = 0.0!
        Me.btn_LoadLin.FocalPoints.FocusPtY = 0.0!
        Me.btn_LoadLin.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_LoadLin.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_LoadLin.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_LoadLin.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LoadLin.FocusPtTracker = DesignerRectTracker2
        Me.btn_LoadLin.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_LoadLin.Image = Nothing
        Me.btn_LoadLin.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadLin.ImageIndex = 0
        Me.btn_LoadLin.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_LoadLin.Location = New System.Drawing.Point(341, 30)
        Me.btn_LoadLin.Name = "btn_LoadLin"
        Me.btn_LoadLin.Shape = MyButton.eShape.Rectangle
        Me.btn_LoadLin.SideImage = Nothing
        Me.btn_LoadLin.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadLin.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_LoadLin.Size = New System.Drawing.Size(36, 18)
        Me.btn_LoadLin.TabIndex = 160
        Me.btn_LoadLin.TabStop = False
        Me.btn_LoadLin.Text = "Load"
        Me.btn_LoadLin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadLin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_LoadLin.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_LoadLin.TextShadow = System.Drawing.Color.Transparent
        '
        'tk_Lin2
        '
        Me.tk_Lin2.AutoSize = False
        Me.tk_Lin2.Location = New System.Drawing.Point(46, 18)
        Me.tk_Lin2.Maximum = 1000
        Me.tk_Lin2.Minimum = -1000
        Me.tk_Lin2.Name = "tk_Lin2"
        Me.tk_Lin2.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Lin2.Size = New System.Drawing.Size(43, 103)
        Me.tk_Lin2.TabIndex = 159
        Me.tk_Lin2.TickFrequency = 200
        Me.tk_Lin2.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Lin1
        '
        Me.tk_Lin1.AutoSize = False
        Me.tk_Lin1.Location = New System.Drawing.Point(5, 18)
        Me.tk_Lin1.Maximum = 1000
        Me.tk_Lin1.Minimum = -1000
        Me.tk_Lin1.Name = "tk_Lin1"
        Me.tk_Lin1.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Lin1.Size = New System.Drawing.Size(43, 103)
        Me.tk_Lin1.TabIndex = 157
        Me.tk_Lin1.TickFrequency = 200
        Me.tk_Lin1.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'GroupBox_HeightEq
        '
        Me.GroupBox_HeightEq.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_EqMax)
        Me.GroupBox_HeightEq.Controls.Add(Me.Label1)
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_Eq8)
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_Eq7)
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_Eq6)
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_Eq5)
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_Eq4)
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_Eq3)
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_Eq2)
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_Eq1)
        Me.GroupBox_HeightEq.Controls.Add(Me.btn_TestFill1)
        Me.GroupBox_HeightEq.Controls.Add(Me.txt_EqInterp)
        Me.GroupBox_HeightEq.Controls.Add(Me.lbl_EqInterp)
        Me.GroupBox_HeightEq.Controls.Add(Me.chk_EqOn)
        Me.GroupBox_HeightEq.Controls.Add(Me.tk_Eq8)
        Me.GroupBox_HeightEq.Controls.Add(Me.tk_Eq7)
        Me.GroupBox_HeightEq.Controls.Add(Me.tk_Eq6)
        Me.GroupBox_HeightEq.Controls.Add(Me.tk_Eq5)
        Me.GroupBox_HeightEq.Controls.Add(Me.tk_Eq4)
        Me.GroupBox_HeightEq.Controls.Add(Me.tk_Eq3)
        Me.GroupBox_HeightEq.Controls.Add(Me.btn_SaveEq)
        Me.GroupBox_HeightEq.Controls.Add(Me.btn_LoadEq)
        Me.GroupBox_HeightEq.Controls.Add(Me.tk_Eq2)
        Me.GroupBox_HeightEq.Controls.Add(Me.tk_Eq1)
        Me.GroupBox_HeightEq.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_HeightEq.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_HeightEq.Location = New System.Drawing.Point(5, 6)
        Me.GroupBox_HeightEq.Name = "GroupBox_HeightEq"
        Me.GroupBox_HeightEq.Size = New System.Drawing.Size(385, 136)
        Me.GroupBox_HeightEq.TabIndex = 167
        Me.GroupBox_HeightEq.TabStop = False
        Me.GroupBox_HeightEq.Text = "Height Equalizer"
        '
        'txt_EqMax
        '
        Me.txt_EqMax.ArrowsIncrement = 1
        Me.txt_EqMax.BackColor = System.Drawing.Color.MintCream
        Me.txt_EqMax.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_EqMax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_EqMax.DimFactorGray = -20
        Me.txt_EqMax.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_EqMax.ForeColor = System.Drawing.Color.Black
        Me.txt_EqMax.Increment = 0.2
        Me.txt_EqMax.Location = New System.Drawing.Point(225, 1)
        Me.txt_EqMax.MaxValue = 100
        Me.txt_EqMax.MinValue = 1
        Me.txt_EqMax.Name = "txt_EqMax"
        Me.txt_EqMax.NumericValue = 10
        Me.txt_EqMax.NumericValueInteger = 10
        Me.txt_EqMax.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_EqMax.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_EqMax.RoundingStep = 1
        Me.txt_EqMax.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_EqMax.Size = New System.Drawing.Size(28, 15)
        Me.txt_EqMax.TabIndex = 199
        Me.txt_EqMax.Text = "10"
        Me.txt_EqMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(165, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 14)
        Me.Label1.TabIndex = 200
        Me.Label1.Text = "Max effect"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_Eq8
        '
        Me.txt_Eq8.ArrowsIncrement = 1
        Me.txt_Eq8.BackColor = System.Drawing.Color.MintCream
        Me.txt_Eq8.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Eq8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Eq8.DimFactorGray = -20
        Me.txt_Eq8.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Eq8.ForeColor = System.Drawing.Color.Black
        Me.txt_Eq8.Increment = 0.2
        Me.txt_Eq8.Location = New System.Drawing.Point(293, 115)
        Me.txt_Eq8.MaxValue = 4000
        Me.txt_Eq8.MinValue = 1000
        Me.txt_Eq8.Name = "txt_Eq8"
        Me.txt_Eq8.NumericValue = 2000
        Me.txt_Eq8.NumericValueInteger = 2000
        Me.txt_Eq8.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Eq8.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Eq8.RoundingStep = 0
        Me.txt_Eq8.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Eq8.Size = New System.Drawing.Size(32, 15)
        Me.txt_Eq8.TabIndex = 198
        Me.txt_Eq8.Text = "2000"
        Me.txt_Eq8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Eq7
        '
        Me.txt_Eq7.ArrowsIncrement = 1
        Me.txt_Eq7.BackColor = System.Drawing.Color.MintCream
        Me.txt_Eq7.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Eq7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Eq7.DimFactorGray = -20
        Me.txt_Eq7.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Eq7.ForeColor = System.Drawing.Color.Black
        Me.txt_Eq7.Increment = 0.2
        Me.txt_Eq7.Location = New System.Drawing.Point(254, 115)
        Me.txt_Eq7.MaxValue = 2000
        Me.txt_Eq7.MinValue = 500
        Me.txt_Eq7.Name = "txt_Eq7"
        Me.txt_Eq7.NumericValue = 1000
        Me.txt_Eq7.NumericValueInteger = 1000
        Me.txt_Eq7.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Eq7.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Eq7.RoundingStep = 0
        Me.txt_Eq7.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Eq7.Size = New System.Drawing.Size(32, 15)
        Me.txt_Eq7.TabIndex = 197
        Me.txt_Eq7.Text = "1000"
        Me.txt_Eq7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Eq6
        '
        Me.txt_Eq6.ArrowsIncrement = 1
        Me.txt_Eq6.BackColor = System.Drawing.Color.MintCream
        Me.txt_Eq6.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Eq6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Eq6.DimFactorGray = -20
        Me.txt_Eq6.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Eq6.ForeColor = System.Drawing.Color.Black
        Me.txt_Eq6.Increment = 0.2
        Me.txt_Eq6.Location = New System.Drawing.Point(214, 115)
        Me.txt_Eq6.MaxValue = 1000
        Me.txt_Eq6.MinValue = 250
        Me.txt_Eq6.Name = "txt_Eq6"
        Me.txt_Eq6.NumericValue = 500
        Me.txt_Eq6.NumericValueInteger = 500
        Me.txt_Eq6.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Eq6.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Eq6.RoundingStep = 0
        Me.txt_Eq6.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Eq6.Size = New System.Drawing.Size(32, 15)
        Me.txt_Eq6.TabIndex = 196
        Me.txt_Eq6.Text = "500"
        Me.txt_Eq6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Eq5
        '
        Me.txt_Eq5.ArrowsIncrement = 1
        Me.txt_Eq5.BackColor = System.Drawing.Color.MintCream
        Me.txt_Eq5.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Eq5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Eq5.DimFactorGray = -20
        Me.txt_Eq5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Eq5.ForeColor = System.Drawing.Color.Black
        Me.txt_Eq5.Increment = 0.2
        Me.txt_Eq5.Location = New System.Drawing.Point(172, 115)
        Me.txt_Eq5.MaxValue = 400
        Me.txt_Eq5.MinValue = 100
        Me.txt_Eq5.Name = "txt_Eq5"
        Me.txt_Eq5.NumericValue = 200
        Me.txt_Eq5.NumericValueInteger = 200
        Me.txt_Eq5.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Eq5.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Eq5.RoundingStep = 0
        Me.txt_Eq5.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Eq5.Size = New System.Drawing.Size(32, 15)
        Me.txt_Eq5.TabIndex = 195
        Me.txt_Eq5.Text = "200"
        Me.txt_Eq5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Eq4
        '
        Me.txt_Eq4.ArrowsIncrement = 1
        Me.txt_Eq4.BackColor = System.Drawing.Color.MintCream
        Me.txt_Eq4.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Eq4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Eq4.DimFactorGray = -20
        Me.txt_Eq4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Eq4.ForeColor = System.Drawing.Color.Black
        Me.txt_Eq4.Increment = 0.2
        Me.txt_Eq4.Location = New System.Drawing.Point(131, 115)
        Me.txt_Eq4.MaxValue = 200
        Me.txt_Eq4.MinValue = 50
        Me.txt_Eq4.Name = "txt_Eq4"
        Me.txt_Eq4.NumericValue = 100
        Me.txt_Eq4.NumericValueInteger = 100
        Me.txt_Eq4.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Eq4.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Eq4.RoundingStep = 0
        Me.txt_Eq4.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Eq4.Size = New System.Drawing.Size(32, 15)
        Me.txt_Eq4.TabIndex = 194
        Me.txt_Eq4.Text = "100"
        Me.txt_Eq4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Eq3
        '
        Me.txt_Eq3.ArrowsIncrement = 1
        Me.txt_Eq3.BackColor = System.Drawing.Color.MintCream
        Me.txt_Eq3.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Eq3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Eq3.DimFactorGray = -20
        Me.txt_Eq3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Eq3.ForeColor = System.Drawing.Color.Black
        Me.txt_Eq3.Increment = 0.2
        Me.txt_Eq3.Location = New System.Drawing.Point(89, 115)
        Me.txt_Eq3.MaxValue = 100
        Me.txt_Eq3.MinValue = 25
        Me.txt_Eq3.Name = "txt_Eq3"
        Me.txt_Eq3.NumericValue = 50
        Me.txt_Eq3.NumericValueInteger = 50
        Me.txt_Eq3.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Eq3.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Eq3.RoundingStep = 0
        Me.txt_Eq3.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Eq3.Size = New System.Drawing.Size(32, 15)
        Me.txt_Eq3.TabIndex = 193
        Me.txt_Eq3.Text = "50"
        Me.txt_Eq3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Eq2
        '
        Me.txt_Eq2.ArrowsIncrement = 1
        Me.txt_Eq2.BackColor = System.Drawing.Color.MintCream
        Me.txt_Eq2.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Eq2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Eq2.DimFactorGray = -20
        Me.txt_Eq2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Eq2.ForeColor = System.Drawing.Color.Black
        Me.txt_Eq2.Increment = 0.2
        Me.txt_Eq2.Location = New System.Drawing.Point(49, 115)
        Me.txt_Eq2.MaxValue = 40
        Me.txt_Eq2.MinValue = 10
        Me.txt_Eq2.Name = "txt_Eq2"
        Me.txt_Eq2.NumericValue = 20
        Me.txt_Eq2.NumericValueInteger = 20
        Me.txt_Eq2.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Eq2.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Eq2.RoundingStep = 0
        Me.txt_Eq2.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Eq2.Size = New System.Drawing.Size(32, 15)
        Me.txt_Eq2.TabIndex = 192
        Me.txt_Eq2.Text = "20"
        Me.txt_Eq2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Eq1
        '
        Me.txt_Eq1.ArrowsIncrement = 1
        Me.txt_Eq1.BackColor = System.Drawing.Color.MintCream
        Me.txt_Eq1.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Eq1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Eq1.DimFactorGray = -20
        Me.txt_Eq1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Eq1.ForeColor = System.Drawing.Color.Black
        Me.txt_Eq1.Increment = 0.2
        Me.txt_Eq1.Location = New System.Drawing.Point(8, 115)
        Me.txt_Eq1.MaxValue = 20
        Me.txt_Eq1.MinValue = 5
        Me.txt_Eq1.Name = "txt_Eq1"
        Me.txt_Eq1.NumericValue = 10
        Me.txt_Eq1.NumericValueInteger = 10
        Me.txt_Eq1.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Eq1.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Eq1.RoundingStep = 0
        Me.txt_Eq1.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Eq1.Size = New System.Drawing.Size(32, 15)
        Me.txt_Eq1.TabIndex = 191
        Me.txt_Eq1.Text = "10"
        Me.txt_Eq1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_TestFill1
        '
        Me.btn_TestFill1.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TestFill1.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_TestFill1.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_TestFill1.ColorFillBlendChecked = CBlendItems4
        Me.btn_TestFill1.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_TestFill1.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_TestFill1.Corners.All = CType(6, Short)
        Me.btn_TestFill1.Corners.LowerLeft = CType(6, Short)
        Me.btn_TestFill1.Corners.LowerRight = CType(6, Short)
        Me.btn_TestFill1.Corners.UpperLeft = CType(6, Short)
        Me.btn_TestFill1.Corners.UpperRight = CType(6, Short)
        Me.btn_TestFill1.DimFactorGray = -10
        Me.btn_TestFill1.DimFactorOver = 30
        Me.btn_TestFill1.FillType = MyButton.eFillType.LinearVertical
        Me.btn_TestFill1.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_TestFill1.FocalPoints.CenterPtX = 1.0!
        Me.btn_TestFill1.FocalPoints.CenterPtY = 1.0!
        Me.btn_TestFill1.FocalPoints.FocusPtX = 0.0!
        Me.btn_TestFill1.FocalPoints.FocusPtY = 0.0!
        Me.btn_TestFill1.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_TestFill1.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_TestFill1.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_TestFill1.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TestFill1.FocusPtTracker = DesignerRectTracker4
        Me.btn_TestFill1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_TestFill1.Image = Nothing
        Me.btn_TestFill1.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestFill1.ImageIndex = 0
        Me.btn_TestFill1.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_TestFill1.Location = New System.Drawing.Point(341, 87)
        Me.btn_TestFill1.Name = "btn_TestFill1"
        Me.btn_TestFill1.Shape = MyButton.eShape.Rectangle
        Me.btn_TestFill1.SideImage = Nothing
        Me.btn_TestFill1.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestFill1.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_TestFill1.Size = New System.Drawing.Size(36, 18)
        Me.btn_TestFill1.TabIndex = 162
        Me.btn_TestFill1.TabStop = False
        Me.btn_TestFill1.Text = "Test"
        Me.btn_TestFill1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TestFill1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_TestFill1.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_TestFill1.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_EqInterp
        '
        Me.txt_EqInterp.ArrowsIncrement = 10
        Me.txt_EqInterp.BackColor = System.Drawing.Color.MintCream
        Me.txt_EqInterp.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_EqInterp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_EqInterp.DimFactorGray = -20
        Me.txt_EqInterp.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_EqInterp.ForeColor = System.Drawing.Color.Black
        Me.txt_EqInterp.Increment = 2
        Me.txt_EqInterp.Location = New System.Drawing.Point(343, 1)
        Me.txt_EqInterp.MaxValue = 100
        Me.txt_EqInterp.MinValue = 0
        Me.txt_EqInterp.Name = "txt_EqInterp"
        Me.txt_EqInterp.NumericValue = 50
        Me.txt_EqInterp.NumericValueInteger = 50
        Me.txt_EqInterp.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_EqInterp.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_EqInterp.RoundingStep = 10
        Me.txt_EqInterp.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_EqInterp.Size = New System.Drawing.Size(32, 15)
        Me.txt_EqInterp.TabIndex = 190
        Me.txt_EqInterp.Text = "50"
        Me.txt_EqInterp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_EqInterp
        '
        Me.lbl_EqInterp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_EqInterp.ForeColor = System.Drawing.Color.Black
        Me.lbl_EqInterp.Location = New System.Drawing.Point(269, 1)
        Me.lbl_EqInterp.Name = "lbl_EqInterp"
        Me.lbl_EqInterp.Size = New System.Drawing.Size(80, 14)
        Me.lbl_EqInterp.TabIndex = 191
        Me.lbl_EqInterp.Text = "Cubical interp."
        Me.lbl_EqInterp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chk_EqOn
        '
        Me.chk_EqOn.AutoSize = True
        Me.chk_EqOn.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_EqOn.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_EqOn.Location = New System.Drawing.Point(334, 114)
        Me.chk_EqOn.Name = "chk_EqOn"
        Me.chk_EqOn.Size = New System.Drawing.Size(41, 18)
        Me.chk_EqOn.TabIndex = 189
        Me.chk_EqOn.Text = "ON"
        Me.chk_EqOn.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.chk_EqOn.UseVisualStyleBackColor = True
        '
        'tk_Eq8
        '
        Me.tk_Eq8.AutoSize = False
        Me.tk_Eq8.Location = New System.Drawing.Point(292, 18)
        Me.tk_Eq8.Maximum = 1000
        Me.tk_Eq8.Minimum = -1000
        Me.tk_Eq8.Name = "tk_Eq8"
        Me.tk_Eq8.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Eq8.Size = New System.Drawing.Size(43, 103)
        Me.tk_Eq8.TabIndex = 168
        Me.tk_Eq8.TickFrequency = 200
        Me.tk_Eq8.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Eq7
        '
        Me.tk_Eq7.AutoSize = False
        Me.tk_Eq7.Location = New System.Drawing.Point(252, 18)
        Me.tk_Eq7.Maximum = 1000
        Me.tk_Eq7.Minimum = -1000
        Me.tk_Eq7.Name = "tk_Eq7"
        Me.tk_Eq7.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Eq7.Size = New System.Drawing.Size(43, 103)
        Me.tk_Eq7.TabIndex = 167
        Me.tk_Eq7.TickFrequency = 200
        Me.tk_Eq7.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Eq6
        '
        Me.tk_Eq6.AutoSize = False
        Me.tk_Eq6.Location = New System.Drawing.Point(210, 18)
        Me.tk_Eq6.Maximum = 1000
        Me.tk_Eq6.Minimum = -1000
        Me.tk_Eq6.Name = "tk_Eq6"
        Me.tk_Eq6.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Eq6.Size = New System.Drawing.Size(43, 103)
        Me.tk_Eq6.TabIndex = 166
        Me.tk_Eq6.TickFrequency = 200
        Me.tk_Eq6.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Eq5
        '
        Me.tk_Eq5.AutoSize = False
        Me.tk_Eq5.Location = New System.Drawing.Point(169, 18)
        Me.tk_Eq5.Maximum = 1000
        Me.tk_Eq5.Minimum = -1000
        Me.tk_Eq5.Name = "tk_Eq5"
        Me.tk_Eq5.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Eq5.Size = New System.Drawing.Size(43, 103)
        Me.tk_Eq5.TabIndex = 165
        Me.tk_Eq5.TickFrequency = 200
        Me.tk_Eq5.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Eq4
        '
        Me.tk_Eq4.AutoSize = False
        Me.tk_Eq4.Location = New System.Drawing.Point(128, 18)
        Me.tk_Eq4.Maximum = 1000
        Me.tk_Eq4.Minimum = -1000
        Me.tk_Eq4.Name = "tk_Eq4"
        Me.tk_Eq4.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Eq4.Size = New System.Drawing.Size(43, 103)
        Me.tk_Eq4.TabIndex = 164
        Me.tk_Eq4.TickFrequency = 200
        Me.tk_Eq4.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Eq3
        '
        Me.tk_Eq3.AutoSize = False
        Me.tk_Eq3.Location = New System.Drawing.Point(87, 18)
        Me.tk_Eq3.Maximum = 1000
        Me.tk_Eq3.Minimum = -1000
        Me.tk_Eq3.Name = "tk_Eq3"
        Me.tk_Eq3.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Eq3.Size = New System.Drawing.Size(43, 103)
        Me.tk_Eq3.TabIndex = 163
        Me.tk_Eq3.TickFrequency = 200
        Me.tk_Eq3.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'btn_SaveEq
        '
        Me.btn_SaveEq.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SaveEq.CenterPtTracker = DesignerRectTracker5
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_SaveEq.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_SaveEq.ColorFillBlendChecked = CBlendItems6
        Me.btn_SaveEq.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_SaveEq.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_SaveEq.Corners.All = CType(6, Short)
        Me.btn_SaveEq.Corners.LowerLeft = CType(6, Short)
        Me.btn_SaveEq.Corners.LowerRight = CType(6, Short)
        Me.btn_SaveEq.Corners.UpperLeft = CType(6, Short)
        Me.btn_SaveEq.Corners.UpperRight = CType(6, Short)
        Me.btn_SaveEq.DimFactorGray = -10
        Me.btn_SaveEq.DimFactorOver = 30
        Me.btn_SaveEq.FillType = MyButton.eFillType.LinearVertical
        Me.btn_SaveEq.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_SaveEq.FocalPoints.CenterPtX = 1.0!
        Me.btn_SaveEq.FocalPoints.CenterPtY = 1.0!
        Me.btn_SaveEq.FocalPoints.FocusPtX = 0.0!
        Me.btn_SaveEq.FocalPoints.FocusPtY = 0.0!
        Me.btn_SaveEq.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_SaveEq.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_SaveEq.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_SaveEq.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SaveEq.FocusPtTracker = DesignerRectTracker6
        Me.btn_SaveEq.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SaveEq.Image = Nothing
        Me.btn_SaveEq.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SaveEq.ImageIndex = 0
        Me.btn_SaveEq.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_SaveEq.Location = New System.Drawing.Point(341, 53)
        Me.btn_SaveEq.Name = "btn_SaveEq"
        Me.btn_SaveEq.Shape = MyButton.eShape.Rectangle
        Me.btn_SaveEq.SideImage = Nothing
        Me.btn_SaveEq.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SaveEq.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_SaveEq.Size = New System.Drawing.Size(36, 18)
        Me.btn_SaveEq.TabIndex = 161
        Me.btn_SaveEq.TabStop = False
        Me.btn_SaveEq.Text = "Save"
        Me.btn_SaveEq.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SaveEq.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_SaveEq.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_SaveEq.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_LoadEq
        '
        Me.btn_LoadEq.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LoadEq.CenterPtTracker = DesignerRectTracker7
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_LoadEq.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_LoadEq.ColorFillBlendChecked = CBlendItems8
        Me.btn_LoadEq.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_LoadEq.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_LoadEq.Corners.All = CType(6, Short)
        Me.btn_LoadEq.Corners.LowerLeft = CType(6, Short)
        Me.btn_LoadEq.Corners.LowerRight = CType(6, Short)
        Me.btn_LoadEq.Corners.UpperLeft = CType(6, Short)
        Me.btn_LoadEq.Corners.UpperRight = CType(6, Short)
        Me.btn_LoadEq.DimFactorGray = -10
        Me.btn_LoadEq.DimFactorOver = 30
        Me.btn_LoadEq.FillType = MyButton.eFillType.LinearVertical
        Me.btn_LoadEq.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_LoadEq.FocalPoints.CenterPtX = 1.0!
        Me.btn_LoadEq.FocalPoints.CenterPtY = 1.0!
        Me.btn_LoadEq.FocalPoints.FocusPtX = 0.0!
        Me.btn_LoadEq.FocalPoints.FocusPtY = 0.0!
        Me.btn_LoadEq.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_LoadEq.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_LoadEq.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_LoadEq.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = True
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_LoadEq.FocusPtTracker = DesignerRectTracker8
        Me.btn_LoadEq.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_LoadEq.Image = Nothing
        Me.btn_LoadEq.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadEq.ImageIndex = 0
        Me.btn_LoadEq.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_LoadEq.Location = New System.Drawing.Point(341, 30)
        Me.btn_LoadEq.Name = "btn_LoadEq"
        Me.btn_LoadEq.Shape = MyButton.eShape.Rectangle
        Me.btn_LoadEq.SideImage = Nothing
        Me.btn_LoadEq.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadEq.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_LoadEq.Size = New System.Drawing.Size(36, 18)
        Me.btn_LoadEq.TabIndex = 160
        Me.btn_LoadEq.TabStop = False
        Me.btn_LoadEq.Text = "Load"
        Me.btn_LoadEq.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_LoadEq.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_LoadEq.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_LoadEq.TextShadow = System.Drawing.Color.Transparent
        '
        'tk_Eq2
        '
        Me.tk_Eq2.AutoSize = False
        Me.tk_Eq2.Location = New System.Drawing.Point(46, 18)
        Me.tk_Eq2.Maximum = 1000
        Me.tk_Eq2.Minimum = -1000
        Me.tk_Eq2.Name = "tk_Eq2"
        Me.tk_Eq2.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Eq2.Size = New System.Drawing.Size(43, 103)
        Me.tk_Eq2.TabIndex = 159
        Me.tk_Eq2.TickFrequency = 200
        Me.tk_Eq2.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'tk_Eq1
        '
        Me.tk_Eq1.AutoSize = False
        Me.tk_Eq1.Location = New System.Drawing.Point(5, 18)
        Me.tk_Eq1.Maximum = 1000
        Me.tk_Eq1.Minimum = -1000
        Me.tk_Eq1.Name = "tk_Eq1"
        Me.tk_Eq1.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_Eq1.Size = New System.Drawing.Size(43, 103)
        Me.tk_Eq1.TabIndex = 157
        Me.tk_Eq1.TickFrequency = 200
        Me.tk_Eq1.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'Form_Equalizers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(384, 282)
        Me.Controls.Add(Me.GroupBox_HeightEq)
        Me.Controls.Add(Me.GroupBox_EnergyLin)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(400, 320)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(400, 320)
        Me.Name = "Form_Equalizers"
        Me.Opacity = 0
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino MCA - Equalizers"
        Me.GroupBox_EnergyLin.ResumeLayout(False)
        Me.GroupBox_EnergyLin.PerformLayout()
        CType(Me.tk_Lin8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Lin7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Lin6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Lin5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Lin4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Lin3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Lin2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Lin1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_HeightEq.ResumeLayout(False)
        Me.GroupBox_HeightEq.PerformLayout()
        CType(Me.tk_Eq8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Eq7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Eq6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Eq5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Eq4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Eq3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Eq2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Eq1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox_EnergyLin As System.Windows.Forms.GroupBox
    Friend WithEvents tk_Lin1 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Lin2 As System.Windows.Forms.TrackBar
    Friend WithEvents btn_LoadLin As MyButton
    Friend WithEvents btn_SaveLin As MyButton
    Friend WithEvents GroupBox_HeightEq As System.Windows.Forms.GroupBox
    Friend WithEvents btn_TestFill1 As MyButton
    Friend WithEvents btn_SaveEq As MyButton
    Friend WithEvents btn_LoadEq As MyButton
    Friend WithEvents tk_Eq2 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Eq1 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Lin6 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Lin5 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Lin4 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Lin3 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Lin8 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Lin7 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Eq8 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Eq7 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Eq6 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Eq5 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Eq4 As System.Windows.Forms.TrackBar
    Friend WithEvents tk_Eq3 As System.Windows.Forms.TrackBar
    Friend WithEvents chk_EqOn As System.Windows.Forms.CheckBox
    Friend WithEvents txt_EqInterp As MyTextBox
    Friend WithEvents lbl_EqInterp As System.Windows.Forms.Label
    Friend WithEvents chk_LinOn As System.Windows.Forms.CheckBox
    Friend WithEvents txt_LinInterp As MyTextBox
    Friend WithEvents lbl_LinInterp As System.Windows.Forms.Label
    Friend WithEvents txt_Eq4 As MyTextBox
    Friend WithEvents txt_Eq3 As MyTextBox
    Friend WithEvents txt_Eq2 As MyTextBox
    Friend WithEvents txt_Eq1 As MyTextBox
    Friend WithEvents txt_Eq8 As MyTextBox
    Friend WithEvents txt_Eq7 As MyTextBox
    Friend WithEvents txt_Eq6 As MyTextBox
    Friend WithEvents txt_Eq5 As MyTextBox
    Friend WithEvents txt_Lin8 As MyTextBox
    Friend WithEvents txt_Lin7 As MyTextBox
    Friend WithEvents txt_Lin6 As MyTextBox
    Friend WithEvents txt_Lin5 As MyTextBox
    Friend WithEvents txt_Lin4 As MyTextBox
    Friend WithEvents txt_Lin3 As MyTextBox
    Friend WithEvents txt_Lin2 As MyTextBox
    Friend WithEvents txt_Lin1 As MyTextBox
    Friend WithEvents txt_EqMax As MyTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_LinMax As MyTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
