﻿Imports System.Collections.Generic
Imports System.Text.RegularExpressions
Imports System.IO


Public Class Form_AutoSave


    Private Sub Form_AutoSav_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Form_Main.btn_AutoSave.Enabled = False
        Form_Main.txt_AutoSave.Enabled = False
        'MsgBox(AutoSave_Execute)

        If AutoSave_Folder = "" Then
            AutoSave_Folder = Directory.GetCurrentDirectory()
        End If
        If AutoSave_Format = "" Then
            AutoSave_Format = "ThereminoMCA_(yyyy_MM_dd_HH_mm_ss)"
        End If
        txt_AutoSaveSeconds.MinValue = AutoSaveSecondsMinimum
        txt_AutoSaveSeconds.Text = Form_Main.txt_AutoSave.Text
        chk_AutoSave_Enabled.Checked = Form_Main.btn_AutoSave.Checked

        chk_AutoSave_StartNew.Checked = AutoSave_StartNew
        txt_AutoSave_Folder.Text = AutoSave_Folder
        txt_AutoSave_Format.Text = AutoSave_Format
        txt_AutoSave_Execute.Text = AutoSave_Execute
        chk_AutoSave_ExecuteEnabled.Checked = AutoSave_ExecuteEnabled
        'If lst_AutoSaveItem.Items.Count() = 0 Then
        Dim i As Integer
        For i = 0 To chk_List.Length - 1
            If CStr(chk_List(i, AutoSave_lst.Name)) = "" Then
                Exit For
            End If
            If CStr(chk_ListBUF(i, AutoSave_lst.Name)) = "" Then
                chk_ListBUF(i, AutoSave_lst.Name) = chk_List(i, AutoSave_lst.Name)
                chk_ListBUF(i, AutoSave_lst.Desc) = chk_List(i, AutoSave_lst.Desc)
                'chk_ListBUF(i, AutoSave_lst.Checked) = chk_List(i, AutoSave_lst.Checked)
                chk_ListBUF(i, AutoSave_lst.Ext) = chk_List(i, AutoSave_lst.Ext)
            End If

            lst_AutoSaveItem.Items.Add( _
                CStr(chk_ListBUF(i, AutoSave_lst.Name)) & " - " & _
                CStr(chk_ListBUF(i, AutoSave_lst.Desc)) _
                )
            lst_AutoSaveItem.SetItemChecked(i, CBool(chk_ListBUF(i, AutoSave_lst.Checked)))
        Next
        'End If
        FolderBrowserDialog1.SelectedPath = AutoSave_Folder


    End Sub

    Private Sub Form_AutoSave_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'Me.Hide()
        'e.Cancel = True
        If Form_Help.Enabled Then
            Form_Help.Close()
        End If
        Form_Main.btn_AutoSave.Enabled = True
        Form_Main.txt_AutoSave.Enabled = True
        'Save_INI()
    End Sub


    Private Sub Button_OK(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_OK.Click

        Apply_Changes()
        Me.Close()

    End Sub

    Private Sub Apply_Changes()
        Form_Main.txt_AutoSave.Text = txt_AutoSaveSeconds.Text
        Form_Main.btn_AutoSave.Checked = chk_AutoSave_Enabled.Checked

        AutoSave_StartNew = chk_AutoSave_StartNew.Checked
        AutoSave_Folder = txt_AutoSave_Folder.Text
        AutoSave_Format = txt_AutoSave_Format.Text
        AutoSave_Execute = txt_AutoSave_Execute.Text
        AutoSave_ExecuteEnabled = chk_AutoSave_ExecuteEnabled.Checked


        Dim i As Integer
        For i = 0 To chk_List.Length - 1
            If CStr(chk_List(i, AutoSave_lst.Name)) = "" Then
                Exit For
            End If
            chk_ListBUF(i, AutoSave_lst.Checked) = lst_AutoSaveItem.GetItemChecked(i)
            'MsgBox(CStr(chk_ListBUF(i, AutoSave_lst.Name)) & " -AB- " & CBool(chk_ListBUF(i, AutoSave_lst.Checked)))
        Next


        'Save_INI()

    End Sub

    Private Sub Button_Cancel(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Cancel.Click
        Me.Close()

    End Sub

    Private Sub Buton_Browse(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Browse.Click
        If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then
            txt_AutoSave_Folder.Text = FolderBrowserDialog1.SelectedPath
        End If

    End Sub


    Private Sub Button_Apply(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Apply.Click
        Apply_Changes()
    End Sub

    Private Sub Button_Now(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Now.Click
        Apply_Changes()
        Me.Close()
        Form_Main.AutoSaveFiles()
    End Sub


    Private Sub Button_Help(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Help.Click
        Show_Help("Docs\AutoSave_Help_", ".rtf")
    End Sub


    Private Sub Check_AutoSave_Seconds(ByVal sender As System.Object, ByVal e As System.EventArgs)
        txt_AutoSaveSeconds.Text = Regex.Replace(txt_AutoSaveSeconds.Text, "[^\d]", "")
        If txt_AutoSaveSeconds.NumericValueInteger < AutoSaveSecondsMinimum Then
            txt_AutoSaveSeconds.NumericValueInteger = AutoSaveSecondsMinimum
        End If
    End Sub

End Class