﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Pulses
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker1 As DesignerRectTracker = New DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Pulses))
        Dim CBlendItems1 As cBlendItems = New cBlendItems
        Dim CBlendItems2 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker2 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker3 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems3 As cBlendItems = New cBlendItems
        Dim CBlendItems4 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker4 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker5 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems5 As cBlendItems = New cBlendItems
        Dim CBlendItems6 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker6 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker7 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems7 As cBlendItems = New cBlendItems
        Dim CBlendItems8 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker8 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker9 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems9 As cBlendItems = New cBlendItems
        Dim CBlendItems10 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker10 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker11 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems11 As cBlendItems = New cBlendItems
        Dim CBlendItems12 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker12 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker13 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems13 As cBlendItems = New cBlendItems
        Dim CBlendItems14 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker14 As DesignerRectTracker = New DesignerRectTracker
        Dim DesignerRectTracker15 As DesignerRectTracker = New DesignerRectTracker
        Dim CBlendItems15 As cBlendItems = New cBlendItems
        Dim CBlendItems16 As cBlendItems = New cBlendItems
        Dim DesignerRectTracker16 As DesignerRectTracker = New DesignerRectTracker
        Me.PBoxScope = New System.Windows.Forms.PictureBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btn_Run = New MyButton
        Me.btn_OneShot = New MyButton
        Me.tk_SizeY = New System.Windows.Forms.TrackBar
        Me.tk_SizeX = New System.Windows.Forms.TrackBar
        Me.btn_Normalized = New MyButton
        Me.tk_PosY = New System.Windows.Forms.TrackBar
        Me.txt_MinEnergy = New MyTextBox
        Me.Label_MinEnergy = New System.Windows.Forms.Label
        Me.txt_MaxEnergy = New MyTextBox
        Me.Label_MaxEnergy = New System.Windows.Forms.Label
        Me.GroupBox_SpectrumData = New System.Windows.Forms.GroupBox
        Me.btn_PV_S = New MyButton
        Me.btn_PV_N = New MyButton
        Me.btn_PV_B = New MyButton
        Me.btn_PV_R = New MyButton
        Me.Label_Range = New System.Windows.Forms.Label
        Me.btn_Rejected = New MyButton
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton_SaveScopeImage = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        CType(Me.PBoxScope, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_SizeY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_SizeX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_PosY, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_SpectrumData.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PBoxScope
        '
        Me.PBoxScope.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PBoxScope.BackColor = System.Drawing.Color.AliceBlue
        Me.PBoxScope.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PBoxScope.Location = New System.Drawing.Point(10, 18)
        Me.PBoxScope.Name = "PBoxScope"
        Me.PBoxScope.Size = New System.Drawing.Size(320, 184)
        Me.PBoxScope.TabIndex = 0
        Me.PBoxScope.TabStop = False
        '
        'Timer1
        '
        '
        'btn_Run
        '
        Me.btn_Run.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Run.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Run.CenterPtTracker = DesignerRectTracker1
        Me.btn_Run.CheckButton = True
        Me.btn_Run.Checked = True
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Run.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Run.ColorFillBlendChecked = CBlendItems2
        Me.btn_Run.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Run.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Run.Corners.All = CType(6, Short)
        Me.btn_Run.Corners.LowerLeft = CType(6, Short)
        Me.btn_Run.Corners.LowerRight = CType(6, Short)
        Me.btn_Run.Corners.UpperLeft = CType(6, Short)
        Me.btn_Run.Corners.UpperRight = CType(6, Short)
        Me.btn_Run.DimFactorGray = -10
        Me.btn_Run.DimFactorOver = 30
        Me.btn_Run.FillType = MyButton.eFillType.LinearVertical
        Me.btn_Run.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_Run.FocalPoints.CenterPtX = 1.0!
        Me.btn_Run.FocalPoints.CenterPtY = 1.0!
        Me.btn_Run.FocalPoints.FocusPtX = 0.0!
        Me.btn_Run.FocalPoints.FocusPtY = 0.0!
        Me.btn_Run.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_Run.FocalPointsChecked.CenterPtY = 0.375!
        Me.btn_Run.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Run.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Run.FocusPtTracker = DesignerRectTracker2
        Me.btn_Run.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Run.Image = Nothing
        Me.btn_Run.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Run.ImageIndex = 0
        Me.btn_Run.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Run.Location = New System.Drawing.Point(125, 227)
        Me.btn_Run.Name = "btn_Run"
        Me.btn_Run.Shape = MyButton.eShape.Rectangle
        Me.btn_Run.SideImage = Nothing
        Me.btn_Run.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Run.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Run.Size = New System.Drawing.Size(39, 20)
        Me.btn_Run.TabIndex = 155
        Me.btn_Run.TabStop = False
        Me.btn_Run.Text = "Run"
        Me.btn_Run.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Run.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Run.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Run.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_OneShot
        '
        Me.btn_OneShot.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_OneShot.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_OneShot.CenterPtTracker = DesignerRectTracker3
        Me.btn_OneShot.CheckButton = True
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_OneShot.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_OneShot.ColorFillBlendChecked = CBlendItems4
        Me.btn_OneShot.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_OneShot.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_OneShot.Corners.All = CType(5, Short)
        Me.btn_OneShot.Corners.LowerLeft = CType(5, Short)
        Me.btn_OneShot.Corners.LowerRight = CType(5, Short)
        Me.btn_OneShot.Corners.UpperLeft = CType(5, Short)
        Me.btn_OneShot.Corners.UpperRight = CType(5, Short)
        Me.btn_OneShot.DimFactorGray = -10
        Me.btn_OneShot.DimFactorOver = 30
        Me.btn_OneShot.FillType = MyButton.eFillType.LinearVertical
        Me.btn_OneShot.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_OneShot.FocalPoints.CenterPtX = 1.0!
        Me.btn_OneShot.FocalPoints.CenterPtY = 1.0!
        Me.btn_OneShot.FocalPoints.FocusPtX = 0.0!
        Me.btn_OneShot.FocalPoints.FocusPtY = 0.0!
        Me.btn_OneShot.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_OneShot.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_OneShot.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_OneShot.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_OneShot.FocusPtTracker = DesignerRectTracker4
        Me.btn_OneShot.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_OneShot.Image = Nothing
        Me.btn_OneShot.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_OneShot.ImageIndex = 0
        Me.btn_OneShot.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_OneShot.Location = New System.Drawing.Point(175, 227)
        Me.btn_OneShot.Name = "btn_OneShot"
        Me.btn_OneShot.Shape = MyButton.eShape.Rectangle
        Me.btn_OneShot.SideImage = Nothing
        Me.btn_OneShot.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_OneShot.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_OneShot.Size = New System.Drawing.Size(66, 20)
        Me.btn_OneShot.TabIndex = 156
        Me.btn_OneShot.TabStop = False
        Me.btn_OneShot.Text = "One shot"
        Me.btn_OneShot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_OneShot.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_OneShot.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_OneShot.TextShadow = System.Drawing.Color.Transparent
        '
        'tk_SizeY
        '
        Me.tk_SizeY.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tk_SizeY.AutoSize = False
        Me.tk_SizeY.Enabled = False
        Me.tk_SizeY.LargeChange = 1
        Me.tk_SizeY.Location = New System.Drawing.Point(334, 22)
        Me.tk_SizeY.Maximum = 32
        Me.tk_SizeY.Minimum = 1
        Me.tk_SizeY.Name = "tk_SizeY"
        Me.tk_SizeY.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_SizeY.Size = New System.Drawing.Size(33, 70)
        Me.tk_SizeY.TabIndex = 157
        Me.tk_SizeY.TickFrequency = 3
        Me.tk_SizeY.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tk_SizeY.Value = 9
        '
        'tk_SizeX
        '
        Me.tk_SizeX.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tk_SizeX.AutoSize = False
        Me.tk_SizeX.Location = New System.Drawing.Point(256, 208)
        Me.tk_SizeX.Maximum = 100
        Me.tk_SizeX.Minimum = 10
        Me.tk_SizeX.Name = "tk_SizeX"
        Me.tk_SizeX.Size = New System.Drawing.Size(77, 33)
        Me.tk_SizeX.TabIndex = 158
        Me.tk_SizeX.TickFrequency = 10
        Me.tk_SizeX.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tk_SizeX.Value = 10
        '
        'btn_Normalized
        '
        Me.btn_Normalized.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Normalized.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Normalized.CenterPtTracker = DesignerRectTracker5
        Me.btn_Normalized.CheckButton = True
        Me.btn_Normalized.Checked = True
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Normalized.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(193, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.7455197!, 1.0!}
        Me.btn_Normalized.ColorFillBlendChecked = CBlendItems6
        Me.btn_Normalized.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Normalized.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Normalized.Corners.All = CType(-1, Short)
        Me.btn_Normalized.Corners.LowerLeft = CType(3, Short)
        Me.btn_Normalized.Corners.LowerRight = CType(3, Short)
        Me.btn_Normalized.Corners.UpperLeft = CType(11, Short)
        Me.btn_Normalized.Corners.UpperRight = CType(11, Short)
        Me.btn_Normalized.DimFactorGray = -10
        Me.btn_Normalized.DimFactorOver = 30
        Me.btn_Normalized.FillType = MyButton.eFillType.LinearVertical
        Me.btn_Normalized.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_Normalized.FocalPoints.CenterPtX = 1.0!
        Me.btn_Normalized.FocalPoints.CenterPtY = 1.0!
        Me.btn_Normalized.FocalPoints.FocusPtX = 0.0!
        Me.btn_Normalized.FocalPoints.FocusPtY = 0.0!
        Me.btn_Normalized.FocalPointsChecked.CenterPtX = 0.6818182!
        Me.btn_Normalized.FocalPointsChecked.CenterPtY = 0.2857143!
        Me.btn_Normalized.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Normalized.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Normalized.FocusPtTracker = DesignerRectTracker6
        Me.btn_Normalized.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Normalized.Image = Nothing
        Me.btn_Normalized.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Normalized.ImageIndex = 0
        Me.btn_Normalized.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Normalized.Location = New System.Drawing.Point(343, 189)
        Me.btn_Normalized.Name = "btn_Normalized"
        Me.btn_Normalized.Shape = MyButton.eShape.Rectangle
        Me.btn_Normalized.SideImage = Nothing
        Me.btn_Normalized.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Normalized.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Normalized.Size = New System.Drawing.Size(22, 52)
        Me.btn_Normalized.TabIndex = 159
        Me.btn_Normalized.TabStop = False
        Me.btn_Normalized.Text = "N         o         r         m"
        Me.btn_Normalized.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Normalized.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Normalized.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Normalized.TextShadow = System.Drawing.Color.Transparent
        '
        'tk_PosY
        '
        Me.tk_PosY.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tk_PosY.AutoSize = False
        Me.tk_PosY.Enabled = False
        Me.tk_PosY.Location = New System.Drawing.Point(334, 90)
        Me.tk_PosY.Maximum = 100
        Me.tk_PosY.Minimum = 1
        Me.tk_PosY.Name = "tk_PosY"
        Me.tk_PosY.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_PosY.Size = New System.Drawing.Size(33, 70)
        Me.tk_PosY.TabIndex = 160
        Me.tk_PosY.TickFrequency = 10
        Me.tk_PosY.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tk_PosY.Value = 50
        '
        'txt_MinEnergy
        '
        Me.txt_MinEnergy.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_MinEnergy.ArrowsIncrement = 1
        Me.txt_MinEnergy.BackColor = System.Drawing.Color.MintCream
        Me.txt_MinEnergy.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MinEnergy.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MinEnergy.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MinEnergy.ForeColor = System.Drawing.Color.Black
        Me.txt_MinEnergy.Increment = 5
        Me.txt_MinEnergy.Location = New System.Drawing.Point(80, 208)
        Me.txt_MinEnergy.MaxValue = 5000
        Me.txt_MinEnergy.MinValue = 0
        Me.txt_MinEnergy.Name = "txt_MinEnergy"
        Me.txt_MinEnergy.NumericValue = 10
        Me.txt_MinEnergy.NumericValueInteger = 10
        Me.txt_MinEnergy.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MinEnergy.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MinEnergy.RoundingStep = 0
        Me.txt_MinEnergy.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MinEnergy.Size = New System.Drawing.Size(34, 16)
        Me.txt_MinEnergy.TabIndex = 162
        Me.txt_MinEnergy.Text = "10"
        Me.txt_MinEnergy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_MinEnergy
        '
        Me.Label_MinEnergy.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label_MinEnergy.AutoSize = True
        Me.Label_MinEnergy.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MinEnergy.ForeColor = System.Drawing.Color.Black
        Me.Label_MinEnergy.Location = New System.Drawing.Point(7, 208)
        Me.Label_MinEnergy.Name = "Label_MinEnergy"
        Me.Label_MinEnergy.Size = New System.Drawing.Size(59, 13)
        Me.Label_MinEnergy.TabIndex = 163
        Me.Label_MinEnergy.Text = "Base (KeV)"
        '
        'txt_MaxEnergy
        '
        Me.txt_MaxEnergy.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_MaxEnergy.ArrowsIncrement = 1
        Me.txt_MaxEnergy.BackColor = System.Drawing.Color.MintCream
        Me.txt_MaxEnergy.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MaxEnergy.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MaxEnergy.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MaxEnergy.ForeColor = System.Drawing.Color.Black
        Me.txt_MaxEnergy.Increment = 5
        Me.txt_MaxEnergy.Location = New System.Drawing.Point(80, 227)
        Me.txt_MaxEnergy.MaxValue = 5000
        Me.txt_MaxEnergy.MinValue = 1
        Me.txt_MaxEnergy.Name = "txt_MaxEnergy"
        Me.txt_MaxEnergy.NumericValue = 3200
        Me.txt_MaxEnergy.NumericValueInteger = 3200
        Me.txt_MaxEnergy.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MaxEnergy.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MaxEnergy.RoundingStep = 0
        Me.txt_MaxEnergy.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MaxEnergy.Size = New System.Drawing.Size(34, 16)
        Me.txt_MaxEnergy.TabIndex = 161
        Me.txt_MaxEnergy.Text = "3200"
        Me.txt_MaxEnergy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_MaxEnergy
        '
        Me.Label_MaxEnergy.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label_MaxEnergy.AutoSize = True
        Me.Label_MaxEnergy.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MaxEnergy.ForeColor = System.Drawing.Color.Black
        Me.Label_MaxEnergy.Location = New System.Drawing.Point(7, 228)
        Me.Label_MaxEnergy.Name = "Label_MaxEnergy"
        Me.Label_MaxEnergy.Size = New System.Drawing.Size(67, 13)
        Me.Label_MaxEnergy.TabIndex = 164
        Me.Label_MaxEnergy.Text = "Range (KeV)"
        '
        'GroupBox_SpectrumData
        '
        Me.GroupBox_SpectrumData.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_SpectrumData.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_PV_S)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_PV_N)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_PV_B)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_PV_R)
        Me.GroupBox_SpectrumData.Controls.Add(Me.Label_Range)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_Rejected)
        Me.GroupBox_SpectrumData.Controls.Add(Me.tk_SizeY)
        Me.GroupBox_SpectrumData.Controls.Add(Me.PBoxScope)
        Me.GroupBox_SpectrumData.Controls.Add(Me.tk_PosY)
        Me.GroupBox_SpectrumData.Controls.Add(Me.txt_MinEnergy)
        Me.GroupBox_SpectrumData.Controls.Add(Me.tk_SizeX)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_Normalized)
        Me.GroupBox_SpectrumData.Controls.Add(Me.txt_MaxEnergy)
        Me.GroupBox_SpectrumData.Controls.Add(Me.Label_MinEnergy)
        Me.GroupBox_SpectrumData.Controls.Add(Me.Label_MaxEnergy)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_Run)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_OneShot)
        Me.GroupBox_SpectrumData.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_SpectrumData.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_SpectrumData.Location = New System.Drawing.Point(6, 28)
        Me.GroupBox_SpectrumData.Name = "GroupBox_SpectrumData"
        Me.GroupBox_SpectrumData.Size = New System.Drawing.Size(373, 250)
        Me.GroupBox_SpectrumData.TabIndex = 165
        Me.GroupBox_SpectrumData.TabStop = False
        Me.GroupBox_SpectrumData.Text = "Pulse shape"
        '
        'btn_PV_S
        '
        Me.btn_PV_S.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_PV_S.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker7.IsActive = True
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_PV_S.CenterPtTracker = DesignerRectTracker7
        Me.btn_PV_S.CheckButton = True
        Me.btn_PV_S.Checked = True
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_PV_S.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_PV_S.ColorFillBlendChecked = CBlendItems8
        Me.btn_PV_S.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_PV_S.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_PV_S.Corners.All = CType(6, Short)
        Me.btn_PV_S.Corners.LowerLeft = CType(6, Short)
        Me.btn_PV_S.Corners.LowerRight = CType(6, Short)
        Me.btn_PV_S.Corners.UpperLeft = CType(6, Short)
        Me.btn_PV_S.Corners.UpperRight = CType(6, Short)
        Me.btn_PV_S.DimFactorGray = -10
        Me.btn_PV_S.DimFactorOver = 30
        Me.btn_PV_S.FillType = MyButton.eFillType.LinearVertical
        Me.btn_PV_S.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_PV_S.FocalPoints.CenterPtX = 1.0!
        Me.btn_PV_S.FocalPoints.CenterPtY = 1.0!
        Me.btn_PV_S.FocalPoints.FocusPtX = 0.0!
        Me.btn_PV_S.FocalPoints.FocusPtY = 0.0!
        Me.btn_PV_S.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_PV_S.FocalPointsChecked.CenterPtY = 0.375!
        Me.btn_PV_S.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_PV_S.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_PV_S.FocusPtTracker = DesignerRectTracker8
        Me.btn_PV_S.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_PV_S.Image = Nothing
        Me.btn_PV_S.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_S.ImageIndex = 0
        Me.btn_PV_S.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_PV_S.Location = New System.Drawing.Point(190, 0)
        Me.btn_PV_S.Name = "btn_PV_S"
        Me.btn_PV_S.Shape = MyButton.eShape.Rectangle
        Me.btn_PV_S.SideImage = Nothing
        Me.btn_PV_S.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_S.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_PV_S.Size = New System.Drawing.Size(23, 15)
        Me.btn_PV_S.TabIndex = 170
        Me.btn_PV_S.TabStop = False
        Me.btn_PV_S.Text = "S"
        Me.btn_PV_S.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_S.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_PV_S.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_PV_S.TextShadow = System.Drawing.Color.Transparent
        Me.btn_PV_S.Visible = False
        '
        'btn_PV_N
        '
        Me.btn_PV_N.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_PV_N.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_PV_N.CenterPtTracker = DesignerRectTracker9
        Me.btn_PV_N.CheckButton = True
        Me.btn_PV_N.Checked = True
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_PV_N.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_PV_N.ColorFillBlendChecked = CBlendItems10
        Me.btn_PV_N.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_PV_N.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_PV_N.Corners.All = CType(6, Short)
        Me.btn_PV_N.Corners.LowerLeft = CType(6, Short)
        Me.btn_PV_N.Corners.LowerRight = CType(6, Short)
        Me.btn_PV_N.Corners.UpperLeft = CType(6, Short)
        Me.btn_PV_N.Corners.UpperRight = CType(6, Short)
        Me.btn_PV_N.DimFactorGray = -10
        Me.btn_PV_N.DimFactorOver = 30
        Me.btn_PV_N.FillType = MyButton.eFillType.LinearVertical
        Me.btn_PV_N.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_PV_N.FocalPoints.CenterPtX = 1.0!
        Me.btn_PV_N.FocalPoints.CenterPtY = 1.0!
        Me.btn_PV_N.FocalPoints.FocusPtX = 0.0!
        Me.btn_PV_N.FocalPoints.FocusPtY = 0.0!
        Me.btn_PV_N.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_PV_N.FocalPointsChecked.CenterPtY = 0.375!
        Me.btn_PV_N.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_PV_N.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_PV_N.FocusPtTracker = DesignerRectTracker10
        Me.btn_PV_N.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_PV_N.Image = Nothing
        Me.btn_PV_N.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_N.ImageIndex = 0
        Me.btn_PV_N.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_PV_N.Location = New System.Drawing.Point(219, 0)
        Me.btn_PV_N.Name = "btn_PV_N"
        Me.btn_PV_N.Shape = MyButton.eShape.Rectangle
        Me.btn_PV_N.SideImage = Nothing
        Me.btn_PV_N.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_N.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_PV_N.Size = New System.Drawing.Size(23, 15)
        Me.btn_PV_N.TabIndex = 169
        Me.btn_PV_N.TabStop = False
        Me.btn_PV_N.Text = "N"
        Me.btn_PV_N.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_N.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_PV_N.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_PV_N.TextShadow = System.Drawing.Color.Transparent
        Me.btn_PV_N.Visible = False
        '
        'btn_PV_B
        '
        Me.btn_PV_B.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_PV_B.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_PV_B.CenterPtTracker = DesignerRectTracker11
        Me.btn_PV_B.CheckButton = True
        Me.btn_PV_B.Checked = True
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_PV_B.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_PV_B.ColorFillBlendChecked = CBlendItems12
        Me.btn_PV_B.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_PV_B.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_PV_B.Corners.All = CType(6, Short)
        Me.btn_PV_B.Corners.LowerLeft = CType(6, Short)
        Me.btn_PV_B.Corners.LowerRight = CType(6, Short)
        Me.btn_PV_B.Corners.UpperLeft = CType(6, Short)
        Me.btn_PV_B.Corners.UpperRight = CType(6, Short)
        Me.btn_PV_B.DimFactorGray = -10
        Me.btn_PV_B.DimFactorOver = 30
        Me.btn_PV_B.FillType = MyButton.eFillType.LinearVertical
        Me.btn_PV_B.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_PV_B.FocalPoints.CenterPtX = 1.0!
        Me.btn_PV_B.FocalPoints.CenterPtY = 1.0!
        Me.btn_PV_B.FocalPoints.FocusPtX = 0.0!
        Me.btn_PV_B.FocalPoints.FocusPtY = 0.0!
        Me.btn_PV_B.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_PV_B.FocalPointsChecked.CenterPtY = 0.375!
        Me.btn_PV_B.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_PV_B.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_PV_B.FocusPtTracker = DesignerRectTracker12
        Me.btn_PV_B.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_PV_B.Image = Nothing
        Me.btn_PV_B.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_B.ImageIndex = 0
        Me.btn_PV_B.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_PV_B.Location = New System.Drawing.Point(248, 0)
        Me.btn_PV_B.Name = "btn_PV_B"
        Me.btn_PV_B.Shape = MyButton.eShape.Rectangle
        Me.btn_PV_B.SideImage = Nothing
        Me.btn_PV_B.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_B.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_PV_B.Size = New System.Drawing.Size(23, 15)
        Me.btn_PV_B.TabIndex = 168
        Me.btn_PV_B.TabStop = False
        Me.btn_PV_B.Text = "B"
        Me.btn_PV_B.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_B.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_PV_B.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_PV_B.TextShadow = System.Drawing.Color.Transparent
        Me.btn_PV_B.Visible = False
        '
        'btn_PV_R
        '
        Me.btn_PV_R.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_PV_R.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker13.IsActive = False
        DesignerRectTracker13.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker13.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_PV_R.CenterPtTracker = DesignerRectTracker13
        Me.btn_PV_R.CheckButton = True
        Me.btn_PV_R.Checked = True
        CBlendItems13.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems13.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_PV_R.ColorFillBlend = CBlendItems13
        CBlendItems14.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems14.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_PV_R.ColorFillBlendChecked = CBlendItems14
        Me.btn_PV_R.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_PV_R.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_PV_R.Corners.All = CType(6, Short)
        Me.btn_PV_R.Corners.LowerLeft = CType(6, Short)
        Me.btn_PV_R.Corners.LowerRight = CType(6, Short)
        Me.btn_PV_R.Corners.UpperLeft = CType(6, Short)
        Me.btn_PV_R.Corners.UpperRight = CType(6, Short)
        Me.btn_PV_R.DimFactorGray = -10
        Me.btn_PV_R.DimFactorOver = 30
        Me.btn_PV_R.FillType = MyButton.eFillType.LinearVertical
        Me.btn_PV_R.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_PV_R.FocalPoints.CenterPtX = 1.0!
        Me.btn_PV_R.FocalPoints.CenterPtY = 1.0!
        Me.btn_PV_R.FocalPoints.FocusPtX = 0.0!
        Me.btn_PV_R.FocalPoints.FocusPtY = 0.0!
        Me.btn_PV_R.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_PV_R.FocalPointsChecked.CenterPtY = 0.375!
        Me.btn_PV_R.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_PV_R.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker14.IsActive = False
        DesignerRectTracker14.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker14.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_PV_R.FocusPtTracker = DesignerRectTracker14
        Me.btn_PV_R.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_PV_R.Image = Nothing
        Me.btn_PV_R.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_R.ImageIndex = 0
        Me.btn_PV_R.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_PV_R.Location = New System.Drawing.Point(277, 0)
        Me.btn_PV_R.Name = "btn_PV_R"
        Me.btn_PV_R.Shape = MyButton.eShape.Rectangle
        Me.btn_PV_R.SideImage = Nothing
        Me.btn_PV_R.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_R.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_PV_R.Size = New System.Drawing.Size(23, 15)
        Me.btn_PV_R.TabIndex = 167
        Me.btn_PV_R.TabStop = False
        Me.btn_PV_R.Text = "R"
        Me.btn_PV_R.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_PV_R.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_PV_R.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_PV_R.TextShadow = System.Drawing.Color.Transparent
        Me.btn_PV_R.Visible = False
        '
        'Label_Range
        '
        Me.Label_Range.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label_Range.AutoSize = True
        Me.Label_Range.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Range.ForeColor = System.Drawing.Color.Black
        Me.Label_Range.Location = New System.Drawing.Point(122, 208)
        Me.Label_Range.Name = "Label_Range"
        Me.Label_Range.Size = New System.Drawing.Size(128, 13)
        Me.Label_Range.TabIndex = 166
        Me.Label_Range.Text = " From 2000 to 3200  KeV "
        '
        'btn_Rejected
        '
        Me.btn_Rejected.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Rejected.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker15.IsActive = False
        DesignerRectTracker15.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker15.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rejected.CenterPtTracker = DesignerRectTracker15
        CBlendItems15.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems15.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Rejected.ColorFillBlend = CBlendItems15
        CBlendItems16.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems16.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Rejected.ColorFillBlendChecked = CBlendItems16
        Me.btn_Rejected.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Rejected.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Rejected.Corners.All = CType(6, Short)
        Me.btn_Rejected.Corners.LowerLeft = CType(6, Short)
        Me.btn_Rejected.Corners.LowerRight = CType(6, Short)
        Me.btn_Rejected.Corners.UpperLeft = CType(6, Short)
        Me.btn_Rejected.Corners.UpperRight = CType(6, Short)
        Me.btn_Rejected.DimFactorGray = -10
        Me.btn_Rejected.DimFactorOver = 30
        Me.btn_Rejected.FillType = MyButton.eFillType.LinearVertical
        Me.btn_Rejected.FillTypeChecked = MyButton.eFillType.LinearVertical
        Me.btn_Rejected.FocalPoints.CenterPtX = 1.0!
        Me.btn_Rejected.FocalPoints.CenterPtY = 1.0!
        Me.btn_Rejected.FocalPoints.FocusPtX = 0.0!
        Me.btn_Rejected.FocalPoints.FocusPtY = 0.0!
        Me.btn_Rejected.FocalPointsChecked.CenterPtX = 1.0!
        Me.btn_Rejected.FocalPointsChecked.CenterPtY = 0.375!
        Me.btn_Rejected.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Rejected.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker16.IsActive = False
        DesignerRectTracker16.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker16.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Rejected.FocusPtTracker = DesignerRectTracker16
        Me.btn_Rejected.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Rejected.Image = Nothing
        Me.btn_Rejected.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rejected.ImageIndex = 0
        Me.btn_Rejected.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Rejected.Location = New System.Drawing.Point(306, 0)
        Me.btn_Rejected.Name = "btn_Rejected"
        Me.btn_Rejected.Shape = MyButton.eShape.Rectangle
        Me.btn_Rejected.SideImage = Nothing
        Me.btn_Rejected.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rejected.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Rejected.Size = New System.Drawing.Size(59, 15)
        Me.btn_Rejected.TabIndex = 165
        Me.btn_Rejected.TabStop = False
        Me.btn_Rejected.Text = "Valid"
        Me.btn_Rejected.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Rejected.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Rejected.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Rejected.TextShadow = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton_SaveScopeImage, Me.ToolStripSeparator5})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(384, 25)
        Me.ToolStrip1.TabIndex = 167
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton_SaveScopeImage
        '
        Me.ToolStripButton_SaveScopeImage.Image = CType(resources.GetObject("ToolStripButton_SaveScopeImage.Image"), System.Drawing.Image)
        Me.ToolStripButton_SaveScopeImage.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_SaveScopeImage.Name = "ToolStripButton_SaveScopeImage"
        Me.ToolStripButton_SaveScopeImage.Size = New System.Drawing.Size(87, 22)
        Me.ToolStripButton_SaveScopeImage.Text = "Save image"
        Me.ToolStripButton_SaveScopeImage.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'Form_Pulses
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(384, 282)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.GroupBox_SpectrumData)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(700, 550)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(400, 320)
        Me.Name = "Form_Pulses"
        Me.Opacity = 0
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino MCA - Pulse shape visualizer"
        CType(Me.PBoxScope, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_SizeY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_SizeX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_PosY, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_SpectrumData.ResumeLayout(False)
        Me.GroupBox_SpectrumData.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PBoxScope As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents btn_Run As MyButton
    Friend WithEvents btn_OneShot As MyButton
    Friend WithEvents tk_SizeY As System.Windows.Forms.TrackBar
    Friend WithEvents tk_SizeX As System.Windows.Forms.TrackBar
    Friend WithEvents btn_Normalized As MyButton
    Friend WithEvents tk_PosY As System.Windows.Forms.TrackBar
    Friend WithEvents txt_MinEnergy As MyTextBox
    Friend WithEvents Label_MinEnergy As System.Windows.Forms.Label
    Friend WithEvents txt_MaxEnergy As MyTextBox
    Friend WithEvents Label_MaxEnergy As System.Windows.Forms.Label
    Friend WithEvents GroupBox_SpectrumData As System.Windows.Forms.GroupBox
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton_SaveScopeImage As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btn_Rejected As MyButton
    Friend WithEvents Label_Range As System.Windows.Forms.Label
    Friend WithEvents btn_PV_S As MyButton
    Friend WithEvents btn_PV_N As MyButton
    Friend WithEvents btn_PV_B As MyButton
    Friend WithEvents btn_PV_R As MyButton
End Class
