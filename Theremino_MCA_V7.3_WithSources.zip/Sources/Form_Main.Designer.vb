﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DesignerRectTracker41 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Main))
        Dim CBlendItems41 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems42 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker42 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker1 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems1 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems2 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker2 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker3 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems3 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems4 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker4 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker5 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems5 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems6 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker6 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker7 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems7 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems8 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker8 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker9 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems9 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems10 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker10 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker11 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems11 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems12 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker12 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker13 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems13 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems14 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker14 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker15 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems15 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems16 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker16 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker17 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems17 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems18 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker18 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker19 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems19 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems20 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker20 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker21 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems21 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems22 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker22 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker23 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems23 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems24 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker24 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker25 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems25 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems26 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker26 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker27 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems27 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems28 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker28 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker29 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems29 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems30 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker30 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker31 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems31 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems32 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker32 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker33 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems33 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems34 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker34 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker35 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems35 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems36 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker36 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim DesignerRectTracker37 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Dim CBlendItems37 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim CBlendItems38 As Theremino_MCA.cBlendItems = New Theremino_MCA.cBlendItems
        Dim DesignerRectTracker38 As Theremino_MCA.DesignerRectTracker = New Theremino_MCA.DesignerRectTracker
        Me.TimerDraw = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox_Params = New System.Windows.Forms.GroupBox
        Me.btn_IIR_Filter = New Theremino_MCA.MyButton
        Me.btn_IntegrationTime = New Theremino_MCA.MyButton
        Me.txt_IntegrationTime = New Theremino_MCA.MyTextBox
        Me.txt_DrawSpeed = New Theremino_MCA.MyTextBox
        Me.txt_IIR_Filter = New Theremino_MCA.MyTextBox
        Me.Label_DrawSpeed = New System.Windows.Forms.Label
        Me.Label_MinEnergy = New System.Windows.Forms.Label
        Me.txt_MinEnergy = New Theremino_MCA.MyTextBox
        Me.Label_CounterSlot = New System.Windows.Forms.Label
        Me.Pbox3 = New System.Windows.Forms.PictureBox
        Me.GroupBox_SpectrumData = New System.Windows.Forms.GroupBox
        Me.tk_EqMaster = New System.Windows.Forms.TrackBar
        Me.tk_LinMaster = New System.Windows.Forms.TrackBar
        Me.txt_LinMaster = New Theremino_MCA.MyTextBox
        Me.txt_EqMaster = New Theremino_MCA.MyTextBox
        Me.Panel_Dummy = New System.Windows.Forms.Panel
        Me.Label_Dummy = New System.Windows.Forms.Label
        Me.btn_Graph = New Theremino_MCA.MyButton
        Me.btn_cps = New Theremino_MCA.MyButton
        Me.txt_Zoom = New Theremino_MCA.MyTextBox
        Me.btn_BrowseSpectrum = New Theremino_MCA.MyButton
        Me.txt_AutoSave = New Theremino_MCA.MyTextBox
        Me.btn_AutoSave = New Theremino_MCA.MyButton
        Me.txt_MaxY = New Theremino_MCA.MyTextBox
        Me.btn_MaxY = New Theremino_MCA.MyButton
        Me.btn_Ylog = New Theremino_MCA.MyButton
        Me.PBox_Spectrum = New System.Windows.Forms.PictureBox
        Me.btn_Xlog = New Theremino_MCA.MyButton
        Me.btn_Reference3 = New Theremino_MCA.MyButton
        Me.btn_Reference2 = New Theremino_MCA.MyButton
        Me.btn_Reference1 = New Theremino_MCA.MyButton
        Me.btn_SaveAsBkg = New Theremino_MCA.MyButton
        Me.btn_UseBkg = New Theremino_MCA.MyButton
        Me.tk_MaxY = New System.Windows.Forms.TrackBar
        Me.Label_Vert1 = New System.Windows.Forms.Label
        Me.Label_Vert3 = New System.Windows.Forms.Label
        Me.Label_Vert2 = New System.Windows.Forms.Label
        Me.tk_Zoom = New System.Windows.Forms.TrackBar
        Me.Label_Zoom = New System.Windows.Forms.Label
        Me.Label_NumBins = New System.Windows.Forms.Label
        Me.Label_Sampling = New System.Windows.Forms.Label
        Me.Label_PulsePolarity = New System.Windows.Forms.Label
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_LoadConfiguration = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_SaveConfigurationAs = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_SaveImage = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_SavePlotImage = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_ExportPulseHeight = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_ImportToRef1 = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_ImportToRef2 = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_ImportToRef3 = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_File_ImportToBKG = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuTools_NoiseTest = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuTools_StartPulseSimulator = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_English = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Italian = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Francais = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Espanol = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Deutsch = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Chinese = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_Japanese = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_StartingGuide = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_PmtAdapters = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_SignalConditioning = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_MinimizingFWHM = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_TestAudioSignal = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_IsotopeIdentifier = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_Isotopes = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ToDoList = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_OpenProgramFolder = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton_SaveImage = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_AudioInputs = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_Export = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_ViewPulses = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_ViewEqualizers = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_Run = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_StartMeasure = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton_Identifier = New System.Windows.Forms.ToolStripButton
        Me.GroupBox_Info = New System.Windows.Forms.GroupBox
        Me.lbl_TotalSeconds = New System.Windows.Forms.Label
        Me.lbl_PulsesPerSec = New System.Windows.Forms.Label
        Me.lbl_TotalPulses = New System.Windows.Forms.Label
        Me.Label_TotalSeconds = New System.Windows.Forms.Label
        Me.Label_PulsesPerSec = New System.Windows.Forms.Label
        Me.Label_TotalPulses = New System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage_Operation = New System.Windows.Forms.TabPage
        Me.GroupBox_BaseLineTest = New System.Windows.Forms.GroupBox
        Me.Label_BLT_MaxNoise = New System.Windows.Forms.Label
        Me.btn_BLT_MaxSlope = New Theremino_MCA.MyButton
        Me.txt_BLT_MaxNoise = New Theremino_MCA.MyTextBox
        Me.chk_BltEnable = New System.Windows.Forms.CheckBox
        Me.txt_BLT_Size = New Theremino_MCA.MyTextBox
        Me.Label_BLT_Size = New System.Windows.Forms.Label
        Me.txt_BLT_Position = New Theremino_MCA.MyTextBox
        Me.Label_BLT_Position = New System.Windows.Forms.Label
        Me.txt_BLT_MaxSlope = New Theremino_MCA.MyTextBox
        Me.GroupBox_AudioInput = New System.Windows.Forms.GroupBox
        Me.cmb_AudioInDevices = New Theremino_MCA.MyComboBox
        Me.btn_InputSelection = New Theremino_MCA.MyButton
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.cmb_Bins = New Theremino_MCA.MyComboBox
        Me.cmb_Sampling = New Theremino_MCA.MyComboBox
        Me.cmb_PulsePolarity = New Theremino_MCA.MyComboBox
        Me.txt_AudioZero = New Theremino_MCA.MyTextBox
        Me.Label_AudioZero = New System.Windows.Forms.Label
        Me.txt_AudioGain = New Theremino_MCA.MyTextBox
        Me.Label_AudioGain = New System.Windows.Forms.Label
        Me.TabPage_Options = New System.Windows.Forms.TabPage
        Me.GroupBox_GaussianDec = New System.Windows.Forms.GroupBox
        Me.chk_GaussianDecEnable = New System.Windows.Forms.CheckBox
        Me.txt_DeconvSize = New Theremino_MCA.MyTextBox
        Me.Label_DeconvSize = New System.Windows.Forms.Label
        Me.Label_GaussianSize = New System.Windows.Forms.Label
        Me.txt_GaussianSize = New Theremino_MCA.MyTextBox
        Me.GroupBox_ResComp = New System.Windows.Forms.GroupBox
        Me.Label_ResCompSize = New System.Windows.Forms.Label
        Me.txt_ResCompSize = New Theremino_MCA.MyTextBox
        Me.Label_ResCompRight = New System.Windows.Forms.Label
        Me.txt_ResCompRight = New Theremino_MCA.MyTextBox
        Me.chk_ResCompEnable = New System.Windows.Forms.CheckBox
        Me.txt_ResCompCenter = New Theremino_MCA.MyTextBox
        Me.Label_ResCompCenter = New System.Windows.Forms.Label
        Me.Label_ResCompLeft = New System.Windows.Forms.Label
        Me.txt_ResCompLeft = New Theremino_MCA.MyTextBox
        Me.GroupBox_ScaleOptions = New System.Windows.Forms.GroupBox
        Me.chk_ThickLines = New System.Windows.Forms.CheckBox
        Me.txt_XlogExponent = New Theremino_MCA.MyTextBox
        Me.Label_XlogExponent = New System.Windows.Forms.Label
        Me.txt_YlogExponent = New Theremino_MCA.MyTextBox
        Me.Label_YlogExponent = New System.Windows.Forms.Label
        Me.GroupBox_Timers = New System.Windows.Forms.GroupBox
        Me.txt_StopTimer = New Theremino_MCA.MyTextBox
        Me.Label_StopTimer = New System.Windows.Forms.Label
        Me.GroupBox_ExportOptions = New System.Windows.Forms.GroupBox
        Me.chk_ExportWithHeader = New System.Windows.Forms.CheckBox
        Me.lbl_FieldSeparator = New System.Windows.Forms.Label
        Me.txt_FieldSeparator = New Theremino_MCA.MyTextBox
        Me.lbl_DecimalSeparator = New System.Windows.Forms.Label
        Me.txt_DecimalSeparator = New Theremino_MCA.MyTextBox
        Me.GroupBox_OutputSlots = New System.Windows.Forms.GroupBox
        Me.chk_OnlySelectedRows = New System.Windows.Forms.CheckBox
        Me.txt_BinsNumSlots = New Theremino_MCA.MyTextBox
        Me.Label_BinsNumSlots = New System.Windows.Forms.Label
        Me.txt_BinsFirstSlot = New Theremino_MCA.MyTextBox
        Me.Label_BinsFirstSlot = New System.Windows.Forms.Label
        Me.txt_SlotCounter = New Theremino_MCA.MyTextBox
        Me.TabPage_Isotopes = New System.Windows.Forms.TabPage
        Me.btn_EditSamplesRowsFile = New Theremino_MCA.MyButton
        Me.cmb_SampleRows = New Theremino_MCA.MyComboBox
        Me.btn_ExtendSelectedIsotope = New Theremino_MCA.MyButton
        Me.btn_ExtendCheckedRows = New Theremino_MCA.MyButton
        Me.btn_DeselectAllRows = New Theremino_MCA.MyButton
        Me.MyListView1 = New Theremino_MCA.MyListView
        Me.Timer1Sec = New System.Windows.Forms.Timer(Me.components)
        Me.txt_UserText = New System.Windows.Forms.TextBox
        Me.Timer10Hz = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.StatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.Menu_Language_Portoguese = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox_Params.SuspendLayout()
        CType(Me.Pbox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_SpectrumData.SuspendLayout()
        CType(Me.tk_EqMaster, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_LinMaster, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_Dummy.SuspendLayout()
        CType(Me.PBox_Spectrum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_MaxY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tk_Zoom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox_Info.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage_Operation.SuspendLayout()
        Me.GroupBox_BaseLineTest.SuspendLayout()
        Me.GroupBox_AudioInput.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabPage_Options.SuspendLayout()
        Me.GroupBox_GaussianDec.SuspendLayout()
        Me.GroupBox_ResComp.SuspendLayout()
        Me.GroupBox_ScaleOptions.SuspendLayout()
        Me.GroupBox_Timers.SuspendLayout()
        Me.GroupBox_ExportOptions.SuspendLayout()
        Me.GroupBox_OutputSlots.SuspendLayout()
        Me.TabPage_Isotopes.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TimerDraw
        '
        '
        'GroupBox_Params
        '
        Me.GroupBox_Params.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GroupBox_Params.Controls.Add(Me.btn_IIR_Filter)
        Me.GroupBox_Params.Controls.Add(Me.btn_IntegrationTime)
        Me.GroupBox_Params.Controls.Add(Me.txt_IntegrationTime)
        Me.GroupBox_Params.Controls.Add(Me.txt_DrawSpeed)
        Me.GroupBox_Params.Controls.Add(Me.txt_IIR_Filter)
        Me.GroupBox_Params.Controls.Add(Me.Label_DrawSpeed)
        Me.GroupBox_Params.Controls.Add(Me.Label_MinEnergy)
        Me.GroupBox_Params.Controls.Add(Me.txt_MinEnergy)
        Me.GroupBox_Params.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Params.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_Params.Location = New System.Drawing.Point(2, 311)
        Me.GroupBox_Params.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Params.Name = "GroupBox_Params"
        Me.GroupBox_Params.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Params.Size = New System.Drawing.Size(152, 87)
        Me.GroupBox_Params.TabIndex = 149
        Me.GroupBox_Params.TabStop = False
        Me.GroupBox_Params.Text = "Params"
        '
        'btn_IIR_Filter
        '
        Me.btn_IIR_Filter.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker41.IsActive = True
        DesignerRectTracker41.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker41.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_IIR_Filter.CenterPtTracker = DesignerRectTracker41
        Me.btn_IIR_Filter.CheckButton = True
        Me.btn_IIR_Filter.Checked = True
        CBlendItems41.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems41.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_IIR_Filter.ColorFillBlend = CBlendItems41
        CBlendItems42.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems42.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_IIR_Filter.ColorFillBlendChecked = CBlendItems42
        Me.btn_IIR_Filter.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_IIR_Filter.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_IIR_Filter.Corners.All = CType(6, Short)
        Me.btn_IIR_Filter.Corners.LowerLeft = CType(6, Short)
        Me.btn_IIR_Filter.Corners.LowerRight = CType(6, Short)
        Me.btn_IIR_Filter.Corners.UpperLeft = CType(6, Short)
        Me.btn_IIR_Filter.Corners.UpperRight = CType(6, Short)
        Me.btn_IIR_Filter.DimFactorGray = -10
        Me.btn_IIR_Filter.DimFactorOver = 30
        Me.btn_IIR_Filter.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_IIR_Filter.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_IIR_Filter.FocalPoints.CenterPtX = 0.0!
        Me.btn_IIR_Filter.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_IIR_Filter.FocalPoints.FocusPtX = 0.0!
        Me.btn_IIR_Filter.FocalPoints.FocusPtY = 0.0!
        Me.btn_IIR_Filter.FocalPointsChecked.CenterPtX = 0.5483871!
        Me.btn_IIR_Filter.FocalPointsChecked.CenterPtY = 0.6470588!
        Me.btn_IIR_Filter.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_IIR_Filter.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker42.IsActive = False
        DesignerRectTracker42.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker42.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_IIR_Filter.FocusPtTracker = DesignerRectTracker42
        Me.btn_IIR_Filter.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_IIR_Filter.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_IIR_Filter.Image = Nothing
        Me.btn_IIR_Filter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_IIR_Filter.ImageIndex = 0
        Me.btn_IIR_Filter.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_IIR_Filter.Location = New System.Drawing.Point(4, 65)
        Me.btn_IIR_Filter.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_IIR_Filter.Name = "btn_IIR_Filter"
        Me.btn_IIR_Filter.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_IIR_Filter.SideImage = Nothing
        Me.btn_IIR_Filter.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_IIR_Filter.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_IIR_Filter.Size = New System.Drawing.Size(93, 17)
        Me.btn_IIR_Filter.TabIndex = 174
        Me.btn_IIR_Filter.Text = "IIR Filter (%)"
        Me.btn_IIR_Filter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_IIR_Filter.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_IIR_Filter.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_IIR_Filter.TextShadow = System.Drawing.Color.Transparent
        Me.btn_IIR_Filter.TextShadowChecked = System.Drawing.Color.Empty
        '
        'btn_IntegrationTime
        '
        Me.btn_IntegrationTime.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker1.IsActive = False
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_IntegrationTime.CenterPtTracker = DesignerRectTracker1
        Me.btn_IntegrationTime.CheckButton = True
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_IntegrationTime.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_IntegrationTime.ColorFillBlendChecked = CBlendItems2
        Me.btn_IntegrationTime.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_IntegrationTime.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_IntegrationTime.Corners.All = CType(6, Short)
        Me.btn_IntegrationTime.Corners.LowerLeft = CType(6, Short)
        Me.btn_IntegrationTime.Corners.LowerRight = CType(6, Short)
        Me.btn_IntegrationTime.Corners.UpperLeft = CType(6, Short)
        Me.btn_IntegrationTime.Corners.UpperRight = CType(6, Short)
        Me.btn_IntegrationTime.DimFactorGray = -10
        Me.btn_IntegrationTime.DimFactorOver = 30
        Me.btn_IntegrationTime.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_IntegrationTime.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_IntegrationTime.FocalPoints.CenterPtX = 0.0!
        Me.btn_IntegrationTime.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_IntegrationTime.FocalPoints.FocusPtX = 0.0!
        Me.btn_IntegrationTime.FocalPoints.FocusPtY = 0.0!
        Me.btn_IntegrationTime.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_IntegrationTime.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_IntegrationTime.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_IntegrationTime.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_IntegrationTime.FocusPtTracker = DesignerRectTracker2
        Me.btn_IntegrationTime.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_IntegrationTime.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_IntegrationTime.Image = Nothing
        Me.btn_IntegrationTime.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_IntegrationTime.ImageIndex = 0
        Me.btn_IntegrationTime.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_IntegrationTime.Location = New System.Drawing.Point(4, 14)
        Me.btn_IntegrationTime.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_IntegrationTime.Name = "btn_IntegrationTime"
        Me.btn_IntegrationTime.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_IntegrationTime.SideImage = Nothing
        Me.btn_IntegrationTime.SideImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btn_IntegrationTime.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_IntegrationTime.Size = New System.Drawing.Size(93, 17)
        Me.btn_IntegrationTime.TabIndex = 173
        Me.btn_IntegrationTime.Text = "Integration (sec)"
        Me.btn_IntegrationTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_IntegrationTime.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_IntegrationTime.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_IntegrationTime.TextShadow = System.Drawing.Color.Transparent
        Me.btn_IntegrationTime.TextShadowChecked = System.Drawing.Color.Empty
        '
        'txt_IntegrationTime
        '
        Me.txt_IntegrationTime.ArrowsIncrement = 1
        Me.txt_IntegrationTime.BackColor = System.Drawing.Color.MintCream
        Me.txt_IntegrationTime.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_IntegrationTime.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_IntegrationTime.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_IntegrationTime.ForeColor = System.Drawing.Color.Black
        Me.txt_IntegrationTime.Increment = 0.2
        Me.txt_IntegrationTime.Location = New System.Drawing.Point(105, 15)
        Me.txt_IntegrationTime.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_IntegrationTime.MaxValue = 9999
        Me.txt_IntegrationTime.MinValue = 10
        Me.txt_IntegrationTime.Name = "txt_IntegrationTime"
        Me.txt_IntegrationTime.NumericValue = 120
        Me.txt_IntegrationTime.NumericValueInteger = 120
        Me.txt_IntegrationTime.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_IntegrationTime.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_IntegrationTime.RoundingStep = 1
        Me.txt_IntegrationTime.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_IntegrationTime.Size = New System.Drawing.Size(37, 15)
        Me.txt_IntegrationTime.TabIndex = 23
        Me.txt_IntegrationTime.Text = "120"
        Me.txt_IntegrationTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_DrawSpeed
        '
        Me.txt_DrawSpeed.ArrowsIncrement = 1
        Me.txt_DrawSpeed.BackColor = System.Drawing.Color.MintCream
        Me.txt_DrawSpeed.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DrawSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DrawSpeed.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DrawSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_DrawSpeed.Increment = 0.2
        Me.txt_DrawSpeed.Location = New System.Drawing.Point(105, 32)
        Me.txt_DrawSpeed.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_DrawSpeed.MaxValue = 10
        Me.txt_DrawSpeed.MinValue = 1
        Me.txt_DrawSpeed.Name = "txt_DrawSpeed"
        Me.txt_DrawSpeed.NumericValue = 4
        Me.txt_DrawSpeed.NumericValueInteger = 4
        Me.txt_DrawSpeed.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DrawSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DrawSpeed.RoundingStep = 0
        Me.txt_DrawSpeed.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DrawSpeed.Size = New System.Drawing.Size(37, 15)
        Me.txt_DrawSpeed.TabIndex = 24
        Me.txt_DrawSpeed.Text = "4"
        Me.txt_DrawSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_IIR_Filter
        '
        Me.txt_IIR_Filter.ArrowsIncrement = 1
        Me.txt_IIR_Filter.BackColor = System.Drawing.Color.MintCream
        Me.txt_IIR_Filter.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_IIR_Filter.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_IIR_Filter.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_IIR_Filter.ForeColor = System.Drawing.Color.Black
        Me.txt_IIR_Filter.Increment = 0.2
        Me.txt_IIR_Filter.Location = New System.Drawing.Point(105, 66)
        Me.txt_IIR_Filter.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_IIR_Filter.MaxValue = 100
        Me.txt_IIR_Filter.MinValue = 0
        Me.txt_IIR_Filter.Name = "txt_IIR_Filter"
        Me.txt_IIR_Filter.NumericValue = 10
        Me.txt_IIR_Filter.NumericValueInteger = 10
        Me.txt_IIR_Filter.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_IIR_Filter.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_IIR_Filter.RoundingStep = 0
        Me.txt_IIR_Filter.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_IIR_Filter.Size = New System.Drawing.Size(37, 15)
        Me.txt_IIR_Filter.TabIndex = 26
        Me.txt_IIR_Filter.Text = "10"
        Me.txt_IIR_Filter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_DrawSpeed
        '
        Me.Label_DrawSpeed.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_DrawSpeed.ForeColor = System.Drawing.Color.Black
        Me.Label_DrawSpeed.Location = New System.Drawing.Point(4, 32)
        Me.Label_DrawSpeed.Name = "Label_DrawSpeed"
        Me.Label_DrawSpeed.Size = New System.Drawing.Size(97, 14)
        Me.Label_DrawSpeed.TabIndex = 170
        Me.Label_DrawSpeed.Text = "Draw speed (fps)"
        Me.Label_DrawSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_MinEnergy
        '
        Me.Label_MinEnergy.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MinEnergy.ForeColor = System.Drawing.Color.Black
        Me.Label_MinEnergy.Location = New System.Drawing.Point(4, 48)
        Me.Label_MinEnergy.Name = "Label_MinEnergy"
        Me.Label_MinEnergy.Size = New System.Drawing.Size(97, 14)
        Me.Label_MinEnergy.TabIndex = 164
        Me.Label_MinEnergy.Text = "Min. energy (KeV)"
        Me.Label_MinEnergy.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_MinEnergy
        '
        Me.txt_MinEnergy.ArrowsIncrement = 1
        Me.txt_MinEnergy.BackColor = System.Drawing.Color.MintCream
        Me.txt_MinEnergy.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MinEnergy.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MinEnergy.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MinEnergy.ForeColor = System.Drawing.Color.Black
        Me.txt_MinEnergy.Increment = 0.2
        Me.txt_MinEnergy.Location = New System.Drawing.Point(105, 48)
        Me.txt_MinEnergy.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_MinEnergy.MaxValue = 2000
        Me.txt_MinEnergy.MinValue = 0
        Me.txt_MinEnergy.Name = "txt_MinEnergy"
        Me.txt_MinEnergy.NumericValue = 10
        Me.txt_MinEnergy.NumericValueInteger = 10
        Me.txt_MinEnergy.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MinEnergy.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MinEnergy.RoundingStep = 0
        Me.txt_MinEnergy.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MinEnergy.Size = New System.Drawing.Size(37, 15)
        Me.txt_MinEnergy.TabIndex = 25
        Me.txt_MinEnergy.Text = "10"
        Me.txt_MinEnergy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_CounterSlot
        '
        Me.Label_CounterSlot.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_CounterSlot.ForeColor = System.Drawing.Color.Black
        Me.Label_CounterSlot.Location = New System.Drawing.Point(4, 18)
        Me.Label_CounterSlot.Name = "Label_CounterSlot"
        Me.Label_CounterSlot.Size = New System.Drawing.Size(91, 13)
        Me.Label_CounterSlot.TabIndex = 134
        Me.Label_CounterSlot.Text = "Counter slot"
        Me.Label_CounterSlot.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Pbox3
        '
        Me.Pbox3.BackColor = System.Drawing.Color.MintCream
        Me.Pbox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pbox3.Location = New System.Drawing.Point(15, 21)
        Me.Pbox3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Pbox3.Name = "Pbox3"
        Me.Pbox3.Size = New System.Drawing.Size(18, 79)
        Me.Pbox3.TabIndex = 19
        Me.Pbox3.TabStop = False
        '
        'GroupBox_SpectrumData
        '
        Me.GroupBox_SpectrumData.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_SpectrumData.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_SpectrumData.Controls.Add(Me.tk_EqMaster)
        Me.GroupBox_SpectrumData.Controls.Add(Me.tk_LinMaster)
        Me.GroupBox_SpectrumData.Controls.Add(Me.txt_LinMaster)
        Me.GroupBox_SpectrumData.Controls.Add(Me.txt_EqMaster)
        Me.GroupBox_SpectrumData.Controls.Add(Me.Panel_Dummy)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_Graph)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_cps)
        Me.GroupBox_SpectrumData.Controls.Add(Me.txt_Zoom)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_BrowseSpectrum)
        Me.GroupBox_SpectrumData.Controls.Add(Me.txt_AutoSave)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_AutoSave)
        Me.GroupBox_SpectrumData.Controls.Add(Me.txt_MaxY)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_MaxY)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_Ylog)
        Me.GroupBox_SpectrumData.Controls.Add(Me.PBox_Spectrum)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_Xlog)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_Reference3)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_Reference2)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_Reference1)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_SaveAsBkg)
        Me.GroupBox_SpectrumData.Controls.Add(Me.btn_UseBkg)
        Me.GroupBox_SpectrumData.Controls.Add(Me.tk_MaxY)
        Me.GroupBox_SpectrumData.Controls.Add(Me.Label_Vert1)
        Me.GroupBox_SpectrumData.Controls.Add(Me.Label_Vert3)
        Me.GroupBox_SpectrumData.Controls.Add(Me.Label_Vert2)
        Me.GroupBox_SpectrumData.Controls.Add(Me.tk_Zoom)
        Me.GroupBox_SpectrumData.Controls.Add(Me.Label_Zoom)
        Me.GroupBox_SpectrumData.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_SpectrumData.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox_SpectrumData.Location = New System.Drawing.Point(171, 57)
        Me.GroupBox_SpectrumData.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_SpectrumData.Name = "GroupBox_SpectrumData"
        Me.GroupBox_SpectrumData.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_SpectrumData.Size = New System.Drawing.Size(607, 517)
        Me.GroupBox_SpectrumData.TabIndex = 152
        Me.GroupBox_SpectrumData.TabStop = False
        Me.GroupBox_SpectrumData.Text = "Spectrum data"
        '
        'tk_EqMaster
        '
        Me.tk_EqMaster.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tk_EqMaster.AutoSize = False
        Me.tk_EqMaster.LargeChange = 50
        Me.tk_EqMaster.Location = New System.Drawing.Point(565, 169)
        Me.tk_EqMaster.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tk_EqMaster.Maximum = 1000
        Me.tk_EqMaster.Minimum = -1000
        Me.tk_EqMaster.Name = "tk_EqMaster"
        Me.tk_EqMaster.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_EqMaster.Size = New System.Drawing.Size(29, 125)
        Me.tk_EqMaster.SmallChange = 10
        Me.tk_EqMaster.TabIndex = 59
        Me.tk_EqMaster.TickFrequency = 200
        Me.tk_EqMaster.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        '
        'tk_LinMaster
        '
        Me.tk_LinMaster.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tk_LinMaster.AutoSize = False
        Me.tk_LinMaster.Location = New System.Drawing.Point(565, 335)
        Me.tk_LinMaster.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tk_LinMaster.Maximum = 3000
        Me.tk_LinMaster.Minimum = 300
        Me.tk_LinMaster.Name = "tk_LinMaster"
        Me.tk_LinMaster.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_LinMaster.Size = New System.Drawing.Size(29, 125)
        Me.tk_LinMaster.TabIndex = 58
        Me.tk_LinMaster.TickFrequency = 90
        Me.tk_LinMaster.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tk_LinMaster.Value = 750
        '
        'txt_LinMaster
        '
        Me.txt_LinMaster.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_LinMaster.ArrowsIncrement = 1
        Me.txt_LinMaster.BackColor = System.Drawing.Color.White
        Me.txt_LinMaster.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_LinMaster.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_LinMaster.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_LinMaster.ForeColor = System.Drawing.Color.Black
        Me.txt_LinMaster.Increment = 1
        Me.txt_LinMaster.Location = New System.Drawing.Point(570, 460)
        Me.txt_LinMaster.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_LinMaster.MaxValue = 3000
        Me.txt_LinMaster.MinValue = 300
        Me.txt_LinMaster.Name = "txt_LinMaster"
        Me.txt_LinMaster.NumericValue = 750
        Me.txt_LinMaster.NumericValueInteger = 750
        Me.txt_LinMaster.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_LinMaster.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_LinMaster.RoundingStep = 1
        Me.txt_LinMaster.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_LinMaster.Size = New System.Drawing.Size(32, 14)
        Me.txt_LinMaster.TabIndex = 168
        Me.txt_LinMaster.Text = "750"
        Me.txt_LinMaster.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_EqMaster
        '
        Me.txt_EqMaster.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_EqMaster.ArrowsIncrement = 10
        Me.txt_EqMaster.BackColor = System.Drawing.Color.White
        Me.txt_EqMaster.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_EqMaster.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_EqMaster.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_EqMaster.ForeColor = System.Drawing.Color.Black
        Me.txt_EqMaster.Increment = 50
        Me.txt_EqMaster.Location = New System.Drawing.Point(570, 294)
        Me.txt_EqMaster.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_EqMaster.MaxValue = 1000
        Me.txt_EqMaster.MinValue = -999
        Me.txt_EqMaster.Name = "txt_EqMaster"
        Me.txt_EqMaster.NumericValue = 0
        Me.txt_EqMaster.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_EqMaster.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_EqMaster.RoundingStep = 1
        Me.txt_EqMaster.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_EqMaster.Size = New System.Drawing.Size(32, 14)
        Me.txt_EqMaster.TabIndex = 169
        Me.txt_EqMaster.Text = "0"
        Me.txt_EqMaster.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel_Dummy
        '
        Me.Panel_Dummy.BackColor = System.Drawing.Color.Transparent
        Me.Panel_Dummy.Controls.Add(Me.Label_Dummy)
        Me.Panel_Dummy.Location = New System.Drawing.Point(294, 4)
        Me.Panel_Dummy.Name = "Panel_Dummy"
        Me.Panel_Dummy.Size = New System.Drawing.Size(18, 14)
        Me.Panel_Dummy.TabIndex = 174
        '
        'Label_Dummy
        '
        Me.Label_Dummy.AutoSize = True
        Me.Label_Dummy.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Dummy.ForeColor = System.Drawing.Color.Transparent
        Me.Label_Dummy.Location = New System.Drawing.Point(9, 6)
        Me.Label_Dummy.Name = "Label_Dummy"
        Me.Label_Dummy.Size = New System.Drawing.Size(0, 13)
        Me.Label_Dummy.TabIndex = 0
        '
        'btn_Graph
        '
        Me.btn_Graph.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Graph.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Graph.CenterPtTracker = DesignerRectTracker3
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Graph.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Graph.ColorFillBlendChecked = CBlendItems4
        Me.btn_Graph.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Graph.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Graph.Corners.All = CType(6, Short)
        Me.btn_Graph.Corners.LowerLeft = CType(6, Short)
        Me.btn_Graph.Corners.LowerRight = CType(6, Short)
        Me.btn_Graph.Corners.UpperLeft = CType(6, Short)
        Me.btn_Graph.Corners.UpperRight = CType(6, Short)
        Me.btn_Graph.DimFactorGray = -10
        Me.btn_Graph.DimFactorOver = 30
        Me.btn_Graph.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Graph.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Graph.FocalPoints.CenterPtX = 0.0!
        Me.btn_Graph.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_Graph.FocalPoints.FocusPtX = 0.0!
        Me.btn_Graph.FocalPoints.FocusPtY = 0.0!
        Me.btn_Graph.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_Graph.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_Graph.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Graph.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Graph.FocusPtTracker = DesignerRectTracker4
        Me.btn_Graph.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Graph.Image = Nothing
        Me.btn_Graph.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Graph.ImageIndex = 0
        Me.btn_Graph.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Graph.Location = New System.Drawing.Point(401, 0)
        Me.btn_Graph.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_Graph.Name = "btn_Graph"
        Me.btn_Graph.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_Graph.SideImage = Nothing
        Me.btn_Graph.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Graph.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Graph.Size = New System.Drawing.Size(50, 18)
        Me.btn_Graph.TabIndex = 171
        Me.btn_Graph.Text = "Line"
        Me.btn_Graph.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Graph.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Graph.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Graph.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_cps
        '
        Me.btn_cps.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_cps.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_cps.CenterPtTracker = DesignerRectTracker5
        Me.btn_cps.CheckButton = True
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_cps.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_cps.ColorFillBlendChecked = CBlendItems6
        Me.btn_cps.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_cps.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_cps.Corners.All = CType(6, Short)
        Me.btn_cps.Corners.LowerLeft = CType(6, Short)
        Me.btn_cps.Corners.LowerRight = CType(6, Short)
        Me.btn_cps.Corners.UpperLeft = CType(6, Short)
        Me.btn_cps.Corners.UpperRight = CType(6, Short)
        Me.btn_cps.DimFactorGray = -10
        Me.btn_cps.DimFactorOver = 30
        Me.btn_cps.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_cps.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_cps.FocalPoints.CenterPtX = 0.0!
        Me.btn_cps.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_cps.FocalPoints.FocusPtX = 0.0!
        Me.btn_cps.FocalPoints.FocusPtY = 0.0!
        Me.btn_cps.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_cps.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_cps.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_cps.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_cps.FocusPtTracker = DesignerRectTracker6
        Me.btn_cps.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_cps.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_cps.Image = Nothing
        Me.btn_cps.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_cps.ImageIndex = 0
        Me.btn_cps.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_cps.Location = New System.Drawing.Point(460, 0)
        Me.btn_cps.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_cps.Name = "btn_cps"
        Me.btn_cps.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_cps.SideImage = Nothing
        Me.btn_cps.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_cps.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_cps.Size = New System.Drawing.Size(38, 18)
        Me.btn_cps.TabIndex = 170
        Me.btn_cps.Text = "cps"
        Me.btn_cps.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_cps.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_cps.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_cps.TextShadow = System.Drawing.Color.Transparent
        Me.btn_cps.TextShadowChecked = System.Drawing.Color.Empty
        '
        'txt_Zoom
        '
        Me.txt_Zoom.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_Zoom.ArrowsIncrement = 1
        Me.txt_Zoom.BackColor = System.Drawing.Color.White
        Me.txt_Zoom.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Zoom.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Zoom.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Zoom.ForeColor = System.Drawing.Color.Black
        Me.txt_Zoom.Increment = 10
        Me.txt_Zoom.Location = New System.Drawing.Point(567, 490)
        Me.txt_Zoom.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_Zoom.MaxValue = 1000
        Me.txt_Zoom.MinValue = 0
        Me.txt_Zoom.Name = "txt_Zoom"
        Me.txt_Zoom.NumericValue = 380
        Me.txt_Zoom.NumericValueInteger = 380
        Me.txt_Zoom.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Zoom.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Zoom.RoundingStep = 1
        Me.txt_Zoom.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Zoom.Size = New System.Drawing.Size(32, 14)
        Me.txt_Zoom.TabIndex = 167
        Me.txt_Zoom.Text = "380"
        Me.txt_Zoom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_BrowseSpectrum
        '
        Me.btn_BrowseSpectrum.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BrowseSpectrum.CenterPtTracker = DesignerRectTracker7
        Me.btn_BrowseSpectrum.CheckButton = True
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_BrowseSpectrum.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_BrowseSpectrum.ColorFillBlendChecked = CBlendItems8
        Me.btn_BrowseSpectrum.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BrowseSpectrum.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BrowseSpectrum.Corners.All = CType(6, Short)
        Me.btn_BrowseSpectrum.Corners.LowerLeft = CType(6, Short)
        Me.btn_BrowseSpectrum.Corners.LowerRight = CType(6, Short)
        Me.btn_BrowseSpectrum.Corners.UpperLeft = CType(6, Short)
        Me.btn_BrowseSpectrum.Corners.UpperRight = CType(6, Short)
        Me.btn_BrowseSpectrum.DimFactorGray = -10
        Me.btn_BrowseSpectrum.DimFactorOver = 30
        Me.btn_BrowseSpectrum.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_BrowseSpectrum.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_BrowseSpectrum.FocalPoints.CenterPtX = 0.0!
        Me.btn_BrowseSpectrum.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_BrowseSpectrum.FocalPoints.FocusPtX = 0.0!
        Me.btn_BrowseSpectrum.FocalPoints.FocusPtY = 0.0!
        Me.btn_BrowseSpectrum.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_BrowseSpectrum.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_BrowseSpectrum.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BrowseSpectrum.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BrowseSpectrum.FocusPtTracker = DesignerRectTracker8
        Me.btn_BrowseSpectrum.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_BrowseSpectrum.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_BrowseSpectrum.Image = Nothing
        Me.btn_BrowseSpectrum.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BrowseSpectrum.ImageIndex = 0
        Me.btn_BrowseSpectrum.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BrowseSpectrum.Location = New System.Drawing.Point(223, 0)
        Me.btn_BrowseSpectrum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_BrowseSpectrum.Name = "btn_BrowseSpectrum"
        Me.btn_BrowseSpectrum.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_BrowseSpectrum.SideImage = Nothing
        Me.btn_BrowseSpectrum.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BrowseSpectrum.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_BrowseSpectrum.Size = New System.Drawing.Size(56, 18)
        Me.btn_BrowseSpectrum.TabIndex = 65
        Me.btn_BrowseSpectrum.Text = "Browse"
        Me.btn_BrowseSpectrum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BrowseSpectrum.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_BrowseSpectrum.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BrowseSpectrum.TextShadow = System.Drawing.Color.Transparent
        Me.btn_BrowseSpectrum.TextShadowChecked = System.Drawing.Color.Empty
        '
        'txt_AutoSave
        '
        Me.txt_AutoSave.ArrowsIncrement = 10
        Me.txt_AutoSave.BackColor = System.Drawing.Color.White
        Me.txt_AutoSave.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AutoSave.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AutoSave.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AutoSave.ForeColor = System.Drawing.Color.Black
        Me.txt_AutoSave.Increment = 10
        Me.txt_AutoSave.Location = New System.Drawing.Point(165, 3)
        Me.txt_AutoSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_AutoSave.MaxValue = 90000000
        Me.txt_AutoSave.MinValue = 10
        Me.txt_AutoSave.Name = "txt_AutoSave"
        Me.txt_AutoSave.NumericValue = 600
        Me.txt_AutoSave.NumericValueInteger = 600
        Me.txt_AutoSave.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AutoSave.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AutoSave.RoundingStep = 10
        Me.txt_AutoSave.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AutoSave.Size = New System.Drawing.Size(46, 14)
        Me.txt_AutoSave.TabIndex = 64
        Me.txt_AutoSave.Text = "600"
        Me.txt_AutoSave.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_AutoSave
        '
        Me.btn_AutoSave.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_AutoSave.CenterPtTracker = DesignerRectTracker9
        Me.btn_AutoSave.CheckButton = True
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_AutoSave.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_AutoSave.ColorFillBlendChecked = CBlendItems10
        Me.btn_AutoSave.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_AutoSave.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_AutoSave.Corners.All = CType(6, Short)
        Me.btn_AutoSave.Corners.LowerLeft = CType(6, Short)
        Me.btn_AutoSave.Corners.LowerRight = CType(6, Short)
        Me.btn_AutoSave.Corners.UpperLeft = CType(6, Short)
        Me.btn_AutoSave.Corners.UpperRight = CType(6, Short)
        Me.btn_AutoSave.DimFactorGray = -10
        Me.btn_AutoSave.DimFactorOver = 30
        Me.btn_AutoSave.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_AutoSave.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_AutoSave.FocalPoints.CenterPtX = 0.0!
        Me.btn_AutoSave.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_AutoSave.FocalPoints.FocusPtX = 0.0!
        Me.btn_AutoSave.FocalPoints.FocusPtY = 0.0!
        Me.btn_AutoSave.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_AutoSave.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_AutoSave.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_AutoSave.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker10.IsActive = False
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_AutoSave.FocusPtTracker = DesignerRectTracker10
        Me.btn_AutoSave.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_AutoSave.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_AutoSave.Image = Nothing
        Me.btn_AutoSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_AutoSave.ImageIndex = 0
        Me.btn_AutoSave.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_AutoSave.Location = New System.Drawing.Point(98, 0)
        Me.btn_AutoSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_AutoSave.Name = "btn_AutoSave"
        Me.btn_AutoSave.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_AutoSave.SideImage = Nothing
        Me.btn_AutoSave.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_AutoSave.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_AutoSave.Size = New System.Drawing.Size(61, 18)
        Me.btn_AutoSave.TabIndex = 63
        Me.btn_AutoSave.Text = "AutoSave"
        Me.btn_AutoSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_AutoSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_AutoSave.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_AutoSave.TextShadow = System.Drawing.Color.Transparent
        Me.btn_AutoSave.TextShadowChecked = System.Drawing.Color.Empty
        '
        'txt_MaxY
        '
        Me.txt_MaxY.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_MaxY.ArrowsIncrement = 1
        Me.txt_MaxY.BackColor = System.Drawing.Color.White
        Me.txt_MaxY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_MaxY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_MaxY.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_MaxY.ForeColor = System.Drawing.Color.Black
        Me.txt_MaxY.Increment = 1
        Me.txt_MaxY.Location = New System.Drawing.Point(552, 3)
        Me.txt_MaxY.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_MaxY.MaxValue = 90000000
        Me.txt_MaxY.MinValue = 10
        Me.txt_MaxY.Name = "txt_MaxY"
        Me.txt_MaxY.NumericValue = 10
        Me.txt_MaxY.NumericValueInteger = 10
        Me.txt_MaxY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_MaxY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_MaxY.RoundingStep = 1
        Me.txt_MaxY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_MaxY.Size = New System.Drawing.Size(55, 14)
        Me.txt_MaxY.TabIndex = 62
        Me.txt_MaxY.Text = "10"
        Me.txt_MaxY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_MaxY
        '
        Me.btn_MaxY.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_MaxY.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_MaxY.CenterPtTracker = DesignerRectTracker11
        Me.btn_MaxY.CheckButton = True
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_MaxY.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_MaxY.ColorFillBlendChecked = CBlendItems12
        Me.btn_MaxY.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_MaxY.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_MaxY.Corners.All = CType(6, Short)
        Me.btn_MaxY.Corners.LowerLeft = CType(6, Short)
        Me.btn_MaxY.Corners.LowerRight = CType(6, Short)
        Me.btn_MaxY.Corners.UpperLeft = CType(6, Short)
        Me.btn_MaxY.Corners.UpperRight = CType(6, Short)
        Me.btn_MaxY.DimFactorGray = -10
        Me.btn_MaxY.DimFactorOver = 30
        Me.btn_MaxY.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_MaxY.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_MaxY.FocalPoints.CenterPtX = 0.0!
        Me.btn_MaxY.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_MaxY.FocalPoints.FocusPtX = 0.0!
        Me.btn_MaxY.FocalPoints.FocusPtY = 0.0!
        Me.btn_MaxY.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_MaxY.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_MaxY.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_MaxY.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_MaxY.FocusPtTracker = DesignerRectTracker12
        Me.btn_MaxY.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_MaxY.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_MaxY.Image = Nothing
        Me.btn_MaxY.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_MaxY.ImageIndex = 0
        Me.btn_MaxY.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_MaxY.Location = New System.Drawing.Point(504, 0)
        Me.btn_MaxY.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_MaxY.Name = "btn_MaxY"
        Me.btn_MaxY.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_MaxY.SideImage = Nothing
        Me.btn_MaxY.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_MaxY.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_MaxY.Size = New System.Drawing.Size(43, 18)
        Me.btn_MaxY.TabIndex = 61
        Me.btn_MaxY.Text = "  Max"
        Me.btn_MaxY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_MaxY.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_MaxY.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_MaxY.TextShadow = System.Drawing.Color.Transparent
        Me.btn_MaxY.TextShadowChecked = System.Drawing.Color.Empty
        '
        'btn_Ylog
        '
        Me.btn_Ylog.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Ylog.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker13.IsActive = False
        DesignerRectTracker13.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker13.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Ylog.CenterPtTracker = DesignerRectTracker13
        Me.btn_Ylog.CheckButton = True
        CBlendItems13.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems13.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Ylog.ColorFillBlend = CBlendItems13
        CBlendItems14.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems14.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Ylog.ColorFillBlendChecked = CBlendItems14
        Me.btn_Ylog.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Ylog.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Ylog.Corners.All = CType(6, Short)
        Me.btn_Ylog.Corners.LowerLeft = CType(6, Short)
        Me.btn_Ylog.Corners.LowerRight = CType(6, Short)
        Me.btn_Ylog.Corners.UpperLeft = CType(6, Short)
        Me.btn_Ylog.Corners.UpperRight = CType(6, Short)
        Me.btn_Ylog.DimFactorGray = -10
        Me.btn_Ylog.DimFactorOver = 30
        Me.btn_Ylog.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Ylog.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Ylog.FocalPoints.CenterPtX = 0.0!
        Me.btn_Ylog.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_Ylog.FocalPoints.FocusPtX = 0.0!
        Me.btn_Ylog.FocalPoints.FocusPtY = 0.0!
        Me.btn_Ylog.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_Ylog.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_Ylog.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Ylog.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker14.IsActive = False
        DesignerRectTracker14.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker14.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Ylog.FocusPtTracker = DesignerRectTracker14
        Me.btn_Ylog.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Ylog.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Ylog.Image = CType(resources.GetObject("btn_Ylog.Image"), System.Drawing.Image)
        Me.btn_Ylog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Ylog.ImageIndex = 0
        Me.btn_Ylog.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Ylog.Location = New System.Drawing.Point(360, 491)
        Me.btn_Ylog.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_Ylog.Name = "btn_Ylog"
        Me.btn_Ylog.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_Ylog.SideImage = Nothing
        Me.btn_Ylog.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Ylog.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Ylog.Size = New System.Drawing.Size(48, 18)
        Me.btn_Ylog.TabIndex = 56
        Me.btn_Ylog.Text = ".  Ylog"
        Me.btn_Ylog.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Ylog.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Ylog.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Ylog.TextShadow = System.Drawing.Color.Transparent
        Me.btn_Ylog.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'PBox_Spectrum
        '
        Me.PBox_Spectrum.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PBox_Spectrum.BackColor = System.Drawing.Color.AliceBlue
        Me.PBox_Spectrum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PBox_Spectrum.Location = New System.Drawing.Point(1, 21)
        Me.PBox_Spectrum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PBox_Spectrum.Name = "PBox_Spectrum"
        Me.PBox_Spectrum.Size = New System.Drawing.Size(568, 462)
        Me.PBox_Spectrum.TabIndex = 0
        Me.PBox_Spectrum.TabStop = False
        '
        'btn_Xlog
        '
        Me.btn_Xlog.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Xlog.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker15.IsActive = False
        DesignerRectTracker15.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker15.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Xlog.CenterPtTracker = DesignerRectTracker15
        Me.btn_Xlog.CheckButton = True
        CBlendItems15.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems15.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Xlog.ColorFillBlend = CBlendItems15
        CBlendItems16.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems16.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Xlog.ColorFillBlendChecked = CBlendItems16
        Me.btn_Xlog.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Xlog.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Xlog.Corners.All = CType(6, Short)
        Me.btn_Xlog.Corners.LowerLeft = CType(6, Short)
        Me.btn_Xlog.Corners.LowerRight = CType(6, Short)
        Me.btn_Xlog.Corners.UpperLeft = CType(6, Short)
        Me.btn_Xlog.Corners.UpperRight = CType(6, Short)
        Me.btn_Xlog.DimFactorGray = -10
        Me.btn_Xlog.DimFactorOver = 30
        Me.btn_Xlog.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Xlog.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Xlog.FocalPoints.CenterPtX = 0.0!
        Me.btn_Xlog.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_Xlog.FocalPoints.FocusPtX = 0.0!
        Me.btn_Xlog.FocalPoints.FocusPtY = 0.0!
        Me.btn_Xlog.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_Xlog.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_Xlog.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Xlog.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker16.IsActive = False
        DesignerRectTracker16.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker16.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Xlog.FocusPtTracker = DesignerRectTracker16
        Me.btn_Xlog.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Xlog.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Xlog.Image = CType(resources.GetObject("btn_Xlog.Image"), System.Drawing.Image)
        Me.btn_Xlog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Xlog.ImageIndex = 0
        Me.btn_Xlog.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Xlog.Location = New System.Drawing.Point(309, 491)
        Me.btn_Xlog.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_Xlog.Name = "btn_Xlog"
        Me.btn_Xlog.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_Xlog.SideImage = Nothing
        Me.btn_Xlog.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Xlog.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Xlog.Size = New System.Drawing.Size(48, 18)
        Me.btn_Xlog.TabIndex = 55
        Me.btn_Xlog.Text = ".  Xlog"
        Me.btn_Xlog.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Xlog.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Xlog.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Xlog.TextShadow = System.Drawing.Color.Transparent
        Me.btn_Xlog.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_Reference3
        '
        Me.btn_Reference3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Reference3.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker17.IsActive = False
        DesignerRectTracker17.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker17.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Reference3.CenterPtTracker = DesignerRectTracker17
        Me.btn_Reference3.CheckButton = True
        CBlendItems17.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems17.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Reference3.ColorFillBlend = CBlendItems17
        CBlendItems18.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems18.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Reference3.ColorFillBlendChecked = CBlendItems18
        Me.btn_Reference3.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Reference3.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Reference3.Corners.All = CType(6, Short)
        Me.btn_Reference3.Corners.LowerLeft = CType(6, Short)
        Me.btn_Reference3.Corners.LowerRight = CType(6, Short)
        Me.btn_Reference3.Corners.UpperLeft = CType(6, Short)
        Me.btn_Reference3.Corners.UpperRight = CType(6, Short)
        Me.btn_Reference3.DimFactorGray = -10
        Me.btn_Reference3.DimFactorOver = 30
        Me.btn_Reference3.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Reference3.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Reference3.FocalPoints.CenterPtX = 0.0!
        Me.btn_Reference3.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_Reference3.FocalPoints.FocusPtX = 0.0!
        Me.btn_Reference3.FocalPoints.FocusPtY = 0.0!
        Me.btn_Reference3.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_Reference3.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_Reference3.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Reference3.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker18.IsActive = False
        DesignerRectTracker18.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker18.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Reference3.FocusPtTracker = DesignerRectTracker18
        Me.btn_Reference3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Reference3.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Reference3.Image = CType(resources.GetObject("btn_Reference3.Image"), System.Drawing.Image)
        Me.btn_Reference3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Reference3.ImageIndex = 0
        Me.btn_Reference3.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Reference3.Location = New System.Drawing.Point(110, 491)
        Me.btn_Reference3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_Reference3.Name = "btn_Reference3"
        Me.btn_Reference3.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_Reference3.SideImage = Nothing
        Me.btn_Reference3.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Reference3.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Reference3.Size = New System.Drawing.Size(49, 18)
        Me.btn_Reference3.TabIndex = 52
        Me.btn_Reference3.Text = ".   Ref 3"
        Me.btn_Reference3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Reference3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Reference3.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Reference3.TextShadow = System.Drawing.Color.Transparent
        Me.btn_Reference3.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_Reference2
        '
        Me.btn_Reference2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Reference2.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker19.IsActive = False
        DesignerRectTracker19.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker19.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Reference2.CenterPtTracker = DesignerRectTracker19
        Me.btn_Reference2.CheckButton = True
        CBlendItems19.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems19.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Reference2.ColorFillBlend = CBlendItems19
        CBlendItems20.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems20.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Reference2.ColorFillBlendChecked = CBlendItems20
        Me.btn_Reference2.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Reference2.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Reference2.Corners.All = CType(6, Short)
        Me.btn_Reference2.Corners.LowerLeft = CType(6, Short)
        Me.btn_Reference2.Corners.LowerRight = CType(6, Short)
        Me.btn_Reference2.Corners.UpperLeft = CType(6, Short)
        Me.btn_Reference2.Corners.UpperRight = CType(6, Short)
        Me.btn_Reference2.DimFactorGray = -10
        Me.btn_Reference2.DimFactorOver = 30
        Me.btn_Reference2.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Reference2.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Reference2.FocalPoints.CenterPtX = 0.0!
        Me.btn_Reference2.FocalPoints.CenterPtY = 0.5!
        Me.btn_Reference2.FocalPoints.FocusPtX = 0.0!
        Me.btn_Reference2.FocalPoints.FocusPtY = 0.0!
        Me.btn_Reference2.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_Reference2.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_Reference2.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Reference2.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker20.IsActive = False
        DesignerRectTracker20.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker20.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Reference2.FocusPtTracker = DesignerRectTracker20
        Me.btn_Reference2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Reference2.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Reference2.Image = CType(resources.GetObject("btn_Reference2.Image"), System.Drawing.Image)
        Me.btn_Reference2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Reference2.ImageIndex = 0
        Me.btn_Reference2.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Reference2.Location = New System.Drawing.Point(58, 491)
        Me.btn_Reference2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_Reference2.Name = "btn_Reference2"
        Me.btn_Reference2.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_Reference2.SideImage = Nothing
        Me.btn_Reference2.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Reference2.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Reference2.Size = New System.Drawing.Size(49, 18)
        Me.btn_Reference2.TabIndex = 51
        Me.btn_Reference2.Text = ".   Ref 2"
        Me.btn_Reference2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Reference2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Reference2.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Reference2.TextShadow = System.Drawing.Color.Transparent
        Me.btn_Reference2.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_Reference1
        '
        Me.btn_Reference1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_Reference1.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker21.IsActive = False
        DesignerRectTracker21.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker21.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Reference1.CenterPtTracker = DesignerRectTracker21
        Me.btn_Reference1.CheckButton = True
        CBlendItems21.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems21.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Reference1.ColorFillBlend = CBlendItems21
        CBlendItems22.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems22.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_Reference1.ColorFillBlendChecked = CBlendItems22
        Me.btn_Reference1.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Reference1.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Reference1.Corners.All = CType(6, Short)
        Me.btn_Reference1.Corners.LowerLeft = CType(6, Short)
        Me.btn_Reference1.Corners.LowerRight = CType(6, Short)
        Me.btn_Reference1.Corners.UpperLeft = CType(6, Short)
        Me.btn_Reference1.Corners.UpperRight = CType(6, Short)
        Me.btn_Reference1.DimFactorGray = -10
        Me.btn_Reference1.DimFactorOver = 30
        Me.btn_Reference1.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Reference1.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_Reference1.FocalPoints.CenterPtX = 0.0!
        Me.btn_Reference1.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_Reference1.FocalPoints.FocusPtX = 0.0!
        Me.btn_Reference1.FocalPoints.FocusPtY = 0.0!
        Me.btn_Reference1.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_Reference1.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_Reference1.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_Reference1.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker22.IsActive = False
        DesignerRectTracker22.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker22.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Reference1.FocusPtTracker = DesignerRectTracker22
        Me.btn_Reference1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Reference1.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_Reference1.Image = CType(resources.GetObject("btn_Reference1.Image"), System.Drawing.Image)
        Me.btn_Reference1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Reference1.ImageIndex = 0
        Me.btn_Reference1.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_Reference1.Location = New System.Drawing.Point(6, 491)
        Me.btn_Reference1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_Reference1.Name = "btn_Reference1"
        Me.btn_Reference1.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_Reference1.SideImage = Nothing
        Me.btn_Reference1.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Reference1.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Reference1.Size = New System.Drawing.Size(49, 18)
        Me.btn_Reference1.TabIndex = 50
        Me.btn_Reference1.Text = ".   Ref 1"
        Me.btn_Reference1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Reference1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_Reference1.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Reference1.TextShadow = System.Drawing.Color.Transparent
        Me.btn_Reference1.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_SaveAsBkg
        '
        Me.btn_SaveAsBkg.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_SaveAsBkg.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker23.IsActive = False
        DesignerRectTracker23.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker23.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SaveAsBkg.CenterPtTracker = DesignerRectTracker23
        Me.btn_SaveAsBkg.CheckButton = True
        CBlendItems23.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems23.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_SaveAsBkg.ColorFillBlend = CBlendItems23
        CBlendItems24.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems24.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_SaveAsBkg.ColorFillBlendChecked = CBlendItems24
        Me.btn_SaveAsBkg.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_SaveAsBkg.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_SaveAsBkg.Corners.All = CType(6, Short)
        Me.btn_SaveAsBkg.Corners.LowerLeft = CType(6, Short)
        Me.btn_SaveAsBkg.Corners.LowerRight = CType(6, Short)
        Me.btn_SaveAsBkg.Corners.UpperLeft = CType(6, Short)
        Me.btn_SaveAsBkg.Corners.UpperRight = CType(6, Short)
        Me.btn_SaveAsBkg.DimFactorGray = -10
        Me.btn_SaveAsBkg.DimFactorOver = 30
        Me.btn_SaveAsBkg.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_SaveAsBkg.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_SaveAsBkg.FocalPoints.CenterPtX = 1.0!
        Me.btn_SaveAsBkg.FocalPoints.CenterPtY = 1.0!
        Me.btn_SaveAsBkg.FocalPoints.FocusPtX = 0.0!
        Me.btn_SaveAsBkg.FocalPoints.FocusPtY = 0.0!
        Me.btn_SaveAsBkg.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_SaveAsBkg.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_SaveAsBkg.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_SaveAsBkg.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker24.IsActive = False
        DesignerRectTracker24.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker24.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_SaveAsBkg.FocusPtTracker = DesignerRectTracker24
        Me.btn_SaveAsBkg.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_SaveAsBkg.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_SaveAsBkg.Image = Nothing
        Me.btn_SaveAsBkg.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SaveAsBkg.ImageIndex = 0
        Me.btn_SaveAsBkg.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_SaveAsBkg.Location = New System.Drawing.Point(178, 491)
        Me.btn_SaveAsBkg.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_SaveAsBkg.Name = "btn_SaveAsBkg"
        Me.btn_SaveAsBkg.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_SaveAsBkg.SideImage = Nothing
        Me.btn_SaveAsBkg.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SaveAsBkg.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_SaveAsBkg.Size = New System.Drawing.Size(48, 18)
        Me.btn_SaveAsBkg.TabIndex = 53
        Me.btn_SaveAsBkg.TabStop = False
        Me.btn_SaveAsBkg.Text = "BKG"
        Me.btn_SaveAsBkg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_SaveAsBkg.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_SaveAsBkg.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_SaveAsBkg.TextShadow = System.Drawing.Color.Transparent
        Me.btn_SaveAsBkg.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'btn_UseBkg
        '
        Me.btn_UseBkg.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_UseBkg.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker25.IsActive = False
        DesignerRectTracker25.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker25.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_UseBkg.CenterPtTracker = DesignerRectTracker25
        Me.btn_UseBkg.CheckButton = True
        CBlendItems25.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems25.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_UseBkg.ColorFillBlend = CBlendItems25
        CBlendItems26.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems26.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_UseBkg.ColorFillBlendChecked = CBlendItems26
        Me.btn_UseBkg.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_UseBkg.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_UseBkg.Corners.All = CType(6, Short)
        Me.btn_UseBkg.Corners.LowerLeft = CType(6, Short)
        Me.btn_UseBkg.Corners.LowerRight = CType(6, Short)
        Me.btn_UseBkg.Corners.UpperLeft = CType(6, Short)
        Me.btn_UseBkg.Corners.UpperRight = CType(6, Short)
        Me.btn_UseBkg.DimFactorGray = -10
        Me.btn_UseBkg.DimFactorOver = 30
        Me.btn_UseBkg.Enabled = False
        Me.btn_UseBkg.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_UseBkg.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_UseBkg.FocalPoints.CenterPtX = 0.0!
        Me.btn_UseBkg.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_UseBkg.FocalPoints.FocusPtX = 0.0!
        Me.btn_UseBkg.FocalPoints.FocusPtY = 0.0!
        Me.btn_UseBkg.FocalPointsChecked.CenterPtX = 0.5!
        Me.btn_UseBkg.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_UseBkg.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_UseBkg.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker26.IsActive = False
        DesignerRectTracker26.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker26.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_UseBkg.FocusPtTracker = DesignerRectTracker26
        Me.btn_UseBkg.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_UseBkg.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_UseBkg.Image = Nothing
        Me.btn_UseBkg.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_UseBkg.ImageIndex = 0
        Me.btn_UseBkg.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_UseBkg.Location = New System.Drawing.Point(232, 491)
        Me.btn_UseBkg.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_UseBkg.Name = "btn_UseBkg"
        Me.btn_UseBkg.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_UseBkg.SideImage = Nothing
        Me.btn_UseBkg.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_UseBkg.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_UseBkg.Size = New System.Drawing.Size(61, 18)
        Me.btn_UseBkg.TabIndex = 54
        Me.btn_UseBkg.Text = "Use BKG"
        Me.btn_UseBkg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_UseBkg.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_UseBkg.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_UseBkg.TextShadow = System.Drawing.Color.Transparent
        Me.btn_UseBkg.TextShadowChecked = System.Drawing.Color.Transparent
        '
        'tk_MaxY
        '
        Me.tk_MaxY.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tk_MaxY.AutoSize = False
        Me.tk_MaxY.LargeChange = 1
        Me.tk_MaxY.Location = New System.Drawing.Point(565, 17)
        Me.tk_MaxY.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tk_MaxY.Maximum = 375
        Me.tk_MaxY.Minimum = 1
        Me.tk_MaxY.Name = "tk_MaxY"
        Me.tk_MaxY.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tk_MaxY.Size = New System.Drawing.Size(29, 125)
        Me.tk_MaxY.TabIndex = 172
        Me.tk_MaxY.TickFrequency = 38
        Me.tk_MaxY.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tk_MaxY.Value = 1
        '
        'Label_Vert1
        '
        Me.Label_Vert1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Vert1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Vert1.ForeColor = System.Drawing.Color.Black
        Me.Label_Vert1.Location = New System.Drawing.Point(593, 38)
        Me.Label_Vert1.Name = "Label_Vert1"
        Me.Label_Vert1.Size = New System.Drawing.Size(15, 62)
        Me.Label_Vert1.TabIndex = 175
        Me.Label_Vert1.Tag = "Max scale"
        Me.Label_Vert1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_Vert3
        '
        Me.Label_Vert3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Vert3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Vert3.ForeColor = System.Drawing.Color.Black
        Me.Label_Vert3.Location = New System.Drawing.Point(593, 358)
        Me.Label_Vert3.Name = "Label_Vert3"
        Me.Label_Vert3.Size = New System.Drawing.Size(15, 77)
        Me.Label_Vert3.TabIndex = 177
        Me.Label_Vert3.Tag = "Energy trimmer"
        Me.Label_Vert3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_Vert2
        '
        Me.Label_Vert2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Vert2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Vert2.ForeColor = System.Drawing.Color.Black
        Me.Label_Vert2.Location = New System.Drawing.Point(593, 188)
        Me.Label_Vert2.Name = "Label_Vert2"
        Me.Label_Vert2.Size = New System.Drawing.Size(15, 86)
        Me.Label_Vert2.TabIndex = 176
        Me.Label_Vert2.Tag = "Equalizer master"
        Me.Label_Vert2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tk_Zoom
        '
        Me.tk_Zoom.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tk_Zoom.AutoSize = False
        Me.tk_Zoom.LargeChange = 10
        Me.tk_Zoom.Location = New System.Drawing.Point(465, 478)
        Me.tk_Zoom.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tk_Zoom.Maximum = 1000
        Me.tk_Zoom.Name = "tk_Zoom"
        Me.tk_Zoom.Size = New System.Drawing.Size(108, 29)
        Me.tk_Zoom.TabIndex = 57
        Me.tk_Zoom.TickFrequency = 60
        Me.tk_Zoom.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.tk_Zoom.Value = 380
        '
        'Label_Zoom
        '
        Me.Label_Zoom.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Zoom.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Zoom.ForeColor = System.Drawing.Color.Black
        Me.Label_Zoom.Location = New System.Drawing.Point(486, 502)
        Me.Label_Zoom.Name = "Label_Zoom"
        Me.Label_Zoom.Size = New System.Drawing.Size(77, 16)
        Me.Label_Zoom.TabIndex = 178
        Me.Label_Zoom.Tag = "Equalizer master"
        Me.Label_Zoom.Text = "Zoom"
        Me.Label_Zoom.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'Label_NumBins
        '
        Me.Label_NumBins.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_NumBins.ForeColor = System.Drawing.Color.Black
        Me.Label_NumBins.Location = New System.Drawing.Point(38, 15)
        Me.Label_NumBins.Name = "Label_NumBins"
        Me.Label_NumBins.Size = New System.Drawing.Size(56, 13)
        Me.Label_NumBins.TabIndex = 140
        Me.Label_NumBins.Text = "Bins"
        Me.Label_NumBins.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_Sampling
        '
        Me.Label_Sampling.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Sampling.ForeColor = System.Drawing.Color.Black
        Me.Label_Sampling.Location = New System.Drawing.Point(38, 32)
        Me.Label_Sampling.Name = "Label_Sampling"
        Me.Label_Sampling.Size = New System.Drawing.Size(56, 13)
        Me.Label_Sampling.TabIndex = 139
        Me.Label_Sampling.Text = "Samp."
        Me.Label_Sampling.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_PulsePolarity
        '
        Me.Label_PulsePolarity.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_PulsePolarity.ForeColor = System.Drawing.Color.Black
        Me.Label_PulsePolarity.Location = New System.Drawing.Point(38, 51)
        Me.Label_PulsePolarity.Name = "Label_PulsePolarity"
        Me.Label_PulsePolarity.Size = New System.Drawing.Size(56, 13)
        Me.Label_PulsePolarity.TabIndex = 138
        Me.Label_PulsePolarity.Text = "Pulses"
        Me.Label_PulsePolarity.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Tools, Me.Menu_Language, Me.Menu_Help, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(784, 24)
        Me.MenuStrip1.TabIndex = 159
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File_LoadConfiguration, Me.Menu_File_SaveConfigurationAs, Me.ToolStripSeparator6, Me.Menu_File_SaveImage, Me.Menu_File_SavePlotImage, Me.ToolStripSeparator4, Me.Menu_File_ExportPulseHeight, Me.Menu_File_ImportToRef1, Me.Menu_File_ImportToRef2, Me.Menu_File_ImportToRef3, Me.Menu_File_ImportToBKG, Me.ToolStripSeparator2, Me.Menu_File_Exit})
        Me.Menu_File.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'Menu_File_LoadConfiguration
        '
        Me.Menu_File_LoadConfiguration.Image = CType(resources.GetObject("Menu_File_LoadConfiguration.Image"), System.Drawing.Image)
        Me.Menu_File_LoadConfiguration.Name = "Menu_File_LoadConfiguration"
        Me.Menu_File_LoadConfiguration.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_LoadConfiguration.Text = "Load configuration"
        '
        'Menu_File_SaveConfigurationAs
        '
        Me.Menu_File_SaveConfigurationAs.Image = CType(resources.GetObject("Menu_File_SaveConfigurationAs.Image"), System.Drawing.Image)
        Me.Menu_File_SaveConfigurationAs.Name = "Menu_File_SaveConfigurationAs"
        Me.Menu_File_SaveConfigurationAs.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_SaveConfigurationAs.Text = "Save configuration as"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(229, 6)
        '
        'Menu_File_SaveImage
        '
        Me.Menu_File_SaveImage.Image = CType(resources.GetObject("Menu_File_SaveImage.Image"), System.Drawing.Image)
        Me.Menu_File_SaveImage.Name = "Menu_File_SaveImage"
        Me.Menu_File_SaveImage.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_SaveImage.Text = "Save image"
        '
        'Menu_File_SavePlotImage
        '
        Me.Menu_File_SavePlotImage.Image = CType(resources.GetObject("Menu_File_SavePlotImage.Image"), System.Drawing.Image)
        Me.Menu_File_SavePlotImage.Name = "Menu_File_SavePlotImage"
        Me.Menu_File_SavePlotImage.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_SavePlotImage.Text = "Save plot area image"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(229, 6)
        '
        'Menu_File_ExportPulseHeight
        '
        Me.Menu_File_ExportPulseHeight.Image = CType(resources.GetObject("Menu_File_ExportPulseHeight.Image"), System.Drawing.Image)
        Me.Menu_File_ExportPulseHeight.Name = "Menu_File_ExportPulseHeight"
        Me.Menu_File_ExportPulseHeight.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_ExportPulseHeight.Text = "Export pulse height histogram"
        '
        'Menu_File_ImportToRef1
        '
        Me.Menu_File_ImportToRef1.Image = CType(resources.GetObject("Menu_File_ImportToRef1.Image"), System.Drawing.Image)
        Me.Menu_File_ImportToRef1.Name = "Menu_File_ImportToRef1"
        Me.Menu_File_ImportToRef1.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_ImportToRef1.Text = "Import to Ref-1"
        '
        'Menu_File_ImportToRef2
        '
        Me.Menu_File_ImportToRef2.Image = CType(resources.GetObject("Menu_File_ImportToRef2.Image"), System.Drawing.Image)
        Me.Menu_File_ImportToRef2.Name = "Menu_File_ImportToRef2"
        Me.Menu_File_ImportToRef2.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_ImportToRef2.Text = "Import to Ref-2"
        '
        'Menu_File_ImportToRef3
        '
        Me.Menu_File_ImportToRef3.Image = CType(resources.GetObject("Menu_File_ImportToRef3.Image"), System.Drawing.Image)
        Me.Menu_File_ImportToRef3.Name = "Menu_File_ImportToRef3"
        Me.Menu_File_ImportToRef3.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_ImportToRef3.Text = "Import to Ref-3"
        '
        'Menu_File_ImportToBKG
        '
        Me.Menu_File_ImportToBKG.Image = CType(resources.GetObject("Menu_File_ImportToBKG.Image"), System.Drawing.Image)
        Me.Menu_File_ImportToBKG.Name = "Menu_File_ImportToBKG"
        Me.Menu_File_ImportToBKG.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_ImportToBKG.Text = "Import to BKG"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(229, 6)
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Image = CType(resources.GetObject("Menu_File_Exit.Image"), System.Drawing.Image)
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(232, 22)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Tools
        '
        Me.Menu_Tools.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuTools_NoiseTest, Me.MenuTools_StartPulseSimulator})
        Me.Menu_Tools.Name = "Menu_Tools"
        Me.Menu_Tools.Size = New System.Drawing.Size(47, 20)
        Me.Menu_Tools.Text = "Tools"
        '
        'MenuTools_NoiseTest
        '
        Me.MenuTools_NoiseTest.Name = "MenuTools_NoiseTest"
        Me.MenuTools_NoiseTest.Size = New System.Drawing.Size(182, 22)
        Me.MenuTools_NoiseTest.Text = "Auto zero trim"
        '
        'MenuTools_StartPulseSimulator
        '
        Me.MenuTools_StartPulseSimulator.Name = "MenuTools_StartPulseSimulator"
        Me.MenuTools_StartPulseSimulator.Size = New System.Drawing.Size(182, 22)
        Me.MenuTools_StartPulseSimulator.Text = "Start pulse simulator"
        '
        'Menu_Language
        '
        Me.Menu_Language.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Language_English, Me.Menu_Language_Italian, Me.Menu_Language_Francais, Me.Menu_Language_Espanol, Me.Menu_Language_Portoguese, Me.Menu_Language_Deutsch, Me.Menu_Language_Japanese, Me.Menu_Language_Chinese})
        Me.Menu_Language.Name = "Menu_Language"
        Me.Menu_Language.Size = New System.Drawing.Size(71, 20)
        Me.Menu_Language.Text = "Language"
        '
        'Menu_Language_English
        '
        Me.Menu_Language_English.Image = CType(resources.GetObject("Menu_Language_English.Image"), System.Drawing.Image)
        Me.Menu_Language_English.Name = "Menu_Language_English"
        Me.Menu_Language_English.Size = New System.Drawing.Size(152, 22)
        Me.Menu_Language_English.Text = "English"
        '
        'Menu_Language_Italian
        '
        Me.Menu_Language_Italian.Image = CType(resources.GetObject("Menu_Language_Italian.Image"), System.Drawing.Image)
        Me.Menu_Language_Italian.Name = "Menu_Language_Italian"
        Me.Menu_Language_Italian.Size = New System.Drawing.Size(152, 22)
        Me.Menu_Language_Italian.Text = "Italiano"
        '
        'Menu_Language_Francais
        '
        Me.Menu_Language_Francais.Image = CType(resources.GetObject("Menu_Language_Francais.Image"), System.Drawing.Image)
        Me.Menu_Language_Francais.Name = "Menu_Language_Francais"
        Me.Menu_Language_Francais.Size = New System.Drawing.Size(152, 22)
        Me.Menu_Language_Francais.Text = "Francais"
        '
        'Menu_Language_Espanol
        '
        Me.Menu_Language_Espanol.Image = CType(resources.GetObject("Menu_Language_Espanol.Image"), System.Drawing.Image)
        Me.Menu_Language_Espanol.Name = "Menu_Language_Espanol"
        Me.Menu_Language_Espanol.Size = New System.Drawing.Size(152, 22)
        Me.Menu_Language_Espanol.Text = "Espanol"
        '
        'Menu_Language_Deutsch
        '
        Me.Menu_Language_Deutsch.Image = CType(resources.GetObject("Menu_Language_Deutsch.Image"), System.Drawing.Image)
        Me.Menu_Language_Deutsch.Name = "Menu_Language_Deutsch"
        Me.Menu_Language_Deutsch.Size = New System.Drawing.Size(152, 22)
        Me.Menu_Language_Deutsch.Text = "Deutsch"
        '
        'Menu_Language_Chinese
        '
        Me.Menu_Language_Chinese.Image = CType(resources.GetObject("Menu_Language_Chinese.Image"), System.Drawing.Image)
        Me.Menu_Language_Chinese.Name = "Menu_Language_Chinese"
        Me.Menu_Language_Chinese.Size = New System.Drawing.Size(152, 22)
        Me.Menu_Language_Chinese.Text = "Chinese"
        '
        'Menu_Language_Japanese
        '
        Me.Menu_Language_Japanese.Image = CType(resources.GetObject("Menu_Language_Japanese.Image"), System.Drawing.Image)
        Me.Menu_Language_Japanese.Name = "Menu_Language_Japanese"
        Me.Menu_Language_Japanese.Size = New System.Drawing.Size(152, 22)
        Me.Menu_Language_Japanese.Text = "Japanese"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp, Me.Menu_Help_StartingGuide, Me.Menu_Help_PmtAdapters, Me.Menu_Help_SignalConditioning, Me.Menu_Help_MinimizingFWHM, Me.Menu_Help_TestAudioSignal, Me.Menu_Help_IsotopeIdentifier, Me.ToolStripSeparator10, Me.Menu_Help_Isotopes, Me.Menu_Help_ToDoList, Me.ToolStripSeparator11, Me.Menu_Help_OpenProgramFolder})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(44, 20)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp
        '
        Me.Menu_Help_ProgramHelp.Image = CType(resources.GetObject("Menu_Help_ProgramHelp.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp.Name = "Menu_Help_ProgramHelp"
        Me.Menu_Help_ProgramHelp.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_ProgramHelp.Text = "Program help"
        '
        'Menu_Help_StartingGuide
        '
        Me.Menu_Help_StartingGuide.Image = CType(resources.GetObject("Menu_Help_StartingGuide.Image"), System.Drawing.Image)
        Me.Menu_Help_StartingGuide.Name = "Menu_Help_StartingGuide"
        Me.Menu_Help_StartingGuide.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_StartingGuide.Text = "Starting guide"
        '
        'Menu_Help_PmtAdapters
        '
        Me.Menu_Help_PmtAdapters.Image = CType(resources.GetObject("Menu_Help_PmtAdapters.Image"), System.Drawing.Image)
        Me.Menu_Help_PmtAdapters.Name = "Menu_Help_PmtAdapters"
        Me.Menu_Help_PmtAdapters.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_PmtAdapters.Text = "PMT adapters"
        '
        'Menu_Help_SignalConditioning
        '
        Me.Menu_Help_SignalConditioning.Image = CType(resources.GetObject("Menu_Help_SignalConditioning.Image"), System.Drawing.Image)
        Me.Menu_Help_SignalConditioning.Name = "Menu_Help_SignalConditioning"
        Me.Menu_Help_SignalConditioning.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_SignalConditioning.Text = "Signal conditioning"
        '
        'Menu_Help_MinimizingFWHM
        '
        Me.Menu_Help_MinimizingFWHM.AccessibleDescription = ""
        Me.Menu_Help_MinimizingFWHM.Image = CType(resources.GetObject("Menu_Help_MinimizingFWHM.Image"), System.Drawing.Image)
        Me.Menu_Help_MinimizingFWHM.Name = "Menu_Help_MinimizingFWHM"
        Me.Menu_Help_MinimizingFWHM.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_MinimizingFWHM.Text = "Minimizing FWHM"
        '
        'Menu_Help_TestAudioSignal
        '
        Me.Menu_Help_TestAudioSignal.Image = CType(resources.GetObject("Menu_Help_TestAudioSignal.Image"), System.Drawing.Image)
        Me.Menu_Help_TestAudioSignal.Name = "Menu_Help_TestAudioSignal"
        Me.Menu_Help_TestAudioSignal.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_TestAudioSignal.Text = "Test audio signal with DAA"
        '
        'Menu_Help_IsotopeIdentifier
        '
        Me.Menu_Help_IsotopeIdentifier.Image = CType(resources.GetObject("Menu_Help_IsotopeIdentifier.Image"), System.Drawing.Image)
        Me.Menu_Help_IsotopeIdentifier.Name = "Menu_Help_IsotopeIdentifier"
        Me.Menu_Help_IsotopeIdentifier.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_IsotopeIdentifier.Text = "Isotope identifier help"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(212, 6)
        '
        'Menu_Help_Isotopes
        '
        Me.Menu_Help_Isotopes.Image = CType(resources.GetObject("Menu_Help_Isotopes.Image"), System.Drawing.Image)
        Me.Menu_Help_Isotopes.Name = "Menu_Help_Isotopes"
        Me.Menu_Help_Isotopes.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_Isotopes.Text = "Isotopes"
        '
        'Menu_Help_ToDoList
        '
        Me.Menu_Help_ToDoList.Image = CType(resources.GetObject("Menu_Help_ToDoList.Image"), System.Drawing.Image)
        Me.Menu_Help_ToDoList.Name = "Menu_Help_ToDoList"
        Me.Menu_Help_ToDoList.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_ToDoList.Text = "ToDo list"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(212, 6)
        '
        'Menu_Help_OpenProgramFolder
        '
        Me.Menu_Help_OpenProgramFolder.Image = CType(resources.GetObject("Menu_Help_OpenProgramFolder.Image"), System.Drawing.Image)
        Me.Menu_Help_OpenProgramFolder.Name = "Menu_Help_OpenProgramFolder"
        Me.Menu_Help_OpenProgramFolder.Size = New System.Drawing.Size(215, 22)
        Me.Menu_Help_OpenProgramFolder.Text = "Open program folder"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(52, 20)
        Me.Menu_About.Text = "About"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton_SaveImage, Me.ToolStripSeparator5, Me.ToolStripButton_AudioInputs, Me.ToolStripSeparator12, Me.ToolStripButton_Export, Me.ToolStripSeparator3, Me.ToolStripButton_ViewPulses, Me.ToolStripSeparator7, Me.ToolStripButton_ViewEqualizers, Me.ToolStripSeparator9, Me.ToolStripButton_Run, Me.ToolStripSeparator8, Me.ToolStripButton_StartMeasure, Me.ToolStripSeparator1, Me.ToolStripButton_Identifier})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(784, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton_SaveImage
        '
        Me.ToolStripButton_SaveImage.Image = CType(resources.GetObject("ToolStripButton_SaveImage.Image"), System.Drawing.Image)
        Me.ToolStripButton_SaveImage.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_SaveImage.Name = "ToolStripButton_SaveImage"
        Me.ToolStripButton_SaveImage.Size = New System.Drawing.Size(87, 22)
        Me.ToolStripButton_SaveImage.Text = "Save image"
        Me.ToolStripButton_SaveImage.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_AudioInputs
        '
        Me.ToolStripButton_AudioInputs.Image = CType(resources.GetObject("ToolStripButton_AudioInputs.Image"), System.Drawing.Image)
        Me.ToolStripButton_AudioInputs.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_AudioInputs.Name = "ToolStripButton_AudioInputs"
        Me.ToolStripButton_AudioInputs.Size = New System.Drawing.Size(95, 22)
        Me.ToolStripButton_AudioInputs.Text = "Audio inputs"
        Me.ToolStripButton_AudioInputs.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_Export
        '
        Me.ToolStripButton_Export.Image = CType(resources.GetObject("ToolStripButton_Export.Image"), System.Drawing.Image)
        Me.ToolStripButton_Export.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_Export.Name = "ToolStripButton_Export"
        Me.ToolStripButton_Export.Size = New System.Drawing.Size(60, 22)
        Me.ToolStripButton_Export.Text = "Export"
        Me.ToolStripButton_Export.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_ViewPulses
        '
        Me.ToolStripButton_ViewPulses.Image = CType(resources.GetObject("ToolStripButton_ViewPulses.Image"), System.Drawing.Image)
        Me.ToolStripButton_ViewPulses.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_ViewPulses.Name = "ToolStripButton_ViewPulses"
        Me.ToolStripButton_ViewPulses.Size = New System.Drawing.Size(88, 22)
        Me.ToolStripButton_ViewPulses.Text = "View pulses"
        Me.ToolStripButton_ViewPulses.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_ViewEqualizers
        '
        Me.ToolStripButton_ViewEqualizers.Image = CType(resources.GetObject("ToolStripButton_ViewEqualizers.Image"), System.Drawing.Image)
        Me.ToolStripButton_ViewEqualizers.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_ViewEqualizers.Name = "ToolStripButton_ViewEqualizers"
        Me.ToolStripButton_ViewEqualizers.Size = New System.Drawing.Size(79, 22)
        Me.ToolStripButton_ViewEqualizers.Text = "Equalizers"
        Me.ToolStripButton_ViewEqualizers.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_Run
        '
        Me.ToolStripButton_Run.Checked = True
        Me.ToolStripButton_Run.CheckOnClick = True
        Me.ToolStripButton_Run.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ToolStripButton_Run.Image = CType(resources.GetObject("ToolStripButton_Run.Image"), System.Drawing.Image)
        Me.ToolStripButton_Run.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_Run.Name = "ToolStripButton_Run"
        Me.ToolStripButton_Run.Size = New System.Drawing.Size(48, 22)
        Me.ToolStripButton_Run.Text = "Run"
        Me.ToolStripButton_Run.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_StartMeasure
        '
        Me.ToolStripButton_StartMeasure.Image = CType(resources.GetObject("ToolStripButton_StartMeasure.Image"), System.Drawing.Image)
        Me.ToolStripButton_StartMeasure.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_StartMeasure.Name = "ToolStripButton_StartMeasure"
        Me.ToolStripButton_StartMeasure.Size = New System.Drawing.Size(124, 22)
        Me.ToolStripButton_StartMeasure.Text = "Start new measure"
        Me.ToolStripButton_StartMeasure.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton_Identifier
        '
        Me.ToolStripButton_Identifier.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripButton_Identifier.Image = CType(resources.GetObject("ToolStripButton_Identifier.Image"), System.Drawing.Image)
        Me.ToolStripButton_Identifier.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_Identifier.Name = "ToolStripButton_Identifier"
        Me.ToolStripButton_Identifier.Size = New System.Drawing.Size(107, 22)
        Me.ToolStripButton_Identifier.Text = "Tomy identifier"
        Me.ToolStripButton_Identifier.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'GroupBox_Info
        '
        Me.GroupBox_Info.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_Info.Controls.Add(Me.lbl_TotalSeconds)
        Me.GroupBox_Info.Controls.Add(Me.lbl_PulsesPerSec)
        Me.GroupBox_Info.Controls.Add(Me.lbl_TotalPulses)
        Me.GroupBox_Info.Controls.Add(Me.Label_TotalSeconds)
        Me.GroupBox_Info.Controls.Add(Me.Label_PulsesPerSec)
        Me.GroupBox_Info.Controls.Add(Me.Label_TotalPulses)
        Me.GroupBox_Info.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Info.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_Info.Location = New System.Drawing.Point(2, 6)
        Me.GroupBox_Info.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Info.Name = "GroupBox_Info"
        Me.GroupBox_Info.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Info.Size = New System.Drawing.Size(152, 77)
        Me.GroupBox_Info.TabIndex = 161
        Me.GroupBox_Info.TabStop = False
        Me.GroupBox_Info.Text = "Info"
        '
        'lbl_TotalSeconds
        '
        Me.lbl_TotalSeconds.BackColor = System.Drawing.Color.MintCream
        Me.lbl_TotalSeconds.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_TotalSeconds.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TotalSeconds.ForeColor = System.Drawing.Color.Black
        Me.lbl_TotalSeconds.Location = New System.Drawing.Point(89, 17)
        Me.lbl_TotalSeconds.Name = "lbl_TotalSeconds"
        Me.lbl_TotalSeconds.Size = New System.Drawing.Size(54, 17)
        Me.lbl_TotalSeconds.TabIndex = 10
        Me.lbl_TotalSeconds.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbl_PulsesPerSec
        '
        Me.lbl_PulsesPerSec.BackColor = System.Drawing.Color.MintCream
        Me.lbl_PulsesPerSec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_PulsesPerSec.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_PulsesPerSec.ForeColor = System.Drawing.Color.Black
        Me.lbl_PulsesPerSec.Location = New System.Drawing.Point(89, 56)
        Me.lbl_PulsesPerSec.Name = "lbl_PulsesPerSec"
        Me.lbl_PulsesPerSec.Size = New System.Drawing.Size(54, 17)
        Me.lbl_PulsesPerSec.TabIndex = 12
        Me.lbl_PulsesPerSec.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbl_TotalPulses
        '
        Me.lbl_TotalPulses.BackColor = System.Drawing.Color.MintCream
        Me.lbl_TotalPulses.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl_TotalPulses.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TotalPulses.ForeColor = System.Drawing.Color.Black
        Me.lbl_TotalPulses.Location = New System.Drawing.Point(81, 35)
        Me.lbl_TotalPulses.Name = "lbl_TotalPulses"
        Me.lbl_TotalPulses.Size = New System.Drawing.Size(62, 17)
        Me.lbl_TotalPulses.TabIndex = 11
        Me.lbl_TotalPulses.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_TotalSeconds
        '
        Me.Label_TotalSeconds.AutoSize = True
        Me.Label_TotalSeconds.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_TotalSeconds.ForeColor = System.Drawing.Color.Black
        Me.Label_TotalSeconds.Location = New System.Drawing.Point(7, 19)
        Me.Label_TotalSeconds.Name = "Label_TotalSeconds"
        Me.Label_TotalSeconds.Size = New System.Drawing.Size(73, 13)
        Me.Label_TotalSeconds.TabIndex = 138
        Me.Label_TotalSeconds.Text = "Total seconds"
        '
        'Label_PulsesPerSec
        '
        Me.Label_PulsesPerSec.AutoSize = True
        Me.Label_PulsesPerSec.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_PulsesPerSec.ForeColor = System.Drawing.Color.Black
        Me.Label_PulsesPerSec.Location = New System.Drawing.Point(7, 57)
        Me.Label_PulsesPerSec.Name = "Label_PulsesPerSec"
        Me.Label_PulsesPerSec.Size = New System.Drawing.Size(79, 13)
        Me.Label_PulsesPerSec.TabIndex = 136
        Me.Label_PulsesPerSec.Text = "Pulses per sec."
        '
        'Label_TotalPulses
        '
        Me.Label_TotalPulses.AutoSize = True
        Me.Label_TotalPulses.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_TotalPulses.ForeColor = System.Drawing.Color.Black
        Me.Label_TotalPulses.Location = New System.Drawing.Point(7, 38)
        Me.Label_TotalPulses.Name = "Label_TotalPulses"
        Me.Label_TotalPulses.Size = New System.Drawing.Size(64, 13)
        Me.Label_TotalPulses.TabIndex = 134
        Me.Label_TotalPulses.Text = "Total pulses"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage_Operation)
        Me.TabControl1.Controls.Add(Me.TabPage_Options)
        Me.TabControl1.Controls.Add(Me.TabPage_Isotopes)
        Me.TabControl1.Location = New System.Drawing.Point(3, 56)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(165, 520)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage_Operation
        '
        Me.TabPage_Operation.Controls.Add(Me.GroupBox_BaseLineTest)
        Me.TabPage_Operation.Controls.Add(Me.GroupBox_Info)
        Me.TabPage_Operation.Controls.Add(Me.GroupBox_Params)
        Me.TabPage_Operation.Controls.Add(Me.GroupBox_AudioInput)
        Me.TabPage_Operation.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Operation.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabPage_Operation.Name = "TabPage_Operation"
        Me.TabPage_Operation.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabPage_Operation.Size = New System.Drawing.Size(157, 494)
        Me.TabPage_Operation.TabIndex = 0
        Me.TabPage_Operation.Text = "Operation"
        Me.TabPage_Operation.UseVisualStyleBackColor = True
        '
        'GroupBox_BaseLineTest
        '
        Me.GroupBox_BaseLineTest.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GroupBox_BaseLineTest.Controls.Add(Me.Label_BLT_MaxNoise)
        Me.GroupBox_BaseLineTest.Controls.Add(Me.btn_BLT_MaxSlope)
        Me.GroupBox_BaseLineTest.Controls.Add(Me.txt_BLT_MaxNoise)
        Me.GroupBox_BaseLineTest.Controls.Add(Me.chk_BltEnable)
        Me.GroupBox_BaseLineTest.Controls.Add(Me.txt_BLT_Size)
        Me.GroupBox_BaseLineTest.Controls.Add(Me.Label_BLT_Size)
        Me.GroupBox_BaseLineTest.Controls.Add(Me.txt_BLT_Position)
        Me.GroupBox_BaseLineTest.Controls.Add(Me.Label_BLT_Position)
        Me.GroupBox_BaseLineTest.Controls.Add(Me.txt_BLT_MaxSlope)
        Me.GroupBox_BaseLineTest.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_BaseLineTest.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_BaseLineTest.Location = New System.Drawing.Point(2, 217)
        Me.GroupBox_BaseLineTest.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_BaseLineTest.Name = "GroupBox_BaseLineTest"
        Me.GroupBox_BaseLineTest.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_BaseLineTest.Size = New System.Drawing.Size(152, 89)
        Me.GroupBox_BaseLineTest.TabIndex = 154
        Me.GroupBox_BaseLineTest.TabStop = False
        Me.GroupBox_BaseLineTest.Text = "Baseline test"
        '
        'Label_BLT_MaxNoise
        '
        Me.Label_BLT_MaxNoise.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_BLT_MaxNoise.ForeColor = System.Drawing.Color.Black
        Me.Label_BLT_MaxNoise.Location = New System.Drawing.Point(4, 69)
        Me.Label_BLT_MaxNoise.Name = "Label_BLT_MaxNoise"
        Me.Label_BLT_MaxNoise.Size = New System.Drawing.Size(96, 13)
        Me.Label_BLT_MaxNoise.TabIndex = 176
        Me.Label_BLT_MaxNoise.Text = "Max Noise (%)"
        Me.Label_BLT_MaxNoise.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btn_BLT_MaxSlope
        '
        Me.btn_BLT_MaxSlope.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker27.IsActive = False
        DesignerRectTracker27.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker27.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BLT_MaxSlope.CenterPtTracker = DesignerRectTracker27
        Me.btn_BLT_MaxSlope.CheckButton = True
        Me.btn_BLT_MaxSlope.Checked = True
        CBlendItems27.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems27.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_BLT_MaxSlope.ColorFillBlend = CBlendItems27
        CBlendItems28.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems28.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_BLT_MaxSlope.ColorFillBlendChecked = CBlendItems28
        Me.btn_BLT_MaxSlope.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_BLT_MaxSlope.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_BLT_MaxSlope.Corners.All = CType(6, Short)
        Me.btn_BLT_MaxSlope.Corners.LowerLeft = CType(6, Short)
        Me.btn_BLT_MaxSlope.Corners.LowerRight = CType(6, Short)
        Me.btn_BLT_MaxSlope.Corners.UpperLeft = CType(6, Short)
        Me.btn_BLT_MaxSlope.Corners.UpperRight = CType(6, Short)
        Me.btn_BLT_MaxSlope.DimFactorGray = -10
        Me.btn_BLT_MaxSlope.DimFactorOver = 30
        Me.btn_BLT_MaxSlope.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_BLT_MaxSlope.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_BLT_MaxSlope.FocalPoints.CenterPtX = 0.0!
        Me.btn_BLT_MaxSlope.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_BLT_MaxSlope.FocalPoints.FocusPtX = 0.0!
        Me.btn_BLT_MaxSlope.FocalPoints.FocusPtY = 0.0!
        Me.btn_BLT_MaxSlope.FocalPointsChecked.CenterPtX = 0.4946237!
        Me.btn_BLT_MaxSlope.FocalPointsChecked.CenterPtY = 0.2352941!
        Me.btn_BLT_MaxSlope.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_BLT_MaxSlope.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker28.IsActive = False
        DesignerRectTracker28.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker28.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_BLT_MaxSlope.FocusPtTracker = DesignerRectTracker28
        Me.btn_BLT_MaxSlope.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_BLT_MaxSlope.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_BLT_MaxSlope.Image = Nothing
        Me.btn_BLT_MaxSlope.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_BLT_MaxSlope.ImageIndex = 0
        Me.btn_BLT_MaxSlope.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_BLT_MaxSlope.Location = New System.Drawing.Point(4, 51)
        Me.btn_BLT_MaxSlope.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_BLT_MaxSlope.Name = "btn_BLT_MaxSlope"
        Me.btn_BLT_MaxSlope.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_BLT_MaxSlope.SideImage = Nothing
        Me.btn_BLT_MaxSlope.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_BLT_MaxSlope.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_BLT_MaxSlope.Size = New System.Drawing.Size(93, 17)
        Me.btn_BLT_MaxSlope.TabIndex = 175
        Me.btn_BLT_MaxSlope.Text = "Max Slope (%)"
        Me.btn_BLT_MaxSlope.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_BLT_MaxSlope.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_BLT_MaxSlope.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_BLT_MaxSlope.TextShadow = System.Drawing.Color.Transparent
        Me.btn_BLT_MaxSlope.TextShadowChecked = System.Drawing.Color.Empty
        '
        'txt_BLT_MaxNoise
        '
        Me.txt_BLT_MaxNoise.ArrowsIncrement = 1
        Me.txt_BLT_MaxNoise.BackColor = System.Drawing.Color.MintCream
        Me.txt_BLT_MaxNoise.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_BLT_MaxNoise.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_BLT_MaxNoise.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BLT_MaxNoise.ForeColor = System.Drawing.Color.Black
        Me.txt_BLT_MaxNoise.Increment = 0.2
        Me.txt_BLT_MaxNoise.Location = New System.Drawing.Point(104, 69)
        Me.txt_BLT_MaxNoise.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_BLT_MaxNoise.MaxValue = 100
        Me.txt_BLT_MaxNoise.MinValue = 1
        Me.txt_BLT_MaxNoise.Name = "txt_BLT_MaxNoise"
        Me.txt_BLT_MaxNoise.NumericValue = 20
        Me.txt_BLT_MaxNoise.NumericValueInteger = 20
        Me.txt_BLT_MaxNoise.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_BLT_MaxNoise.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_BLT_MaxNoise.RoundingStep = 0
        Me.txt_BLT_MaxNoise.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_BLT_MaxNoise.Size = New System.Drawing.Size(37, 15)
        Me.txt_BLT_MaxNoise.TabIndex = 167
        Me.txt_BLT_MaxNoise.Text = "20"
        Me.txt_BLT_MaxNoise.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_BltEnable
        '
        Me.chk_BltEnable.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_BltEnable.Checked = True
        Me.chk_BltEnable.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_BltEnable.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_BltEnable.ForeColor = System.Drawing.Color.Black
        Me.chk_BltEnable.Location = New System.Drawing.Point(127, 2)
        Me.chk_BltEnable.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chk_BltEnable.Name = "chk_BltEnable"
        Me.chk_BltEnable.Size = New System.Drawing.Size(14, 17)
        Me.chk_BltEnable.TabIndex = 20
        Me.chk_BltEnable.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_BltEnable.UseVisualStyleBackColor = True
        '
        'txt_BLT_Size
        '
        Me.txt_BLT_Size.ArrowsIncrement = 1
        Me.txt_BLT_Size.BackColor = System.Drawing.Color.MintCream
        Me.txt_BLT_Size.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_BLT_Size.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_BLT_Size.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BLT_Size.ForeColor = System.Drawing.Color.Black
        Me.txt_BLT_Size.Increment = 0.2
        Me.txt_BLT_Size.Location = New System.Drawing.Point(105, 35)
        Me.txt_BLT_Size.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_BLT_Size.MaxValue = 999
        Me.txt_BLT_Size.MinValue = 100
        Me.txt_BLT_Size.Name = "txt_BLT_Size"
        Me.txt_BLT_Size.NumericValue = 200
        Me.txt_BLT_Size.NumericValueInteger = 200
        Me.txt_BLT_Size.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_BLT_Size.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_BLT_Size.RoundingStep = 0
        Me.txt_BLT_Size.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_BLT_Size.Size = New System.Drawing.Size(36, 15)
        Me.txt_BLT_Size.TabIndex = 22
        Me.txt_BLT_Size.Text = "200"
        Me.txt_BLT_Size.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_BLT_Size
        '
        Me.Label_BLT_Size.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_BLT_Size.ForeColor = System.Drawing.Color.Black
        Me.Label_BLT_Size.Location = New System.Drawing.Point(4, 35)
        Me.Label_BLT_Size.Name = "Label_BLT_Size"
        Me.Label_BLT_Size.Size = New System.Drawing.Size(96, 13)
        Me.Label_BLT_Size.TabIndex = 132
        Me.Label_BLT_Size.Text = "Size (uS)"
        Me.Label_BLT_Size.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_BLT_Position
        '
        Me.txt_BLT_Position.ArrowsIncrement = 1
        Me.txt_BLT_Position.BackColor = System.Drawing.Color.MintCream
        Me.txt_BLT_Position.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_BLT_Position.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_BLT_Position.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BLT_Position.ForeColor = System.Drawing.Color.Black
        Me.txt_BLT_Position.Increment = 0.2
        Me.txt_BLT_Position.Location = New System.Drawing.Point(105, 19)
        Me.txt_BLT_Position.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_BLT_Position.MaxValue = 200
        Me.txt_BLT_Position.MinValue = 50
        Me.txt_BLT_Position.Name = "txt_BLT_Position"
        Me.txt_BLT_Position.NumericValue = 100
        Me.txt_BLT_Position.NumericValueInteger = 100
        Me.txt_BLT_Position.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_BLT_Position.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_BLT_Position.RoundingStep = 0
        Me.txt_BLT_Position.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_BLT_Position.Size = New System.Drawing.Size(36, 15)
        Me.txt_BLT_Position.TabIndex = 21
        Me.txt_BLT_Position.Text = "100"
        Me.txt_BLT_Position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_BLT_Position
        '
        Me.Label_BLT_Position.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_BLT_Position.ForeColor = System.Drawing.Color.Black
        Me.Label_BLT_Position.Location = New System.Drawing.Point(4, 20)
        Me.Label_BLT_Position.Name = "Label_BLT_Position"
        Me.Label_BLT_Position.Size = New System.Drawing.Size(96, 13)
        Me.Label_BLT_Position.TabIndex = 134
        Me.Label_BLT_Position.Text = "Position (uS)"
        Me.Label_BLT_Position.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_BLT_MaxSlope
        '
        Me.txt_BLT_MaxSlope.ArrowsIncrement = 1
        Me.txt_BLT_MaxSlope.BackColor = System.Drawing.Color.MintCream
        Me.txt_BLT_MaxSlope.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_BLT_MaxSlope.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_BLT_MaxSlope.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BLT_MaxSlope.ForeColor = System.Drawing.Color.Black
        Me.txt_BLT_MaxSlope.Increment = 0.2
        Me.txt_BLT_MaxSlope.Location = New System.Drawing.Point(104, 52)
        Me.txt_BLT_MaxSlope.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_BLT_MaxSlope.MaxValue = 100
        Me.txt_BLT_MaxSlope.MinValue = 1
        Me.txt_BLT_MaxSlope.Name = "txt_BLT_MaxSlope"
        Me.txt_BLT_MaxSlope.NumericValue = 20
        Me.txt_BLT_MaxSlope.NumericValueInteger = 20
        Me.txt_BLT_MaxSlope.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_BLT_MaxSlope.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_BLT_MaxSlope.RoundingStep = 0
        Me.txt_BLT_MaxSlope.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_BLT_MaxSlope.Size = New System.Drawing.Size(37, 15)
        Me.txt_BLT_MaxSlope.TabIndex = 19
        Me.txt_BLT_MaxSlope.Text = "20"
        Me.txt_BLT_MaxSlope.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_AudioInput
        '
        Me.GroupBox_AudioInput.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GroupBox_AudioInput.Controls.Add(Me.cmb_AudioInDevices)
        Me.GroupBox_AudioInput.Controls.Add(Me.btn_InputSelection)
        Me.GroupBox_AudioInput.Controls.Add(Me.Panel1)
        Me.GroupBox_AudioInput.Controls.Add(Me.txt_AudioZero)
        Me.GroupBox_AudioInput.Controls.Add(Me.Label_NumBins)
        Me.GroupBox_AudioInput.Controls.Add(Me.Label_AudioZero)
        Me.GroupBox_AudioInput.Controls.Add(Me.Label_Sampling)
        Me.GroupBox_AudioInput.Controls.Add(Me.txt_AudioGain)
        Me.GroupBox_AudioInput.Controls.Add(Me.Label_PulsePolarity)
        Me.GroupBox_AudioInput.Controls.Add(Me.Pbox3)
        Me.GroupBox_AudioInput.Controls.Add(Me.Label_AudioGain)
        Me.GroupBox_AudioInput.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_AudioInput.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_AudioInput.Location = New System.Drawing.Point(2, 87)
        Me.GroupBox_AudioInput.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_AudioInput.Name = "GroupBox_AudioInput"
        Me.GroupBox_AudioInput.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_AudioInput.Size = New System.Drawing.Size(152, 125)
        Me.GroupBox_AudioInput.TabIndex = 152
        Me.GroupBox_AudioInput.TabStop = False
        Me.GroupBox_AudioInput.Text = "Audio Input"
        '
        'cmb_AudioInDevices
        '
        Me.cmb_AudioInDevices.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_AudioInDevices.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_AudioInDevices.BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_AudioInDevices.BackColor_Focused = System.Drawing.Color.AliceBlue
        Me.cmb_AudioInDevices.BackColor_Over = System.Drawing.Color.LemonChiffon
        Me.cmb_AudioInDevices.BorderColor = System.Drawing.Color.PowderBlue
        Me.cmb_AudioInDevices.BorderSize = 1
        Me.cmb_AudioInDevices.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_AudioInDevices.DropDown_BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_AudioInDevices.DropDown_BackSelected = System.Drawing.Color.Gainsboro
        Me.cmb_AudioInDevices.DropDown_BorderColor = System.Drawing.Color.AliceBlue
        Me.cmb_AudioInDevices.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_AudioInDevices.DropDown_ForeSelected = System.Drawing.Color.Black
        Me.cmb_AudioInDevices.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_AudioInDevices.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.cmb_AudioInDevices.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_AudioInDevices.ForeColor = System.Drawing.Color.Black
        Me.cmb_AudioInDevices.IntegralHeight = False
        Me.cmb_AudioInDevices.ItemHeight = 10
        Me.cmb_AudioInDevices.Location = New System.Drawing.Point(15, 104)
        Me.cmb_AudioInDevices.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmb_AudioInDevices.MaxDropDownItems = 99
        Me.cmb_AudioInDevices.Name = "cmb_AudioInDevices"
        Me.cmb_AudioInDevices.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_AudioInDevices.Size = New System.Drawing.Size(128, 16)
        Me.cmb_AudioInDevices.TabIndex = 173
        Me.cmb_AudioInDevices.TextPosition = 1
        '
        'btn_InputSelection
        '
        Me.btn_InputSelection.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_InputSelection.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker29.IsActive = False
        DesignerRectTracker29.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker29.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_InputSelection.CenterPtTracker = DesignerRectTracker29
        Me.btn_InputSelection.CheckButton = True
        CBlendItems29.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems29.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_InputSelection.ColorFillBlend = CBlendItems29
        CBlendItems30.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems30.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_InputSelection.ColorFillBlendChecked = CBlendItems30
        Me.btn_InputSelection.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_InputSelection.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_InputSelection.Corners.All = CType(6, Short)
        Me.btn_InputSelection.Corners.LowerLeft = CType(6, Short)
        Me.btn_InputSelection.Corners.LowerRight = CType(6, Short)
        Me.btn_InputSelection.Corners.UpperLeft = CType(6, Short)
        Me.btn_InputSelection.Corners.UpperRight = CType(6, Short)
        Me.btn_InputSelection.DimFactorGray = -10
        Me.btn_InputSelection.DimFactorOver = 30
        Me.btn_InputSelection.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_InputSelection.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_InputSelection.FocalPoints.CenterPtX = 0.0!
        Me.btn_InputSelection.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_InputSelection.FocalPoints.FocusPtX = 0.0!
        Me.btn_InputSelection.FocalPoints.FocusPtY = 0.0!
        Me.btn_InputSelection.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_InputSelection.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_InputSelection.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_InputSelection.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker30.IsActive = False
        DesignerRectTracker30.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker30.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_InputSelection.FocusPtTracker = DesignerRectTracker30
        Me.btn_InputSelection.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_InputSelection.ForeColorChecked = System.Drawing.Color.Black
        Me.btn_InputSelection.Image = Nothing
        Me.btn_InputSelection.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_InputSelection.ImageIndex = 0
        Me.btn_InputSelection.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_InputSelection.Location = New System.Drawing.Point(2, 1)
        Me.btn_InputSelection.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_InputSelection.Name = "btn_InputSelection"
        Me.btn_InputSelection.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_InputSelection.SideImage = Nothing
        Me.btn_InputSelection.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_InputSelection.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_InputSelection.Size = New System.Drawing.Size(78, 14)
        Me.btn_InputSelection.TabIndex = 172
        Me.btn_InputSelection.Text = "Audio Input"
        Me.btn_InputSelection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_InputSelection.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_InputSelection.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_InputSelection.TextShadow = System.Drawing.Color.Transparent
        Me.btn_InputSelection.TextShadowChecked = System.Drawing.Color.Transparent
        Me.btn_InputSelection.Visible = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cmb_Bins)
        Me.Panel1.Controls.Add(Me.cmb_Sampling)
        Me.Panel1.Controls.Add(Me.cmb_PulsePolarity)
        Me.Panel1.Location = New System.Drawing.Point(91, 10)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(52, 58)
        Me.Panel1.TabIndex = 165
        '
        'cmb_Bins
        '
        Me.cmb_Bins.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Bins.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Bins.BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_Bins.BackColor_Focused = System.Drawing.Color.AliceBlue
        Me.cmb_Bins.BackColor_Over = System.Drawing.Color.LemonChiffon
        Me.cmb_Bins.BorderColor = System.Drawing.Color.PowderBlue
        Me.cmb_Bins.BorderSize = 1
        Me.cmb_Bins.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Bins.DropDown_BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_Bins.DropDown_BackSelected = System.Drawing.Color.Gainsboro
        Me.cmb_Bins.DropDown_BorderColor = System.Drawing.Color.AliceBlue
        Me.cmb_Bins.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Bins.DropDown_ForeSelected = System.Drawing.Color.Black
        Me.cmb_Bins.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Bins.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.cmb_Bins.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Bins.ForeColor = System.Drawing.Color.Black
        Me.cmb_Bins.IntegralHeight = False
        Me.cmb_Bins.ItemHeight = 10
        Me.cmb_Bins.Items.AddRange(New Object() {"x0.1", "x0.2", "x0.5", "x1", "x2", "x5", "x10", "x20", "x50"})
        Me.cmb_Bins.Location = New System.Drawing.Point(5, 4)
        Me.cmb_Bins.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmb_Bins.MaxDropDownItems = 99
        Me.cmb_Bins.Name = "cmb_Bins"
        Me.cmb_Bins.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Bins.Size = New System.Drawing.Size(60, 16)
        Me.cmb_Bins.TabIndex = 13
        Me.cmb_Bins.TextPosition = 1
        '
        'cmb_Sampling
        '
        Me.cmb_Sampling.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_Sampling.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_Sampling.BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_Sampling.BackColor_Focused = System.Drawing.Color.AliceBlue
        Me.cmb_Sampling.BackColor_Over = System.Drawing.Color.LemonChiffon
        Me.cmb_Sampling.BorderColor = System.Drawing.Color.PowderBlue
        Me.cmb_Sampling.BorderSize = 1
        Me.cmb_Sampling.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_Sampling.DropDown_BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_Sampling.DropDown_BackSelected = System.Drawing.Color.Gainsboro
        Me.cmb_Sampling.DropDown_BorderColor = System.Drawing.Color.AliceBlue
        Me.cmb_Sampling.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_Sampling.DropDown_ForeSelected = System.Drawing.Color.Black
        Me.cmb_Sampling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Sampling.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.cmb_Sampling.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Sampling.ForeColor = System.Drawing.Color.Black
        Me.cmb_Sampling.IntegralHeight = False
        Me.cmb_Sampling.ItemHeight = 10
        Me.cmb_Sampling.Items.AddRange(New Object() {"44100", "48000", "96000", "144000", "176400", "192000", "384000", "768000"})
        Me.cmb_Sampling.Location = New System.Drawing.Point(5, 21)
        Me.cmb_Sampling.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmb_Sampling.MaxDropDownItems = 99
        Me.cmb_Sampling.Name = "cmb_Sampling"
        Me.cmb_Sampling.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_Sampling.Size = New System.Drawing.Size(60, 16)
        Me.cmb_Sampling.TabIndex = 14
        Me.cmb_Sampling.TextPosition = 1
        '
        'cmb_PulsePolarity
        '
        Me.cmb_PulsePolarity.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_PulsePolarity.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_PulsePolarity.BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_PulsePolarity.BackColor_Focused = System.Drawing.Color.AliceBlue
        Me.cmb_PulsePolarity.BackColor_Over = System.Drawing.Color.LemonChiffon
        Me.cmb_PulsePolarity.BorderColor = System.Drawing.Color.PowderBlue
        Me.cmb_PulsePolarity.BorderSize = 1
        Me.cmb_PulsePolarity.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_PulsePolarity.DropDown_BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_PulsePolarity.DropDown_BackSelected = System.Drawing.Color.Gainsboro
        Me.cmb_PulsePolarity.DropDown_BorderColor = System.Drawing.Color.AliceBlue
        Me.cmb_PulsePolarity.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_PulsePolarity.DropDown_ForeSelected = System.Drawing.Color.Black
        Me.cmb_PulsePolarity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_PulsePolarity.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.cmb_PulsePolarity.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_PulsePolarity.ForeColor = System.Drawing.Color.Black
        Me.cmb_PulsePolarity.IntegralHeight = False
        Me.cmb_PulsePolarity.ItemHeight = 10
        Me.cmb_PulsePolarity.Items.AddRange(New Object() {"Pos.", "Neg.", "Auto"})
        Me.cmb_PulsePolarity.Location = New System.Drawing.Point(5, 39)
        Me.cmb_PulsePolarity.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmb_PulsePolarity.MaxDropDownItems = 99
        Me.cmb_PulsePolarity.Name = "cmb_PulsePolarity"
        Me.cmb_PulsePolarity.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_PulsePolarity.Size = New System.Drawing.Size(60, 16)
        Me.cmb_PulsePolarity.TabIndex = 15
        Me.cmb_PulsePolarity.TextPosition = 1
        '
        'txt_AudioZero
        '
        Me.txt_AudioZero.ArrowsIncrement = 1
        Me.txt_AudioZero.BackColor = System.Drawing.Color.MintCream
        Me.txt_AudioZero.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AudioZero.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AudioZero.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AudioZero.ForeColor = System.Drawing.Color.Black
        Me.txt_AudioZero.Increment = 0.5
        Me.txt_AudioZero.Location = New System.Drawing.Point(105, 87)
        Me.txt_AudioZero.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_AudioZero.MaxValue = 2000
        Me.txt_AudioZero.MinValue = -2000
        Me.txt_AudioZero.Name = "txt_AudioZero"
        Me.txt_AudioZero.NumericValue = 0
        Me.txt_AudioZero.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AudioZero.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AudioZero.RoundingStep = 0
        Me.txt_AudioZero.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AudioZero.Size = New System.Drawing.Size(37, 15)
        Me.txt_AudioZero.TabIndex = 18
        Me.txt_AudioZero.Text = "0"
        Me.txt_AudioZero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_AudioZero
        '
        Me.Label_AudioZero.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_AudioZero.ForeColor = System.Drawing.Color.Black
        Me.Label_AudioZero.Location = New System.Drawing.Point(38, 88)
        Me.Label_AudioZero.Name = "Label_AudioZero"
        Me.Label_AudioZero.Size = New System.Drawing.Size(63, 13)
        Me.Label_AudioZero.TabIndex = 147
        Me.Label_AudioZero.Text = "Zero trim"
        Me.Label_AudioZero.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_AudioGain
        '
        Me.txt_AudioGain.ArrowsIncrement = 0.1
        Me.txt_AudioGain.BackColor = System.Drawing.Color.MintCream
        Me.txt_AudioGain.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_AudioGain.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_AudioGain.Decimals = 1
        Me.txt_AudioGain.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_AudioGain.ForeColor = System.Drawing.Color.Black
        Me.txt_AudioGain.Increment = 0.02
        Me.txt_AudioGain.Location = New System.Drawing.Point(105, 69)
        Me.txt_AudioGain.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_AudioGain.MaxValue = 20
        Me.txt_AudioGain.MinValue = 1
        Me.txt_AudioGain.Name = "txt_AudioGain"
        Me.txt_AudioGain.NumericValue = 2
        Me.txt_AudioGain.NumericValueInteger = 2
        Me.txt_AudioGain.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_AudioGain.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_AudioGain.RoundingStep = 0
        Me.txt_AudioGain.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_AudioGain.Size = New System.Drawing.Size(37, 15)
        Me.txt_AudioGain.TabIndex = 17
        Me.txt_AudioGain.Text = "2"
        Me.txt_AudioGain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_AudioGain
        '
        Me.Label_AudioGain.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_AudioGain.ForeColor = System.Drawing.Color.Black
        Me.Label_AudioGain.Location = New System.Drawing.Point(35, 71)
        Me.Label_AudioGain.Name = "Label_AudioGain"
        Me.Label_AudioGain.Size = New System.Drawing.Size(66, 13)
        Me.Label_AudioGain.TabIndex = 145
        Me.Label_AudioGain.Text = "Audio gain"
        Me.Label_AudioGain.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TabPage_Options
        '
        Me.TabPage_Options.Controls.Add(Me.GroupBox_GaussianDec)
        Me.TabPage_Options.Controls.Add(Me.GroupBox_ResComp)
        Me.TabPage_Options.Controls.Add(Me.GroupBox_ScaleOptions)
        Me.TabPage_Options.Controls.Add(Me.GroupBox_Timers)
        Me.TabPage_Options.Controls.Add(Me.GroupBox_ExportOptions)
        Me.TabPage_Options.Controls.Add(Me.GroupBox_OutputSlots)
        Me.TabPage_Options.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Options.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabPage_Options.Name = "TabPage_Options"
        Me.TabPage_Options.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabPage_Options.Size = New System.Drawing.Size(157, 494)
        Me.TabPage_Options.TabIndex = 1
        Me.TabPage_Options.Text = "Options"
        Me.TabPage_Options.UseVisualStyleBackColor = True
        '
        'GroupBox_GaussianDec
        '
        Me.GroupBox_GaussianDec.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GroupBox_GaussianDec.Controls.Add(Me.chk_GaussianDecEnable)
        Me.GroupBox_GaussianDec.Controls.Add(Me.txt_DeconvSize)
        Me.GroupBox_GaussianDec.Controls.Add(Me.Label_DeconvSize)
        Me.GroupBox_GaussianDec.Controls.Add(Me.Label_GaussianSize)
        Me.GroupBox_GaussianDec.Controls.Add(Me.txt_GaussianSize)
        Me.GroupBox_GaussianDec.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_GaussianDec.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_GaussianDec.Location = New System.Drawing.Point(2, 414)
        Me.GroupBox_GaussianDec.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_GaussianDec.Name = "GroupBox_GaussianDec"
        Me.GroupBox_GaussianDec.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_GaussianDec.Size = New System.Drawing.Size(152, 59)
        Me.GroupBox_GaussianDec.TabIndex = 1001
        Me.GroupBox_GaussianDec.TabStop = False
        Me.GroupBox_GaussianDec.Text = "Gaussian deconvolution"
        '
        'chk_GaussianDecEnable
        '
        Me.chk_GaussianDecEnable.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_GaussianDecEnable.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_GaussianDecEnable.ForeColor = System.Drawing.Color.Black
        Me.chk_GaussianDecEnable.Location = New System.Drawing.Point(132, 2)
        Me.chk_GaussianDecEnable.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chk_GaussianDecEnable.Name = "chk_GaussianDecEnable"
        Me.chk_GaussianDecEnable.Size = New System.Drawing.Size(14, 17)
        Me.chk_GaussianDecEnable.TabIndex = 20
        Me.chk_GaussianDecEnable.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_GaussianDecEnable.UseVisualStyleBackColor = True
        '
        'txt_DeconvSize
        '
        Me.txt_DeconvSize.ArrowsIncrement = 1
        Me.txt_DeconvSize.BackColor = System.Drawing.Color.MintCream
        Me.txt_DeconvSize.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DeconvSize.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DeconvSize.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DeconvSize.ForeColor = System.Drawing.Color.Black
        Me.txt_DeconvSize.Increment = 0.2
        Me.txt_DeconvSize.Location = New System.Drawing.Point(105, 22)
        Me.txt_DeconvSize.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_DeconvSize.MaxValue = 100
        Me.txt_DeconvSize.MinValue = 1
        Me.txt_DeconvSize.Name = "txt_DeconvSize"
        Me.txt_DeconvSize.NumericValue = 10
        Me.txt_DeconvSize.NumericValueInteger = 10
        Me.txt_DeconvSize.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DeconvSize.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DeconvSize.RoundingStep = 0
        Me.txt_DeconvSize.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DeconvSize.Size = New System.Drawing.Size(36, 15)
        Me.txt_DeconvSize.TabIndex = 22
        Me.txt_DeconvSize.Text = "10"
        Me.txt_DeconvSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_DeconvSize
        '
        Me.Label_DeconvSize.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_DeconvSize.ForeColor = System.Drawing.Color.Black
        Me.Label_DeconvSize.Location = New System.Drawing.Point(4, 22)
        Me.Label_DeconvSize.Name = "Label_DeconvSize"
        Me.Label_DeconvSize.Size = New System.Drawing.Size(96, 13)
        Me.Label_DeconvSize.TabIndex = 132
        Me.Label_DeconvSize.Text = "Deconv. size"
        Me.Label_DeconvSize.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_GaussianSize
        '
        Me.Label_GaussianSize.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_GaussianSize.ForeColor = System.Drawing.Color.Black
        Me.Label_GaussianSize.Location = New System.Drawing.Point(4, 38)
        Me.Label_GaussianSize.Name = "Label_GaussianSize"
        Me.Label_GaussianSize.Size = New System.Drawing.Size(96, 14)
        Me.Label_GaussianSize.TabIndex = 166
        Me.Label_GaussianSize.Text = "Gaussian size"
        Me.Label_GaussianSize.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_GaussianSize
        '
        Me.txt_GaussianSize.ArrowsIncrement = 1
        Me.txt_GaussianSize.BackColor = System.Drawing.Color.MintCream
        Me.txt_GaussianSize.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_GaussianSize.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_GaussianSize.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_GaussianSize.ForeColor = System.Drawing.Color.Black
        Me.txt_GaussianSize.Increment = 0.2
        Me.txt_GaussianSize.Location = New System.Drawing.Point(104, 38)
        Me.txt_GaussianSize.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_GaussianSize.MaxValue = 100
        Me.txt_GaussianSize.MinValue = 0
        Me.txt_GaussianSize.Name = "txt_GaussianSize"
        Me.txt_GaussianSize.NumericValue = 10
        Me.txt_GaussianSize.NumericValueInteger = 10
        Me.txt_GaussianSize.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_GaussianSize.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_GaussianSize.RoundingStep = 0
        Me.txt_GaussianSize.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_GaussianSize.Size = New System.Drawing.Size(37, 15)
        Me.txt_GaussianSize.TabIndex = 19
        Me.txt_GaussianSize.Text = "10"
        Me.txt_GaussianSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_ResComp
        '
        Me.GroupBox_ResComp.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GroupBox_ResComp.Controls.Add(Me.Label_ResCompSize)
        Me.GroupBox_ResComp.Controls.Add(Me.txt_ResCompSize)
        Me.GroupBox_ResComp.Controls.Add(Me.Label_ResCompRight)
        Me.GroupBox_ResComp.Controls.Add(Me.txt_ResCompRight)
        Me.GroupBox_ResComp.Controls.Add(Me.chk_ResCompEnable)
        Me.GroupBox_ResComp.Controls.Add(Me.txt_ResCompCenter)
        Me.GroupBox_ResComp.Controls.Add(Me.Label_ResCompCenter)
        Me.GroupBox_ResComp.Controls.Add(Me.Label_ResCompLeft)
        Me.GroupBox_ResComp.Controls.Add(Me.txt_ResCompLeft)
        Me.GroupBox_ResComp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_ResComp.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_ResComp.Location = New System.Drawing.Point(2, 318)
        Me.GroupBox_ResComp.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_ResComp.Name = "GroupBox_ResComp"
        Me.GroupBox_ResComp.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_ResComp.Size = New System.Drawing.Size(152, 90)
        Me.GroupBox_ResComp.TabIndex = 1000
        Me.GroupBox_ResComp.TabStop = False
        Me.GroupBox_ResComp.Text = "Resolution compensation"
        '
        'Label_ResCompSize
        '
        Me.Label_ResCompSize.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ResCompSize.ForeColor = System.Drawing.Color.Black
        Me.Label_ResCompSize.Location = New System.Drawing.Point(4, 21)
        Me.Label_ResCompSize.Name = "Label_ResCompSize"
        Me.Label_ResCompSize.Size = New System.Drawing.Size(96, 14)
        Me.Label_ResCompSize.TabIndex = 176
        Me.Label_ResCompSize.Text = "Size (bins)"
        Me.Label_ResCompSize.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_ResCompSize
        '
        Me.txt_ResCompSize.ArrowsIncrement = 1
        Me.txt_ResCompSize.BackColor = System.Drawing.Color.MintCream
        Me.txt_ResCompSize.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ResCompSize.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ResCompSize.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ResCompSize.ForeColor = System.Drawing.Color.Black
        Me.txt_ResCompSize.Increment = 0.2
        Me.txt_ResCompSize.Location = New System.Drawing.Point(104, 21)
        Me.txt_ResCompSize.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_ResCompSize.MaxValue = 100
        Me.txt_ResCompSize.MinValue = 0
        Me.txt_ResCompSize.Name = "txt_ResCompSize"
        Me.txt_ResCompSize.NumericValue = 5
        Me.txt_ResCompSize.NumericValueInteger = 5
        Me.txt_ResCompSize.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ResCompSize.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ResCompSize.RoundingStep = 0
        Me.txt_ResCompSize.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ResCompSize.Size = New System.Drawing.Size(37, 15)
        Me.txt_ResCompSize.TabIndex = 175
        Me.txt_ResCompSize.Text = "5"
        Me.txt_ResCompSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_ResCompRight
        '
        Me.Label_ResCompRight.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ResCompRight.ForeColor = System.Drawing.Color.Black
        Me.Label_ResCompRight.Location = New System.Drawing.Point(4, 69)
        Me.Label_ResCompRight.Name = "Label_ResCompRight"
        Me.Label_ResCompRight.Size = New System.Drawing.Size(96, 14)
        Me.Label_ResCompRight.TabIndex = 168
        Me.Label_ResCompRight.Text = "Right (%)"
        Me.Label_ResCompRight.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_ResCompRight
        '
        Me.txt_ResCompRight.ArrowsIncrement = 1
        Me.txt_ResCompRight.BackColor = System.Drawing.Color.MintCream
        Me.txt_ResCompRight.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ResCompRight.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ResCompRight.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ResCompRight.ForeColor = System.Drawing.Color.Black
        Me.txt_ResCompRight.Increment = 0.2
        Me.txt_ResCompRight.Location = New System.Drawing.Point(104, 69)
        Me.txt_ResCompRight.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_ResCompRight.MaxValue = 100
        Me.txt_ResCompRight.MinValue = 0
        Me.txt_ResCompRight.Name = "txt_ResCompRight"
        Me.txt_ResCompRight.NumericValue = 10
        Me.txt_ResCompRight.NumericValueInteger = 10
        Me.txt_ResCompRight.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ResCompRight.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ResCompRight.RoundingStep = 0
        Me.txt_ResCompRight.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ResCompRight.Size = New System.Drawing.Size(37, 15)
        Me.txt_ResCompRight.TabIndex = 167
        Me.txt_ResCompRight.Text = "10"
        Me.txt_ResCompRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chk_ResCompEnable
        '
        Me.chk_ResCompEnable.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_ResCompEnable.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_ResCompEnable.ForeColor = System.Drawing.Color.Black
        Me.chk_ResCompEnable.Location = New System.Drawing.Point(132, 2)
        Me.chk_ResCompEnable.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chk_ResCompEnable.Name = "chk_ResCompEnable"
        Me.chk_ResCompEnable.Size = New System.Drawing.Size(14, 17)
        Me.chk_ResCompEnable.TabIndex = 20
        Me.chk_ResCompEnable.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_ResCompEnable.UseVisualStyleBackColor = True
        '
        'txt_ResCompCenter
        '
        Me.txt_ResCompCenter.ArrowsIncrement = 1
        Me.txt_ResCompCenter.BackColor = System.Drawing.Color.MintCream
        Me.txt_ResCompCenter.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ResCompCenter.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ResCompCenter.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ResCompCenter.ForeColor = System.Drawing.Color.Black
        Me.txt_ResCompCenter.Increment = 0.2
        Me.txt_ResCompCenter.Location = New System.Drawing.Point(105, 37)
        Me.txt_ResCompCenter.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_ResCompCenter.MaxValue = 100
        Me.txt_ResCompCenter.MinValue = 0
        Me.txt_ResCompCenter.Name = "txt_ResCompCenter"
        Me.txt_ResCompCenter.NumericValue = 50
        Me.txt_ResCompCenter.NumericValueInteger = 50
        Me.txt_ResCompCenter.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ResCompCenter.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ResCompCenter.RoundingStep = 0
        Me.txt_ResCompCenter.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ResCompCenter.Size = New System.Drawing.Size(36, 15)
        Me.txt_ResCompCenter.TabIndex = 22
        Me.txt_ResCompCenter.Text = "50"
        Me.txt_ResCompCenter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_ResCompCenter
        '
        Me.Label_ResCompCenter.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ResCompCenter.ForeColor = System.Drawing.Color.Black
        Me.Label_ResCompCenter.Location = New System.Drawing.Point(4, 37)
        Me.Label_ResCompCenter.Name = "Label_ResCompCenter"
        Me.Label_ResCompCenter.Size = New System.Drawing.Size(96, 13)
        Me.Label_ResCompCenter.TabIndex = 132
        Me.Label_ResCompCenter.Text = "Center (%)"
        Me.Label_ResCompCenter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_ResCompLeft
        '
        Me.Label_ResCompLeft.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ResCompLeft.ForeColor = System.Drawing.Color.Black
        Me.Label_ResCompLeft.Location = New System.Drawing.Point(4, 53)
        Me.Label_ResCompLeft.Name = "Label_ResCompLeft"
        Me.Label_ResCompLeft.Size = New System.Drawing.Size(96, 14)
        Me.Label_ResCompLeft.TabIndex = 166
        Me.Label_ResCompLeft.Text = "Left (%)"
        Me.Label_ResCompLeft.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_ResCompLeft
        '
        Me.txt_ResCompLeft.ArrowsIncrement = 1
        Me.txt_ResCompLeft.BackColor = System.Drawing.Color.MintCream
        Me.txt_ResCompLeft.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_ResCompLeft.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_ResCompLeft.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_ResCompLeft.ForeColor = System.Drawing.Color.Black
        Me.txt_ResCompLeft.Increment = 0.2
        Me.txt_ResCompLeft.Location = New System.Drawing.Point(104, 53)
        Me.txt_ResCompLeft.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_ResCompLeft.MaxValue = 100
        Me.txt_ResCompLeft.MinValue = 0
        Me.txt_ResCompLeft.Name = "txt_ResCompLeft"
        Me.txt_ResCompLeft.NumericValue = 10
        Me.txt_ResCompLeft.NumericValueInteger = 10
        Me.txt_ResCompLeft.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_ResCompLeft.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_ResCompLeft.RoundingStep = 0
        Me.txt_ResCompLeft.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_ResCompLeft.Size = New System.Drawing.Size(37, 15)
        Me.txt_ResCompLeft.TabIndex = 19
        Me.txt_ResCompLeft.Text = "10"
        Me.txt_ResCompLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_ScaleOptions
        '
        Me.GroupBox_ScaleOptions.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GroupBox_ScaleOptions.Controls.Add(Me.chk_ThickLines)
        Me.GroupBox_ScaleOptions.Controls.Add(Me.txt_XlogExponent)
        Me.GroupBox_ScaleOptions.Controls.Add(Me.Label_XlogExponent)
        Me.GroupBox_ScaleOptions.Controls.Add(Me.txt_YlogExponent)
        Me.GroupBox_ScaleOptions.Controls.Add(Me.Label_YlogExponent)
        Me.GroupBox_ScaleOptions.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_ScaleOptions.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_ScaleOptions.Location = New System.Drawing.Point(2, 235)
        Me.GroupBox_ScaleOptions.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_ScaleOptions.Name = "GroupBox_ScaleOptions"
        Me.GroupBox_ScaleOptions.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_ScaleOptions.Size = New System.Drawing.Size(152, 77)
        Me.GroupBox_ScaleOptions.TabIndex = 155
        Me.GroupBox_ScaleOptions.TabStop = False
        Me.GroupBox_ScaleOptions.Text = "Scale options"
        '
        'chk_ThickLines
        '
        Me.chk_ThickLines.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_ThickLines.Checked = True
        Me.chk_ThickLines.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_ThickLines.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_ThickLines.ForeColor = System.Drawing.Color.Black
        Me.chk_ThickLines.Location = New System.Drawing.Point(8, 56)
        Me.chk_ThickLines.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chk_ThickLines.Name = "chk_ThickLines"
        Me.chk_ThickLines.Size = New System.Drawing.Size(134, 17)
        Me.chk_ThickLines.TabIndex = 39
        Me.chk_ThickLines.Text = "Use thick lines"
        Me.chk_ThickLines.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_ThickLines.UseVisualStyleBackColor = True
        '
        'txt_XlogExponent
        '
        Me.txt_XlogExponent.ArrowsIncrement = 0.1
        Me.txt_XlogExponent.BackColor = System.Drawing.Color.MintCream
        Me.txt_XlogExponent.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_XlogExponent.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_XlogExponent.Decimals = 1
        Me.txt_XlogExponent.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_XlogExponent.ForeColor = System.Drawing.Color.Black
        Me.txt_XlogExponent.Increment = 0.02
        Me.txt_XlogExponent.Location = New System.Drawing.Point(98, 17)
        Me.txt_XlogExponent.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_XlogExponent.MaxLength = 5
        Me.txt_XlogExponent.MaxValue = 2.5
        Me.txt_XlogExponent.MinValue = 1.4
        Me.txt_XlogExponent.Name = "txt_XlogExponent"
        Me.txt_XlogExponent.NumericValue = 1.5
        Me.txt_XlogExponent.NumericValueInteger = 2
        Me.txt_XlogExponent.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_XlogExponent.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_XlogExponent.RoundingStep = 0
        Me.txt_XlogExponent.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_XlogExponent.Size = New System.Drawing.Size(45, 15)
        Me.txt_XlogExponent.TabIndex = 37
        Me.txt_XlogExponent.Text = "1.5"
        Me.txt_XlogExponent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_XlogExponent
        '
        Me.Label_XlogExponent.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_XlogExponent.ForeColor = System.Drawing.Color.Black
        Me.Label_XlogExponent.Location = New System.Drawing.Point(1, 18)
        Me.Label_XlogExponent.Name = "Label_XlogExponent"
        Me.Label_XlogExponent.Size = New System.Drawing.Size(95, 13)
        Me.Label_XlogExponent.TabIndex = 136
        Me.Label_XlogExponent.Text = "Xlog (1/exp)"
        Me.Label_XlogExponent.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_YlogExponent
        '
        Me.txt_YlogExponent.ArrowsIncrement = 0.1
        Me.txt_YlogExponent.BackColor = System.Drawing.Color.MintCream
        Me.txt_YlogExponent.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_YlogExponent.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_YlogExponent.Decimals = 1
        Me.txt_YlogExponent.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_YlogExponent.ForeColor = System.Drawing.Color.Black
        Me.txt_YlogExponent.Increment = 0.02
        Me.txt_YlogExponent.Location = New System.Drawing.Point(98, 35)
        Me.txt_YlogExponent.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_YlogExponent.MaxLength = 5
        Me.txt_YlogExponent.MaxValue = 10
        Me.txt_YlogExponent.MinValue = 1.1
        Me.txt_YlogExponent.Name = "txt_YlogExponent"
        Me.txt_YlogExponent.NumericValue = 1.5
        Me.txt_YlogExponent.NumericValueInteger = 2
        Me.txt_YlogExponent.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_YlogExponent.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_YlogExponent.RoundingStep = 0
        Me.txt_YlogExponent.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_YlogExponent.Size = New System.Drawing.Size(45, 15)
        Me.txt_YlogExponent.TabIndex = 38
        Me.txt_YlogExponent.Text = "1.5"
        Me.txt_YlogExponent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_YlogExponent
        '
        Me.Label_YlogExponent.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_YlogExponent.ForeColor = System.Drawing.Color.Black
        Me.Label_YlogExponent.Location = New System.Drawing.Point(1, 35)
        Me.Label_YlogExponent.Name = "Label_YlogExponent"
        Me.Label_YlogExponent.Size = New System.Drawing.Size(95, 13)
        Me.Label_YlogExponent.TabIndex = 134
        Me.Label_YlogExponent.Text = "Ylog (1/exp)"
        Me.Label_YlogExponent.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox_Timers
        '
        Me.GroupBox_Timers.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GroupBox_Timers.Controls.Add(Me.txt_StopTimer)
        Me.GroupBox_Timers.Controls.Add(Me.Label_StopTimer)
        Me.GroupBox_Timers.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Timers.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_Timers.Location = New System.Drawing.Point(2, 185)
        Me.GroupBox_Timers.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Timers.Name = "GroupBox_Timers"
        Me.GroupBox_Timers.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_Timers.Size = New System.Drawing.Size(152, 44)
        Me.GroupBox_Timers.TabIndex = 154
        Me.GroupBox_Timers.TabStop = False
        Me.GroupBox_Timers.Text = "Timers"
        '
        'txt_StopTimer
        '
        Me.txt_StopTimer.ArrowsIncrement = 1
        Me.txt_StopTimer.BackColor = System.Drawing.Color.MintCream
        Me.txt_StopTimer.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_StopTimer.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_StopTimer.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_StopTimer.ForeColor = System.Drawing.Color.Black
        Me.txt_StopTimer.Increment = 0.5
        Me.txt_StopTimer.Location = New System.Drawing.Point(98, 21)
        Me.txt_StopTimer.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_StopTimer.MaxLength = 5
        Me.txt_StopTimer.MaxValue = 99999
        Me.txt_StopTimer.MinValue = -1
        Me.txt_StopTimer.Name = "txt_StopTimer"
        Me.txt_StopTimer.NumericValue = -1
        Me.txt_StopTimer.NumericValueInteger = -1
        Me.txt_StopTimer.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_StopTimer.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_StopTimer.RoundingStep = 0
        Me.txt_StopTimer.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_StopTimer.Size = New System.Drawing.Size(45, 15)
        Me.txt_StopTimer.TabIndex = 36
        Me.txt_StopTimer.Text = "-1"
        Me.txt_StopTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_StopTimer
        '
        Me.Label_StopTimer.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_StopTimer.ForeColor = System.Drawing.Color.Black
        Me.Label_StopTimer.Location = New System.Drawing.Point(1, 22)
        Me.Label_StopTimer.Name = "Label_StopTimer"
        Me.Label_StopTimer.Size = New System.Drawing.Size(95, 13)
        Me.Label_StopTimer.TabIndex = 134
        Me.Label_StopTimer.Text = "Stop after (sec)"
        Me.Label_StopTimer.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox_ExportOptions
        '
        Me.GroupBox_ExportOptions.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GroupBox_ExportOptions.Controls.Add(Me.chk_ExportWithHeader)
        Me.GroupBox_ExportOptions.Controls.Add(Me.lbl_FieldSeparator)
        Me.GroupBox_ExportOptions.Controls.Add(Me.txt_FieldSeparator)
        Me.GroupBox_ExportOptions.Controls.Add(Me.lbl_DecimalSeparator)
        Me.GroupBox_ExportOptions.Controls.Add(Me.txt_DecimalSeparator)
        Me.GroupBox_ExportOptions.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_ExportOptions.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_ExportOptions.Location = New System.Drawing.Point(2, 7)
        Me.GroupBox_ExportOptions.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_ExportOptions.Name = "GroupBox_ExportOptions"
        Me.GroupBox_ExportOptions.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_ExportOptions.Size = New System.Drawing.Size(152, 76)
        Me.GroupBox_ExportOptions.TabIndex = 999
        Me.GroupBox_ExportOptions.TabStop = False
        Me.GroupBox_ExportOptions.Text = "Export options"
        '
        'chk_ExportWithHeader
        '
        Me.chk_ExportWithHeader.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_ExportWithHeader.Checked = True
        Me.chk_ExportWithHeader.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_ExportWithHeader.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_ExportWithHeader.ForeColor = System.Drawing.Color.Black
        Me.chk_ExportWithHeader.Location = New System.Drawing.Point(6, 17)
        Me.chk_ExportWithHeader.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chk_ExportWithHeader.Name = "chk_ExportWithHeader"
        Me.chk_ExportWithHeader.Size = New System.Drawing.Size(134, 17)
        Me.chk_ExportWithHeader.TabIndex = 30
        Me.chk_ExportWithHeader.Text = "Export with header"
        Me.chk_ExportWithHeader.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_ExportWithHeader.UseVisualStyleBackColor = True
        '
        'lbl_FieldSeparator
        '
        Me.lbl_FieldSeparator.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_FieldSeparator.ForeColor = System.Drawing.Color.Black
        Me.lbl_FieldSeparator.Location = New System.Drawing.Point(6, 55)
        Me.lbl_FieldSeparator.Name = "lbl_FieldSeparator"
        Me.lbl_FieldSeparator.Size = New System.Drawing.Size(115, 13)
        Me.lbl_FieldSeparator.TabIndex = 143
        Me.lbl_FieldSeparator.Text = "Field separator"
        Me.lbl_FieldSeparator.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_FieldSeparator
        '
        Me.txt_FieldSeparator.ArrowsIncrement = 0
        Me.txt_FieldSeparator.BackColor = System.Drawing.Color.MintCream
        Me.txt_FieldSeparator.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FieldSeparator.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FieldSeparator.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FieldSeparator.ForeColor = System.Drawing.Color.Black
        Me.txt_FieldSeparator.Increment = 0
        Me.txt_FieldSeparator.Location = New System.Drawing.Point(123, 53)
        Me.txt_FieldSeparator.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_FieldSeparator.MaxLength = 1
        Me.txt_FieldSeparator.MaxValue = 0
        Me.txt_FieldSeparator.MinValue = 0
        Me.txt_FieldSeparator.Name = "txt_FieldSeparator"
        Me.txt_FieldSeparator.NumericValue = 0
        Me.txt_FieldSeparator.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FieldSeparator.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_FieldSeparator.RoundingStep = 0
        Me.txt_FieldSeparator.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FieldSeparator.Size = New System.Drawing.Size(19, 16)
        Me.txt_FieldSeparator.TabIndex = 32
        Me.txt_FieldSeparator.Text = ","
        Me.txt_FieldSeparator.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_DecimalSeparator
        '
        Me.lbl_DecimalSeparator.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_DecimalSeparator.ForeColor = System.Drawing.Color.Black
        Me.lbl_DecimalSeparator.Location = New System.Drawing.Point(7, 37)
        Me.lbl_DecimalSeparator.Name = "lbl_DecimalSeparator"
        Me.lbl_DecimalSeparator.Size = New System.Drawing.Size(115, 13)
        Me.lbl_DecimalSeparator.TabIndex = 141
        Me.lbl_DecimalSeparator.Text = "Decimal separator"
        Me.lbl_DecimalSeparator.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_DecimalSeparator
        '
        Me.txt_DecimalSeparator.ArrowsIncrement = 0
        Me.txt_DecimalSeparator.BackColor = System.Drawing.Color.MintCream
        Me.txt_DecimalSeparator.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_DecimalSeparator.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_DecimalSeparator.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_DecimalSeparator.ForeColor = System.Drawing.Color.Black
        Me.txt_DecimalSeparator.Increment = 0
        Me.txt_DecimalSeparator.Location = New System.Drawing.Point(123, 35)
        Me.txt_DecimalSeparator.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_DecimalSeparator.MaxLength = 1
        Me.txt_DecimalSeparator.MaxValue = 0
        Me.txt_DecimalSeparator.MinValue = 0
        Me.txt_DecimalSeparator.Name = "txt_DecimalSeparator"
        Me.txt_DecimalSeparator.NumericValue = 0
        Me.txt_DecimalSeparator.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_DecimalSeparator.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_DecimalSeparator.RoundingStep = 0
        Me.txt_DecimalSeparator.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_DecimalSeparator.Size = New System.Drawing.Size(19, 16)
        Me.txt_DecimalSeparator.TabIndex = 31
        Me.txt_DecimalSeparator.Text = "."
        Me.txt_DecimalSeparator.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_OutputSlots
        '
        Me.GroupBox_OutputSlots.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GroupBox_OutputSlots.Controls.Add(Me.chk_OnlySelectedRows)
        Me.GroupBox_OutputSlots.Controls.Add(Me.txt_BinsNumSlots)
        Me.GroupBox_OutputSlots.Controls.Add(Me.Label_BinsNumSlots)
        Me.GroupBox_OutputSlots.Controls.Add(Me.txt_BinsFirstSlot)
        Me.GroupBox_OutputSlots.Controls.Add(Me.Label_BinsFirstSlot)
        Me.GroupBox_OutputSlots.Controls.Add(Me.txt_SlotCounter)
        Me.GroupBox_OutputSlots.Controls.Add(Me.Label_CounterSlot)
        Me.GroupBox_OutputSlots.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_OutputSlots.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_OutputSlots.Location = New System.Drawing.Point(2, 88)
        Me.GroupBox_OutputSlots.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_OutputSlots.Name = "GroupBox_OutputSlots"
        Me.GroupBox_OutputSlots.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox_OutputSlots.Size = New System.Drawing.Size(152, 92)
        Me.GroupBox_OutputSlots.TabIndex = 5
        Me.GroupBox_OutputSlots.TabStop = False
        Me.GroupBox_OutputSlots.Text = "Output Slots"
        '
        'chk_OnlySelectedRows
        '
        Me.chk_OnlySelectedRows.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_OnlySelectedRows.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_OnlySelectedRows.ForeColor = System.Drawing.Color.Black
        Me.chk_OnlySelectedRows.Location = New System.Drawing.Point(6, 72)
        Me.chk_OnlySelectedRows.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chk_OnlySelectedRows.Name = "chk_OnlySelectedRows"
        Me.chk_OnlySelectedRows.Size = New System.Drawing.Size(134, 17)
        Me.chk_OnlySelectedRows.TabIndex = 139
        Me.chk_OnlySelectedRows.Text = "Only selected rows"
        Me.chk_OnlySelectedRows.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_OnlySelectedRows.UseVisualStyleBackColor = True
        '
        'txt_BinsNumSlots
        '
        Me.txt_BinsNumSlots.ArrowsIncrement = 1
        Me.txt_BinsNumSlots.BackColor = System.Drawing.Color.MintCream
        Me.txt_BinsNumSlots.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_BinsNumSlots.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_BinsNumSlots.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BinsNumSlots.ForeColor = System.Drawing.Color.Black
        Me.txt_BinsNumSlots.Increment = 0.2
        Me.txt_BinsNumSlots.Location = New System.Drawing.Point(98, 53)
        Me.txt_BinsNumSlots.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_BinsNumSlots.MaxLength = 4
        Me.txt_BinsNumSlots.MaxValue = 999
        Me.txt_BinsNumSlots.MinValue = 1
        Me.txt_BinsNumSlots.Name = "txt_BinsNumSlots"
        Me.txt_BinsNumSlots.NumericValue = 12
        Me.txt_BinsNumSlots.NumericValueInteger = 12
        Me.txt_BinsNumSlots.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_BinsNumSlots.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_BinsNumSlots.RoundingStep = 0
        Me.txt_BinsNumSlots.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_BinsNumSlots.Size = New System.Drawing.Size(45, 15)
        Me.txt_BinsNumSlots.TabIndex = 35
        Me.txt_BinsNumSlots.Text = "12"
        Me.txt_BinsNumSlots.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_BinsNumSlots
        '
        Me.Label_BinsNumSlots.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_BinsNumSlots.ForeColor = System.Drawing.Color.Black
        Me.Label_BinsNumSlots.Location = New System.Drawing.Point(4, 53)
        Me.Label_BinsNumSlots.Name = "Label_BinsNumSlots"
        Me.Label_BinsNumSlots.Size = New System.Drawing.Size(91, 13)
        Me.Label_BinsNumSlots.TabIndex = 138
        Me.Label_BinsNumSlots.Text = "Bins (num slots)"
        Me.Label_BinsNumSlots.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_BinsFirstSlot
        '
        Me.txt_BinsFirstSlot.ArrowsIncrement = 1
        Me.txt_BinsFirstSlot.BackColor = System.Drawing.Color.MintCream
        Me.txt_BinsFirstSlot.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_BinsFirstSlot.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_BinsFirstSlot.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_BinsFirstSlot.ForeColor = System.Drawing.Color.Black
        Me.txt_BinsFirstSlot.Increment = 0.2
        Me.txt_BinsFirstSlot.Location = New System.Drawing.Point(98, 35)
        Me.txt_BinsFirstSlot.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_BinsFirstSlot.MaxLength = 4
        Me.txt_BinsFirstSlot.MaxValue = 999
        Me.txt_BinsFirstSlot.MinValue = -1
        Me.txt_BinsFirstSlot.Name = "txt_BinsFirstSlot"
        Me.txt_BinsFirstSlot.NumericValue = -1
        Me.txt_BinsFirstSlot.NumericValueInteger = -1
        Me.txt_BinsFirstSlot.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_BinsFirstSlot.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_BinsFirstSlot.RoundingStep = 0
        Me.txt_BinsFirstSlot.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_BinsFirstSlot.Size = New System.Drawing.Size(45, 15)
        Me.txt_BinsFirstSlot.TabIndex = 34
        Me.txt_BinsFirstSlot.Text = "-1"
        Me.txt_BinsFirstSlot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_BinsFirstSlot
        '
        Me.Label_BinsFirstSlot.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_BinsFirstSlot.ForeColor = System.Drawing.Color.Black
        Me.Label_BinsFirstSlot.Location = New System.Drawing.Point(4, 36)
        Me.Label_BinsFirstSlot.Name = "Label_BinsFirstSlot"
        Me.Label_BinsFirstSlot.Size = New System.Drawing.Size(91, 13)
        Me.Label_BinsFirstSlot.TabIndex = 136
        Me.Label_BinsFirstSlot.Text = "Bins (first slot)"
        Me.Label_BinsFirstSlot.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_SlotCounter
        '
        Me.txt_SlotCounter.ArrowsIncrement = 1
        Me.txt_SlotCounter.BackColor = System.Drawing.Color.MintCream
        Me.txt_SlotCounter.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotCounter.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotCounter.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotCounter.ForeColor = System.Drawing.Color.Black
        Me.txt_SlotCounter.Increment = 0.2
        Me.txt_SlotCounter.Location = New System.Drawing.Point(98, 17)
        Me.txt_SlotCounter.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_SlotCounter.MaxLength = 4
        Me.txt_SlotCounter.MaxValue = 999
        Me.txt_SlotCounter.MinValue = -1
        Me.txt_SlotCounter.Name = "txt_SlotCounter"
        Me.txt_SlotCounter.NumericValue = -1
        Me.txt_SlotCounter.NumericValueInteger = -1
        Me.txt_SlotCounter.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotCounter.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotCounter.RoundingStep = 0
        Me.txt_SlotCounter.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotCounter.Size = New System.Drawing.Size(45, 15)
        Me.txt_SlotCounter.TabIndex = 33
        Me.txt_SlotCounter.Text = "-1"
        Me.txt_SlotCounter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage_Isotopes
        '
        Me.TabPage_Isotopes.Controls.Add(Me.btn_EditSamplesRowsFile)
        Me.TabPage_Isotopes.Controls.Add(Me.cmb_SampleRows)
        Me.TabPage_Isotopes.Controls.Add(Me.btn_ExtendSelectedIsotope)
        Me.TabPage_Isotopes.Controls.Add(Me.btn_ExtendCheckedRows)
        Me.TabPage_Isotopes.Controls.Add(Me.btn_DeselectAllRows)
        Me.TabPage_Isotopes.Controls.Add(Me.MyListView1)
        Me.TabPage_Isotopes.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Isotopes.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabPage_Isotopes.Name = "TabPage_Isotopes"
        Me.TabPage_Isotopes.Size = New System.Drawing.Size(157, 494)
        Me.TabPage_Isotopes.TabIndex = 2
        Me.TabPage_Isotopes.Text = "Isotopes"
        Me.TabPage_Isotopes.UseVisualStyleBackColor = True
        '
        'btn_EditSamplesRowsFile
        '
        Me.btn_EditSamplesRowsFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_EditSamplesRowsFile.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker31.IsActive = False
        DesignerRectTracker31.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker31.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_EditSamplesRowsFile.CenterPtTracker = DesignerRectTracker31
        CBlendItems31.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems31.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_EditSamplesRowsFile.ColorFillBlend = CBlendItems31
        CBlendItems32.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems32.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_EditSamplesRowsFile.ColorFillBlendChecked = CBlendItems32
        Me.btn_EditSamplesRowsFile.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_EditSamplesRowsFile.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_EditSamplesRowsFile.Corners.All = CType(6, Short)
        Me.btn_EditSamplesRowsFile.Corners.LowerLeft = CType(6, Short)
        Me.btn_EditSamplesRowsFile.Corners.LowerRight = CType(6, Short)
        Me.btn_EditSamplesRowsFile.Corners.UpperLeft = CType(6, Short)
        Me.btn_EditSamplesRowsFile.Corners.UpperRight = CType(6, Short)
        Me.btn_EditSamplesRowsFile.DimFactorGray = -10
        Me.btn_EditSamplesRowsFile.DimFactorOver = 30
        Me.btn_EditSamplesRowsFile.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_EditSamplesRowsFile.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_EditSamplesRowsFile.FocalPoints.CenterPtX = 0.0!
        Me.btn_EditSamplesRowsFile.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_EditSamplesRowsFile.FocalPoints.FocusPtX = 0.0!
        Me.btn_EditSamplesRowsFile.FocalPoints.FocusPtY = 0.0!
        Me.btn_EditSamplesRowsFile.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_EditSamplesRowsFile.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_EditSamplesRowsFile.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_EditSamplesRowsFile.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker32.IsActive = False
        DesignerRectTracker32.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker32.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_EditSamplesRowsFile.FocusPtTracker = DesignerRectTracker32
        Me.btn_EditSamplesRowsFile.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_EditSamplesRowsFile.Image = Nothing
        Me.btn_EditSamplesRowsFile.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_EditSamplesRowsFile.ImageIndex = 0
        Me.btn_EditSamplesRowsFile.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_EditSamplesRowsFile.Location = New System.Drawing.Point(6, 472)
        Me.btn_EditSamplesRowsFile.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_EditSamplesRowsFile.Name = "btn_EditSamplesRowsFile"
        Me.btn_EditSamplesRowsFile.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_EditSamplesRowsFile.SideImage = Nothing
        Me.btn_EditSamplesRowsFile.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_EditSamplesRowsFile.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_EditSamplesRowsFile.Size = New System.Drawing.Size(145, 18)
        Me.btn_EditSamplesRowsFile.TabIndex = 176
        Me.btn_EditSamplesRowsFile.Text = "Edit sample rows file"
        Me.btn_EditSamplesRowsFile.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_EditSamplesRowsFile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_EditSamplesRowsFile.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_EditSamplesRowsFile.TextShadow = System.Drawing.Color.Transparent
        '
        'cmb_SampleRows
        '
        Me.cmb_SampleRows.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.cmb_SampleRows.ArrowColor = System.Drawing.Color.Transparent
        Me.cmb_SampleRows.BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_SampleRows.BackColor_Focused = System.Drawing.Color.AliceBlue
        Me.cmb_SampleRows.BackColor_Over = System.Drawing.Color.LemonChiffon
        Me.cmb_SampleRows.BorderColor = System.Drawing.Color.PowderBlue
        Me.cmb_SampleRows.BorderSize = 1
        Me.cmb_SampleRows.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_SampleRows.DropDown_BackColor = System.Drawing.Color.AliceBlue
        Me.cmb_SampleRows.DropDown_BackSelected = System.Drawing.Color.Gainsboro
        Me.cmb_SampleRows.DropDown_BorderColor = System.Drawing.Color.AliceBlue
        Me.cmb_SampleRows.DropDown_ForeColor = System.Drawing.Color.Black
        Me.cmb_SampleRows.DropDown_ForeSelected = System.Drawing.Color.Black
        Me.cmb_SampleRows.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_SampleRows.DropDownWidth = 300
        Me.cmb_SampleRows.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.cmb_SampleRows.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_SampleRows.ForeColor = System.Drawing.Color.Black
        Me.cmb_SampleRows.IntegralHeight = False
        Me.cmb_SampleRows.ItemHeight = 10
        Me.cmb_SampleRows.Items.AddRange(New Object() {"x0.1", "x0.2", "x0.5", "x1", "x2", "x5", "x10", "x20", "x50"})
        Me.cmb_SampleRows.Location = New System.Drawing.Point(6, 451)
        Me.cmb_SampleRows.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmb_SampleRows.MaxDropDownItems = 99
        Me.cmb_SampleRows.Name = "cmb_SampleRows"
        Me.cmb_SampleRows.ShadowColor = System.Drawing.Color.Transparent
        Me.cmb_SampleRows.Size = New System.Drawing.Size(145, 16)
        Me.cmb_SampleRows.TabIndex = 175
        Me.cmb_SampleRows.TextPosition = 1
        '
        'btn_ExtendSelectedIsotope
        '
        Me.btn_ExtendSelectedIsotope.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_ExtendSelectedIsotope.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker33.IsActive = False
        DesignerRectTracker33.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker33.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ExtendSelectedIsotope.CenterPtTracker = DesignerRectTracker33
        CBlendItems33.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems33.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ExtendSelectedIsotope.ColorFillBlend = CBlendItems33
        CBlendItems34.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems34.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ExtendSelectedIsotope.ColorFillBlendChecked = CBlendItems34
        Me.btn_ExtendSelectedIsotope.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ExtendSelectedIsotope.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ExtendSelectedIsotope.Corners.All = CType(6, Short)
        Me.btn_ExtendSelectedIsotope.Corners.LowerLeft = CType(6, Short)
        Me.btn_ExtendSelectedIsotope.Corners.LowerRight = CType(6, Short)
        Me.btn_ExtendSelectedIsotope.Corners.UpperLeft = CType(6, Short)
        Me.btn_ExtendSelectedIsotope.Corners.UpperRight = CType(6, Short)
        Me.btn_ExtendSelectedIsotope.DimFactorGray = -10
        Me.btn_ExtendSelectedIsotope.DimFactorOver = 30
        Me.btn_ExtendSelectedIsotope.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_ExtendSelectedIsotope.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_ExtendSelectedIsotope.FocalPoints.CenterPtX = 0.0!
        Me.btn_ExtendSelectedIsotope.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_ExtendSelectedIsotope.FocalPoints.FocusPtX = 0.0!
        Me.btn_ExtendSelectedIsotope.FocalPoints.FocusPtY = 0.0!
        Me.btn_ExtendSelectedIsotope.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_ExtendSelectedIsotope.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_ExtendSelectedIsotope.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ExtendSelectedIsotope.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker34.IsActive = False
        DesignerRectTracker34.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker34.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ExtendSelectedIsotope.FocusPtTracker = DesignerRectTracker34
        Me.btn_ExtendSelectedIsotope.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ExtendSelectedIsotope.Image = Nothing
        Me.btn_ExtendSelectedIsotope.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ExtendSelectedIsotope.ImageIndex = 0
        Me.btn_ExtendSelectedIsotope.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ExtendSelectedIsotope.Location = New System.Drawing.Point(6, 427)
        Me.btn_ExtendSelectedIsotope.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_ExtendSelectedIsotope.Name = "btn_ExtendSelectedIsotope"
        Me.btn_ExtendSelectedIsotope.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_ExtendSelectedIsotope.SideImage = Nothing
        Me.btn_ExtendSelectedIsotope.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ExtendSelectedIsotope.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ExtendSelectedIsotope.Size = New System.Drawing.Size(145, 18)
        Me.btn_ExtendSelectedIsotope.TabIndex = 174
        Me.btn_ExtendSelectedIsotope.Text = "Extend selected isotope"
        Me.btn_ExtendSelectedIsotope.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ExtendSelectedIsotope.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ExtendSelectedIsotope.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ExtendSelectedIsotope.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_ExtendCheckedRows
        '
        Me.btn_ExtendCheckedRows.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_ExtendCheckedRows.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker35.IsActive = False
        DesignerRectTracker35.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker35.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ExtendCheckedRows.CenterPtTracker = DesignerRectTracker35
        CBlendItems35.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems35.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ExtendCheckedRows.ColorFillBlend = CBlendItems35
        CBlendItems36.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems36.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_ExtendCheckedRows.ColorFillBlendChecked = CBlendItems36
        Me.btn_ExtendCheckedRows.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ExtendCheckedRows.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ExtendCheckedRows.Corners.All = CType(6, Short)
        Me.btn_ExtendCheckedRows.Corners.LowerLeft = CType(6, Short)
        Me.btn_ExtendCheckedRows.Corners.LowerRight = CType(6, Short)
        Me.btn_ExtendCheckedRows.Corners.UpperLeft = CType(6, Short)
        Me.btn_ExtendCheckedRows.Corners.UpperRight = CType(6, Short)
        Me.btn_ExtendCheckedRows.DimFactorGray = -10
        Me.btn_ExtendCheckedRows.DimFactorOver = 30
        Me.btn_ExtendCheckedRows.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_ExtendCheckedRows.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_ExtendCheckedRows.FocalPoints.CenterPtX = 0.0!
        Me.btn_ExtendCheckedRows.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_ExtendCheckedRows.FocalPoints.FocusPtX = 0.0!
        Me.btn_ExtendCheckedRows.FocalPoints.FocusPtY = 0.0!
        Me.btn_ExtendCheckedRows.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_ExtendCheckedRows.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_ExtendCheckedRows.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_ExtendCheckedRows.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker36.IsActive = False
        DesignerRectTracker36.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker36.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ExtendCheckedRows.FocusPtTracker = DesignerRectTracker36
        Me.btn_ExtendCheckedRows.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ExtendCheckedRows.Image = Nothing
        Me.btn_ExtendCheckedRows.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ExtendCheckedRows.ImageIndex = 0
        Me.btn_ExtendCheckedRows.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_ExtendCheckedRows.Location = New System.Drawing.Point(6, 405)
        Me.btn_ExtendCheckedRows.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_ExtendCheckedRows.Name = "btn_ExtendCheckedRows"
        Me.btn_ExtendCheckedRows.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_ExtendCheckedRows.SideImage = Nothing
        Me.btn_ExtendCheckedRows.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ExtendCheckedRows.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ExtendCheckedRows.Size = New System.Drawing.Size(145, 18)
        Me.btn_ExtendCheckedRows.TabIndex = 173
        Me.btn_ExtendCheckedRows.Text = "Extend checked rows"
        Me.btn_ExtendCheckedRows.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ExtendCheckedRows.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_ExtendCheckedRows.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ExtendCheckedRows.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_DeselectAllRows
        '
        Me.btn_DeselectAllRows.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btn_DeselectAllRows.BorderColor = System.Drawing.Color.Gray
        DesignerRectTracker37.IsActive = False
        DesignerRectTracker37.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker37.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_DeselectAllRows.CenterPtTracker = DesignerRectTracker37
        CBlendItems37.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems37.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_DeselectAllRows.ColorFillBlend = CBlendItems37
        CBlendItems38.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))}
        CBlendItems38.iPoint = New Single() {0.0!, 0.3309608!, 1.0!}
        Me.btn_DeselectAllRows.ColorFillBlendChecked = CBlendItems38
        Me.btn_DeselectAllRows.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_DeselectAllRows.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_DeselectAllRows.Corners.All = CType(6, Short)
        Me.btn_DeselectAllRows.Corners.LowerLeft = CType(6, Short)
        Me.btn_DeselectAllRows.Corners.LowerRight = CType(6, Short)
        Me.btn_DeselectAllRows.Corners.UpperLeft = CType(6, Short)
        Me.btn_DeselectAllRows.Corners.UpperRight = CType(6, Short)
        Me.btn_DeselectAllRows.DimFactorGray = -10
        Me.btn_DeselectAllRows.DimFactorOver = 30
        Me.btn_DeselectAllRows.FillType = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_DeselectAllRows.FillTypeChecked = Theremino_MCA.MyButton.eFillType.LinearVertical
        Me.btn_DeselectAllRows.FocalPoints.CenterPtX = 0.0!
        Me.btn_DeselectAllRows.FocalPoints.CenterPtY = 0.4074074!
        Me.btn_DeselectAllRows.FocalPoints.FocusPtX = 0.0!
        Me.btn_DeselectAllRows.FocalPoints.FocusPtY = 0.0!
        Me.btn_DeselectAllRows.FocalPointsChecked.CenterPtX = 0.5045872!
        Me.btn_DeselectAllRows.FocalPointsChecked.CenterPtY = 0.5!
        Me.btn_DeselectAllRows.FocalPointsChecked.FocusPtX = 0.0!
        Me.btn_DeselectAllRows.FocalPointsChecked.FocusPtY = 0.0!
        DesignerRectTracker38.IsActive = False
        DesignerRectTracker38.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker38.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_DeselectAllRows.FocusPtTracker = DesignerRectTracker38
        Me.btn_DeselectAllRows.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_DeselectAllRows.Image = Nothing
        Me.btn_DeselectAllRows.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_DeselectAllRows.ImageIndex = 0
        Me.btn_DeselectAllRows.ImageSize = New System.Drawing.Size(16, 16)
        Me.btn_DeselectAllRows.Location = New System.Drawing.Point(6, 384)
        Me.btn_DeselectAllRows.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_DeselectAllRows.Name = "btn_DeselectAllRows"
        Me.btn_DeselectAllRows.Shape = Theremino_MCA.MyButton.eShape.Rectangle
        Me.btn_DeselectAllRows.SideImage = Nothing
        Me.btn_DeselectAllRows.SideImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_DeselectAllRows.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_DeselectAllRows.Size = New System.Drawing.Size(145, 18)
        Me.btn_DeselectAllRows.TabIndex = 172
        Me.btn_DeselectAllRows.Text = "Deselect all rows"
        Me.btn_DeselectAllRows.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_DeselectAllRows.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.btn_DeselectAllRows.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_DeselectAllRows.TextShadow = System.Drawing.Color.Transparent
        '
        'MyListView1
        '
        Me.MyListView1.Activation = System.Windows.Forms.ItemActivation.TwoClick
        Me.MyListView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MyListView1.CheckBoxes = True
        Me.MyListView1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MyListView1.Enabled = False
        Me.MyListView1.FullRowSelect = True
        Me.MyListView1.GridLines = True
        Me.MyListView1.Header_BackColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.MyListView1.Header_BackColor2 = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.MyListView1.Header_Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MyListView1.Header_ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.MyListView1.Header_ShadowColor = System.Drawing.Color.White
        Me.MyListView1.HideSelection = False
        Me.MyListView1.LabelEdit = True
        Me.MyListView1.Location = New System.Drawing.Point(0, 5)
        Me.MyListView1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MyListView1.MultiSelect = False
        Me.MyListView1.Name = "MyListView1"
        Me.MyListView1.OwnerDraw = True
        Me.MyListView1.ShadowColor = System.Drawing.Color.Transparent
        Me.MyListView1.Size = New System.Drawing.Size(154, 375)
        Me.MyListView1.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.MyListView1.TabIndex = 40
        Me.MyListView1.UseCompatibleStateImageBehavior = False
        '
        'Timer1Sec
        '
        Me.Timer1Sec.Interval = 1000
        '
        'txt_UserText
        '
        Me.txt_UserText.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_UserText.BackColor = System.Drawing.Color.AliceBlue
        Me.txt_UserText.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.txt_UserText.ForeColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.txt_UserText.Location = New System.Drawing.Point(5, 485)
        Me.txt_UserText.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_UserText.Multiline = True
        Me.txt_UserText.Name = "txt_UserText"
        Me.txt_UserText.Size = New System.Drawing.Size(161, 85)
        Me.txt_UserText.TabIndex = 27
        Me.txt_UserText.Text = "User text here."
        '
        'Timer10Hz
        '
        Me.Timer10Hz.Interval = 1000
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.LightYellow
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel1, Me.StatusLabel2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 575)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(784, 26)
        Me.StatusStrip1.TabIndex = 164
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusLabel1
        '
        Me.StatusLabel1.AutoSize = False
        Me.StatusLabel1.BackColor = System.Drawing.Color.Transparent
        Me.StatusLabel1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel1.Name = "StatusLabel1"
        Me.StatusLabel1.Size = New System.Drawing.Size(280, 21)
        '
        'StatusLabel2
        '
        Me.StatusLabel2.AutoSize = False
        Me.StatusLabel2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusLabel2.Name = "StatusLabel2"
        Me.StatusLabel2.Size = New System.Drawing.Size(489, 21)
        Me.StatusLabel2.Spring = True
        '
        'Menu_Language_Portoguese
        '
        Me.Menu_Language_Portoguese.Image = CType(resources.GetObject("Menu_Language_Portoguese.Image"), System.Drawing.Image)
        Me.Menu_Language_Portoguese.Name = "Menu_Language_Portoguese"
        Me.Menu_Language_Portoguese.Size = New System.Drawing.Size(152, 22)
        Me.Menu_Language_Portoguese.Text = "Portoguese"
        '
        'Form_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(784, 601)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox_SpectrumData)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.txt_UserText)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MinimumSize = New System.Drawing.Size(750, 640)
        Me.Name = "Form_Main"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino MCA"
        Me.GroupBox_Params.ResumeLayout(False)
        Me.GroupBox_Params.PerformLayout()
        CType(Me.Pbox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_SpectrumData.ResumeLayout(False)
        Me.GroupBox_SpectrumData.PerformLayout()
        CType(Me.tk_EqMaster, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_LinMaster, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_Dummy.ResumeLayout(False)
        Me.Panel_Dummy.PerformLayout()
        CType(Me.PBox_Spectrum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_MaxY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tk_Zoom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox_Info.ResumeLayout(False)
        Me.GroupBox_Info.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage_Operation.ResumeLayout(False)
        Me.GroupBox_BaseLineTest.ResumeLayout(False)
        Me.GroupBox_BaseLineTest.PerformLayout()
        Me.GroupBox_AudioInput.ResumeLayout(False)
        Me.GroupBox_AudioInput.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.TabPage_Options.ResumeLayout(False)
        Me.GroupBox_GaussianDec.ResumeLayout(False)
        Me.GroupBox_GaussianDec.PerformLayout()
        Me.GroupBox_ResComp.ResumeLayout(False)
        Me.GroupBox_ResComp.PerformLayout()
        Me.GroupBox_ScaleOptions.ResumeLayout(False)
        Me.GroupBox_ScaleOptions.PerformLayout()
        Me.GroupBox_Timers.ResumeLayout(False)
        Me.GroupBox_Timers.PerformLayout()
        Me.GroupBox_ExportOptions.ResumeLayout(False)
        Me.GroupBox_ExportOptions.PerformLayout()
        Me.GroupBox_OutputSlots.ResumeLayout(False)
        Me.GroupBox_OutputSlots.PerformLayout()
        Me.TabPage_Isotopes.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TimerDraw As System.Windows.Forms.Timer
    Friend WithEvents GroupBox_Params As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_SpectrumData As System.Windows.Forms.GroupBox
    Friend WithEvents PBox_Spectrum As System.Windows.Forms.PictureBox
    Friend WithEvents btn_SaveAsBkg As MyButton
    Friend WithEvents btn_UseBkg As MyButton
    Friend WithEvents txt_SlotCounter As MyTextBox
    Friend WithEvents Label_CounterSlot As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_SaveImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_SavePlotImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_English As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Italian As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Francais As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Espanol As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Deutsch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_Isotopes As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton_StartMeasure As System.Windows.Forms.ToolStripButton
    Friend WithEvents btn_Reference1 As MyButton
    Friend WithEvents Pbox3 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox_Info As System.Windows.Forms.GroupBox
    Friend WithEvents Label_TotalPulses As System.Windows.Forms.Label
    Friend WithEvents Label_TotalSeconds As System.Windows.Forms.Label
    Friend WithEvents Label_PulsesPerSec As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_Operation As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_Options As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_AudioInput As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_OutputSlots As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_PulsesPerSec As System.Windows.Forms.Label
    Friend WithEvents lbl_TotalPulses As System.Windows.Forms.Label
    Friend WithEvents btn_Reference2 As MyButton
    Friend WithEvents lbl_TotalSeconds As System.Windows.Forms.Label
    Friend WithEvents btn_Reference3 As MyButton
    Friend WithEvents Timer1Sec As System.Windows.Forms.Timer
    Friend WithEvents ToolStripButton_SaveImage As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_ExportPulseHeight As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton_ViewPulses As System.Windows.Forms.ToolStripButton
    Friend WithEvents TabPage_Isotopes As System.Windows.Forms.TabPage
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_LoadConfiguration As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_SaveConfigurationAs As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GroupBox_ExportOptions As System.Windows.Forms.GroupBox
    Friend WithEvents txt_DecimalSeparator As MyTextBox
    Friend WithEvents lbl_DecimalSeparator As System.Windows.Forms.Label
    Friend WithEvents lbl_FieldSeparator As System.Windows.Forms.Label
    Friend WithEvents txt_FieldSeparator As MyTextBox
    Friend WithEvents chk_ExportWithHeader As System.Windows.Forms.CheckBox
    Friend WithEvents Menu_File_ImportToRef1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_ImportToRef2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_File_ImportToRef3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButton_Export As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton_Run As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_ImportToBKG As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MyListView1 As MyListView
    Friend WithEvents tk_Zoom As System.Windows.Forms.TrackBar
    Friend WithEvents txt_UserText As System.Windows.Forms.TextBox
    Friend WithEvents txt_AudioGain As MyTextBox
    Friend WithEvents Label_AudioGain As System.Windows.Forms.Label
    Friend WithEvents GroupBox_BaseLineTest As System.Windows.Forms.GroupBox
    Friend WithEvents txt_BLT_Size As MyTextBox
    Friend WithEvents Label_BLT_Size As System.Windows.Forms.Label
    Friend WithEvents txt_BLT_Position As MyTextBox
    Friend WithEvents Label_BLT_Position As System.Windows.Forms.Label
    Friend WithEvents chk_BltEnable As System.Windows.Forms.CheckBox
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Tools As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ToDoList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButton_ViewEqualizers As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents txt_IIR_Filter As MyTextBox
    Friend WithEvents txt_BLT_MaxSlope As MyTextBox
    Friend WithEvents txt_MinEnergy As MyTextBox
    Friend WithEvents Label_MinEnergy As System.Windows.Forms.Label
    Friend WithEvents txt_DrawSpeed As MyTextBox
    Friend WithEvents Label_DrawSpeed As System.Windows.Forms.Label
    Friend WithEvents Timer10Hz As System.Windows.Forms.Timer
    Friend WithEvents GroupBox_Timers As System.Windows.Forms.GroupBox
    Friend WithEvents txt_StopTimer As MyTextBox
    Friend WithEvents Label_StopTimer As System.Windows.Forms.Label
    Friend WithEvents ToolStripButton_Identifier As System.Windows.Forms.ToolStripButton
    Friend WithEvents btn_Xlog As MyButton
    Friend WithEvents btn_Ylog As MyButton
    Friend WithEvents GroupBox_ScaleOptions As System.Windows.Forms.GroupBox
    Friend WithEvents txt_YlogExponent As MyTextBox
    Friend WithEvents Label_YlogExponent As System.Windows.Forms.Label
    Friend WithEvents txt_BinsFirstSlot As MyTextBox
    Friend WithEvents Label_BinsFirstSlot As System.Windows.Forms.Label
    Friend WithEvents txt_BinsNumSlots As MyTextBox
    Friend WithEvents Label_BinsNumSlots As System.Windows.Forms.Label
    Friend WithEvents txt_AudioZero As MyTextBox
    Friend WithEvents Label_AudioZero As System.Windows.Forms.Label
    Friend WithEvents txt_XlogExponent As MyTextBox
    Friend WithEvents Label_XlogExponent As System.Windows.Forms.Label
    Friend WithEvents chk_ThickLines As System.Windows.Forms.CheckBox
    Friend WithEvents cmb_PulsePolarity As MyComboBox
    Friend WithEvents cmb_Sampling As MyComboBox
    Friend WithEvents Label_NumBins As System.Windows.Forms.Label
    Friend WithEvents Label_Sampling As System.Windows.Forms.Label
    Friend WithEvents Label_PulsePolarity As System.Windows.Forms.Label
    Friend WithEvents cmb_Bins As MyComboBox
    Friend WithEvents txt_IntegrationTime As MyTextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents tk_LinMaster As System.Windows.Forms.TrackBar
    Friend WithEvents tk_EqMaster As System.Windows.Forms.TrackBar
    Friend WithEvents Menu_Help_TestAudioSignal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help_MinimizingFWHM As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_PmtAdapters As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_OpenProgramFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help_IsotopeIdentifier As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuTools_NoiseTest As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txt_BLT_MaxNoise As MyTextBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents StatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents GroupBox_ResComp As System.Windows.Forms.GroupBox
    Friend WithEvents Label_ResCompSize As System.Windows.Forms.Label
    Friend WithEvents txt_ResCompSize As MyTextBox
    Friend WithEvents Label_ResCompRight As System.Windows.Forms.Label
    Friend WithEvents txt_ResCompRight As MyTextBox
    Friend WithEvents chk_ResCompEnable As System.Windows.Forms.CheckBox
    Friend WithEvents txt_ResCompCenter As MyTextBox
    Friend WithEvents Label_ResCompCenter As System.Windows.Forms.Label
    Friend WithEvents Label_ResCompLeft As System.Windows.Forms.Label
    Friend WithEvents txt_ResCompLeft As MyTextBox
    Friend WithEvents Menu_Help_StartingGuide As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Japanese As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btn_MaxY As MyButton
    Friend WithEvents txt_MaxY As MyTextBox
    Friend WithEvents btn_AutoSave As MyButton
    Friend WithEvents btn_BrowseSpectrum As MyButton
    Friend WithEvents txt_EqMaster As MyTextBox
    Friend WithEvents txt_LinMaster As MyTextBox
    Friend WithEvents txt_Zoom As MyTextBox
    Friend WithEvents btn_cps As MyButton
    Friend WithEvents btn_Graph As MyButton
    Friend WithEvents btn_IntegrationTime As MyButton
    Friend WithEvents btn_IIR_Filter As MyButton
    Friend WithEvents btn_BLT_MaxSlope As MyButton
    Friend WithEvents Label_BLT_MaxNoise As System.Windows.Forms.Label
    Friend WithEvents btn_InputSelection As MyButton
    Friend WithEvents txt_AutoSave As MyTextBox
    Friend WithEvents Menu_Help_SignalConditioning As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel_Dummy As System.Windows.Forms.Panel
    Friend WithEvents Label_Dummy As System.Windows.Forms.Label
    Private WithEvents tk_MaxY As System.Windows.Forms.TrackBar
    Friend WithEvents GroupBox_GaussianDec As System.Windows.Forms.GroupBox
    Friend WithEvents chk_GaussianDecEnable As System.Windows.Forms.CheckBox
    Friend WithEvents txt_DeconvSize As MyTextBox
    Friend WithEvents Label_DeconvSize As System.Windows.Forms.Label
    Friend WithEvents Label_GaussianSize As System.Windows.Forms.Label
    Friend WithEvents txt_GaussianSize As MyTextBox
    Friend WithEvents btn_ExtendCheckedRows As MyButton
    Friend WithEvents btn_DeselectAllRows As MyButton
    Friend WithEvents Label_Vert1 As System.Windows.Forms.Label
    Friend WithEvents Label_Vert3 As System.Windows.Forms.Label
    Friend WithEvents Label_Vert2 As System.Windows.Forms.Label
    Friend WithEvents Label_Zoom As System.Windows.Forms.Label
    Friend WithEvents chk_OnlySelectedRows As System.Windows.Forms.CheckBox
    Friend WithEvents btn_ExtendSelectedIsotope As MyButton
    Friend WithEvents btn_EditSamplesRowsFile As MyButton
    Friend WithEvents cmb_SampleRows As MyComboBox
    Friend WithEvents MenuTools_StartPulseSimulator As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButton_AudioInputs As System.Windows.Forms.ToolStripButton
    Friend WithEvents cmb_AudioInDevices As MyComboBox
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Language_Chinese As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_Portoguese As System.Windows.Forms.ToolStripMenuItem
End Class
