﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Help
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Help))
        Me.rt_Help = New System.Windows.Forms.RichTextBox
        Me.SuspendLayout()
        '
        'rt_Help
        '
        Me.rt_Help.BackColor = System.Drawing.Color.AliceBlue
        Me.rt_Help.Location = New System.Drawing.Point(9, 8)
        Me.rt_Help.Name = "rt_Help"
        Me.rt_Help.ReadOnly = True
        Me.rt_Help.Size = New System.Drawing.Size(381, 364)
        Me.rt_Help.TabIndex = 0
        Me.rt_Help.Text = ""
        '
        'Form_Help
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(400, 384)
        Me.Controls.Add(Me.rt_Help)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form_Help"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Theremino MCA  Help"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents rt_Help As System.Windows.Forms.RichTextBox
End Class
