Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.



<Assembly: AssemblyTitle("Theremino MCA")> 
<Assembly: AssemblyDescription("Multi channel analyzer for gamma spectroscopy")> 
<Assembly: AssemblyCompany("Theremino System")> 
<Assembly: AssemblyProduct("Theremino MCA")> 
<Assembly: AssemblyCopyright("No copyright")> 
<Assembly: AssemblyTrademark("Theremino")> 
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Build Number
'	Revision

' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly: AssemblyVersion("7.3")> 



<Assembly: ComVisibleAttribute(False)> 
<Assembly: AssemblyFileVersionAttribute("7.3")> 