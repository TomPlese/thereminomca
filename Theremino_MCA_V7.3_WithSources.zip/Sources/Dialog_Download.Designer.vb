﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_Download
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_Download))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.btn_DD_OK = New System.Windows.Forms.Button
        Me.btn_DD_Cancel = New System.Windows.Forms.Button
        Me.lbl_Progress = New System.Windows.Forms.Label
        Me.txt_Mesassge = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 75.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.07438!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.92562!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 89.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.ProgressBar1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.btn_DD_OK, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.btn_DD_Cancel, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lbl_Progress, 0, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 83)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(451, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.ProgressBar1.Location = New System.Drawing.Point(78, 3)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(156, 23)
        Me.ProgressBar1.TabIndex = 1
        '
        'btn_DD_OK
        '
        Me.btn_DD_OK.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btn_DD_OK.Location = New System.Drawing.Point(372, 3)
        Me.btn_DD_OK.Name = "btn_DD_OK"
        Me.btn_DD_OK.Size = New System.Drawing.Size(67, 23)
        Me.btn_DD_OK.TabIndex = 0
        Me.btn_DD_OK.Text = "OK"
        '
        'btn_DD_Cancel
        '
        Me.btn_DD_Cancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btn_DD_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn_DD_Cancel.Location = New System.Drawing.Point(286, 3)
        Me.btn_DD_Cancel.Name = "btn_DD_Cancel"
        Me.btn_DD_Cancel.Size = New System.Drawing.Size(67, 23)
        Me.btn_DD_Cancel.TabIndex = 1
        Me.btn_DD_Cancel.Text = "Cancel"
        '
        'lbl_Progress
        '
        Me.lbl_Progress.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lbl_Progress.AutoSize = True
        Me.lbl_Progress.Location = New System.Drawing.Point(13, 8)
        Me.lbl_Progress.Name = "lbl_Progress"
        Me.lbl_Progress.Size = New System.Drawing.Size(48, 13)
        Me.lbl_Progress.TabIndex = 2
        Me.lbl_Progress.Text = "Progress"
        '
        'txt_Mesassge
        '
        Me.txt_Mesassge.CausesValidation = False
        Me.txt_Mesassge.Location = New System.Drawing.Point(8, 10)
        Me.txt_Mesassge.Multiline = True
        Me.txt_Mesassge.Name = "txt_Mesassge"
        Me.txt_Mesassge.Size = New System.Drawing.Size(442, 61)
        Me.txt_Mesassge.TabIndex = 1
        Me.txt_Mesassge.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.txt_Mesassge)
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel1)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(462, 122)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'Dialog_Download
        '
        Me.AcceptButton = Me.btn_DD_OK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.CancelButton = Me.btn_DD_Cancel
        Me.ClientSize = New System.Drawing.Size(473, 131)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_Download"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Download ?"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents btn_DD_OK As System.Windows.Forms.Button
    Friend WithEvents btn_DD_Cancel As System.Windows.Forms.Button
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents txt_Mesassge As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_Progress As System.Windows.Forms.Label

End Class
